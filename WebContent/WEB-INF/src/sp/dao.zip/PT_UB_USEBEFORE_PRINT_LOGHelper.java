

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_USEBEFORE_PRINT_LOG
*  ���̺� ���� :
*  ���̺� PK   :
*  ���̺� �÷� :  
*               UB_LOG_SEQ:NUMBER(22):  
*               USER_NAME:VARCHAR2(200):  
*               CIV_RECV_NUM:VARCHAR2(100):  
*               USER_NAT_NUM:VARCHAR2(32):  
*               SIGUNGU_CODE:VARCHAR2(4):  
*               USER_IP:VARCHAR2(18):  
*               INSP_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_UB_USEBEFORE_PRINT_LOGHelper{

  final static public String UB_LOG_SEQ = "UB_LOG_SEQ";
  final static public String USER_NAME = "USER_NAME";
  final static public String CIV_RECV_NUM = "CIV_RECV_NUM";
  final static public String USER_NAT_NUM = "USER_NAT_NUM";
  final static public String SIGUNGU_CODE = "SIGUNGU_CODE";
  final static public String USER_IP = "USER_IP";
  final static public String INSP_DT = "INSP_DT";
  


  public static HashMap fieldMap = new HashMap(7);
  static{
  fieldMap.put(UB_LOG_SEQ,new Integer(1) );
  fieldMap.put(USER_NAME,new Integer(2) );
  fieldMap.put(CIV_RECV_NUM,new Integer(3) );
  fieldMap.put(USER_NAT_NUM,new Integer(4) );
  fieldMap.put(SIGUNGU_CODE,new Integer(5) );
  fieldMap.put(USER_IP,new Integer(6) );
  fieldMap.put(INSP_DT,new Integer(7) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_UB_USEBEFORE_PRINT_LOG";
     final public static String PREFIX = "sp.dao.PT_UB_USEBEFORE_PRINT_LOG";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
        };
     final public static String FIELD_LIST[] = { 
       UB_LOG_SEQ,USER_NAME,CIV_RECV_NUM,USER_NAT_NUM,SIGUNGU_CODE,USER_IP,INSP_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_UB_USEBEFORE_PRINT_LOGEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UB_LOG_SEQ").append("'")
            .append(" value='").append(""+ent.getUB_LOG_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_NAME").append("'")
            .append(" value='").append(""+ent.getUSER_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CIV_RECV_NUM").append("'")
            .append(" value='").append(""+ent.getCIV_RECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_NAT_NUM").append("'")
            .append(" value='").append(""+ent.getUSER_NAT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_CODE").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_IP").append("'")
            .append(" value='").append(""+ent.getUSER_IP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INSP_DT").append("'")
            .append(" value='").append(""+ent.getINSP_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
