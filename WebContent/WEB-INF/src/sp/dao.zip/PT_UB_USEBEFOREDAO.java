


/*
*  Automatic generated  source
*  ��  ��  �� : ����
*
*  ���̺� ��   :PT_UB_USEBEFORE
*  ���̺� ���� :
*  ���̺� PK   :
*               RECV_NUM
*               SIDO_CODE
*               SIGUNGU_CODE
*  ���̺� �÷� :
*               SIDO_CODE:VARCHAR2(5):
*               SIGUNGU_CODE:VARCHAR2(4):
*               APPLPER_NM:VARCHAR2(50):
*               APPLPER_REP:VARCHAR2(24):
*               APPLPER_POSTNUM:VARCHAR2(16):
*               APPLPER_ADDR:VARCHAR2(100):
*               APPLPER_DETAILADDR:VARCHAR2(128):
*               APPLPER_TELNUM:VARCHAR2(24):
*               OPE_NAME:VARCHAR2(100):
*               OPE_REP:VARCHAR2(24):
*               OPE_TELNUM:VARCHAR2(24):
*               COI_WRT_NUM:VARCHAR2(24):
*               OPE_POSTNUM:VARCHAR2(16):
*               OPE_ADDR:VARCHAR2(100):
*               OPE_DETAILADDR:VARCHAR2(128):
*               INSP_SPOT_NM:VARCHAR2(100):
*               INSP_SPOT_POSTNUM:VARCHAR2(16):
*               INSP_SPOT_ADDR:VARCHAR2(100):
*               INSP_SPOT_DETAILADDR:VARCHAR2(128):
*               PLANER_NM:VARCHAR2(26):
*               WORK_ITEM:VARCHAR2(250):
*               AREA:VARCHAR2(10):
*               NUM_FL:VARCHAR2(200):
*               USE:VARCHAR2(100):
*               INSP_APPL_WORK:VARCHAR2(200):
*               INSP_APPL_DT:VARCHAR2(24):
*               INSP_DT:VARCHAR2(24):
*               INSP_FEE:VARCHAR2(26):
*               INSPER_NM:VARCHAR2(50):
*               INSPER_POSI:VARCHAR2(50):
*               JUDGM:VARCHAR2(255):
*               PLAN_CONFIRM_YN:VARCHAR2(5):
*               SW_BEF_REPO_DELINUM:VARCHAR2(50):
*               SW_DT:VARCHAR2(24):
*               EW_DT:VARCHAR2(24):
*               INSP_WISH_YMD:VARCHAR2(24):
*               OFFI_TELNUM:VARCHAR2(26):
*               OFFI_NM:VARCHAR2(60):
*               USEBEFINSP_DELINUM:VARCHAR2(50):
*               SUV:VARCHAR2(100):
*               REMARK:VARCHAR2(255):
*               CER_DELI_YN:VARCHAR2(5):
*               PLAN_CONFIRM_REMARK:VARCHAR2(255):
*               NAPPL_YN:VARCHAR2(20):
*               NAPPL_CAUSE:VARCHAR2(100):
*               DOC_INSP_REMARK:VARCHAR2(255):
*               WRT_ID:VARCHAR2(50):
*               INS_DT:VARCHAR2(24):
*               UPD_DT:VARCHAR2(24):
*               CIV_RECV_NUM:VARCHAR2(100):
*               RECV_DT:VARCHAR2(8):
*               PLAN_CONFIRM_PER_YN:VARCHAR2(100):
*               PLAN_ENT_CHG_YN:VARCHAR2(200):
*               PLAN_CONT_CHG_YN:VARCHAR2(200):
*               RECV_NUM:VARCHAR2(30):
*               ATT_DOC:VARCHAR2(250):
*               DELI_DT:VARCHAR2(24):
*               DEFI_YN:VARCHAR2(4):
*               PROC_STE:VARCHAR2(4):
*               ISSUE_ITEM:VARCHAR2(4):
*               NET_RECV_YN:VARCHAR2(4):
*               PROC_LIM:VARCHAR2(24):
*               INSP_NUM:VARCHAR2(20):
*               PROC_OFFI:VARCHAR2(20):
*               PLAN_CONFIRM_PER_YN_CONT:VARCHAR2(200):
*               PLAN_ENT_CHG_YN_CONT:VARCHAR2(200):
*               PLAN_CONT_CHG_YN_CONT:VARCHAR2(200):
*               CHG_INSP:VARCHAR2(10):
*               INSP_ITEM:VARCHAR2(5):
*               ETC_INSP_BAS:VARCHAR2(200):
*               WORK_ITEM_ETC:VARCHAR2(200):
*               UPD_DT_OLD:VARCHAR2(24):
*               BACKUP_TRANS_DT:VARCHAR2(24):
*               TAKE_TM:VARCHAR2(24):
*               USER_NAME:VARCHAR2(255):
*               MW_PPS_GETR_ID:VARCHAR2(255):
*               OUTVARS:VARCHAR2(255):
*               MW_AFR_SHTNM:VARCHAR2(255):
*               MW_SE:VARCHAR2(255):
*               MW_CODE_CN:VARCHAR2(255):
*               TAKE_CONFRM_CODE:VARCHAR2(255):
*               DEAL_SE:VARCHAR2(255):
*               DEAL_CODE_CN:VARCHAR2(255):
*               TAKE_SE:VARCHAR2(255):
*               TAKE_CODE_CN:VARCHAR2(255):
*               REAL_DEAL_YMD:VARCHAR2(255):
*               MW_TAKE_NO:VARCHAR2(30):
*               ETC1:VARCHAR2(50):
*               ETC2:VARCHAR2(50):
*               ETC3:VARCHAR2(50):
*               BEF_PLANER_NAME:VARCHAR2(50):
*               PROC_OFFI_ID:VARCHAR2(20):
*               ADMIT_DT:VARCHAR2(24):
*/
package sp.dao;

import kjf.util.*;
import kjf.ops.*;

import java.io.*;
import java.text.*;
import java.util.*;
import java.sql.*;


public class PT_UB_USEBEFOREDAO  extends SuperToDB{

  private String default_fields[]={ "SIDO_CODE" , "SIGUNGU_CODE" , "APPLPER_NM" , "APPLPER_REP" , "APPLPER_POSTNUM" , "APPLPER_ADDR" , "APPLPER_DETAILADDR" , "APPLPER_TELNUM" , "OPE_NAME" , "OPE_REP" , "OPE_TELNUM" , "COI_WRT_NUM" , "OPE_POSTNUM" , "OPE_ADDR" , "OPE_DETAILADDR" , "INSP_SPOT_NM" , "INSP_SPOT_POSTNUM" , "INSP_SPOT_ADDR" , "INSP_SPOT_DETAILADDR" , "PLANER_NM" , "WORK_ITEM" , "AREA" , "NUM_FL" , "USE" , "INSP_APPL_WORK" , "INSP_APPL_DT" , "INSP_DT" , "INSP_FEE" , "INSPER_NM" , "INSPER_POSI" , "JUDGM" , "PLAN_CONFIRM_YN" , "SW_BEF_REPO_DELINUM" , "SW_DT" , "EW_DT" , "INSP_WISH_YMD" , "OFFI_TELNUM" , "OFFI_NM" , "USEBEFINSP_DELINUM" , "SUV" , "REMARK" , "CER_DELI_YN" , "PLAN_CONFIRM_REMARK" , "NAPPL_YN" , "NAPPL_CAUSE" , "DOC_INSP_REMARK" , "WRT_ID" , "INS_DT" , "UPD_DT" , "CIV_RECV_NUM" , "RECV_DT" , "PLAN_CONFIRM_PER_YN" , "PLAN_ENT_CHG_YN" , "PLAN_CONT_CHG_YN" , "RECV_NUM" , "ATT_DOC" , "DELI_DT" , "DEFI_YN" , "PROC_STE" , "ISSUE_ITEM" , "NET_RECV_YN" , "PROC_LIM" , "INSP_NUM" , "PROC_OFFI" , "PLAN_CONFIRM_PER_YN_CONT" , "PLAN_ENT_CHG_YN_CONT" , "PLAN_CONT_CHG_YN_CONT" , "CHG_INSP" , "INSP_ITEM" , "ETC_INSP_BAS" , "WORK_ITEM_ETC" , "UPD_DT_OLD" , "BACKUP_TRANS_DT" , "TAKE_TM" , "USER_NAME" , "MW_PPS_GETR_ID" , "OUTVARS" , "MW_AFR_SHTNM" , "MW_SE" , "MW_CODE_CN" , "TAKE_CONFRM_CODE" , "DEAL_SE" , "DEAL_CODE_CN" , "TAKE_SE" , "TAKE_CODE_CN" , "REAL_DEAL_YMD" , "MW_TAKE_NO" , "ETC1" , "ETC2" , "ETC3" , "BEF_PLANER_NAME" , "PROC_OFFI_ID" , "ADMIT_DT" };	

  public int insert( ValueObject  obj) throws SQLException{

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : insert() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

  StringBuffer sb = new StringBuffer();
  sb.append("insert into PT_UB_USEBEFORE ")
    .append(" ( SIDO_CODE,SIGUNGU_CODE,APPLPER_NM,APPLPER_REP,APPLPER_POSTNUM,APPLPER_ADDR,APPLPER_DETAILADDR,APPLPER_TELNUM,OPE_NAME,OPE_REP,OPE_TELNUM,COI_WRT_NUM,OPE_POSTNUM,OPE_ADDR,OPE_DETAILADDR,INSP_SPOT_NM,INSP_SPOT_POSTNUM,INSP_SPOT_ADDR,INSP_SPOT_DETAILADDR,PLANER_NM,WORK_ITEM,AREA,NUM_FL,USE,INSP_APPL_WORK,INSP_APPL_DT,INSP_DT,INSP_FEE,INSPER_NM,INSPER_POSI,JUDGM,PLAN_CONFIRM_YN,SW_BEF_REPO_DELINUM,SW_DT,EW_DT,INSP_WISH_YMD,OFFI_TELNUM,OFFI_NM,USEBEFINSP_DELINUM,SUV,REMARK,CER_DELI_YN,PLAN_CONFIRM_REMARK,NAPPL_YN,NAPPL_CAUSE,DOC_INSP_REMARK,WRT_ID,INS_DT,UPD_DT,CIV_RECV_NUM,RECV_DT,PLAN_CONFIRM_PER_YN,PLAN_ENT_CHG_YN,PLAN_CONT_CHG_YN,RECV_NUM,ATT_DOC,DELI_DT,DEFI_YN,PROC_STE,ISSUE_ITEM,NET_RECV_YN,PROC_LIM,INSP_NUM,PROC_OFFI,PLAN_CONFIRM_PER_YN_CONT,PLAN_ENT_CHG_YN_CONT,PLAN_CONT_CHG_YN_CONT,CHG_INSP,INSP_ITEM,ETC_INSP_BAS,WORK_ITEM_ETC,UPD_DT_OLD,BACKUP_TRANS_DT,TAKE_TM,USER_NAME,MW_PPS_GETR_ID,OUTVARS,MW_AFR_SHTNM,MW_SE,MW_CODE_CN,TAKE_CONFRM_CODE,DEAL_SE,DEAL_CODE_CN,TAKE_SE,TAKE_CODE_CN,REAL_DEAL_YMD,MW_TAKE_NO,ETC1,ETC2,ETC3,BEF_PLANER_NAME,PROC_OFFI_ID,ADMIT_DT ) ")
    .append(" values ( ")
      
           .append(toDB(entity.getSIDO_CODE()))
			.append(",")
           .append(toDB(entity.getSIGUNGU_CODE()))
			.append(",")
           .append(toDB(entity.getAPPLPER_NM()))
			.append(",")
           .append(toDB(entity.getAPPLPER_REP()))
			.append(",")
           .append(toDB(entity.getAPPLPER_POSTNUM()))
			.append(",")
           .append(toDB(entity.getAPPLPER_ADDR()))
			.append(",")
           .append(toDB(entity.getAPPLPER_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getAPPLPER_TELNUM()))
			.append(",")
           .append(toDB(entity.getOPE_NAME()))
			.append(",")
           .append(toDB(entity.getOPE_REP()))
			.append(",")
           .append(toDB(entity.getOPE_TELNUM()))
			.append(",")
           .append(toDB(entity.getCOI_WRT_NUM()))
			.append(",")
           .append(toDB(entity.getOPE_POSTNUM()))
			.append(",")
           .append(toDB(entity.getOPE_ADDR()))
			.append(",")
           .append(toDB(entity.getOPE_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_NM()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_POSTNUM()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_ADDR()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getPLANER_NM()))
			.append(",")
           .append(toDB(entity.getWORK_ITEM()))
			.append(",")
           .append(toDB(entity.getAREA()))
			.append(",")
           .append(toDB(entity.getNUM_FL()))
			.append(",")
           .append(toDB(entity.getUSE()))
			.append(",")
           .append(toDB(entity.getINSP_APPL_WORK()))
			.append(",")
           .append(toDB(entity.getINSP_APPL_DT()))
			.append(",")
           .append(toDB(entity.getINSP_DT()))
			.append(",")
           .append(toDB(entity.getINSP_FEE()))
			.append(",")
           .append(toDB(entity.getINSPER_NM()))
			.append(",")
           .append(toDB(entity.getINSPER_POSI()))
			.append(",")
           .append(toDB(entity.getJUDGM()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_YN()))
			.append(",")
           .append(toDB(entity.getSW_BEF_REPO_DELINUM()))
			.append(",")
           .append(toDB(entity.getSW_DT()))
			.append(",")
           .append(toDB(entity.getEW_DT()))
			.append(",")
           .append(toDB(entity.getINSP_WISH_YMD()))
			.append(",")
           .append(toDB(entity.getOFFI_TELNUM()))
			.append(",")
           .append(toDB(entity.getOFFI_NM()))
			.append(",")
           .append(toDB(entity.getUSEBEFINSP_DELINUM()))
			.append(",")
           .append(toDB(entity.getSUV()))
			.append(",")
           .append(toDB(entity.getREMARK()))
			.append(",")
           .append(toDB(entity.getCER_DELI_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_REMARK()))
			.append(",")
           .append(toDB(entity.getNAPPL_YN()))
			.append(",")
           .append(toDB(entity.getNAPPL_CAUSE()))
			.append(",")
           .append(toDB(entity.getDOC_INSP_REMARK()))
			.append(",")
           .append(toDB(entity.getWRT_ID()))
			.append(",")
           .append(toDB(entity.getINS_DT()))
			.append(",")
           .append(toDB(entity.getUPD_DT()))
			.append(",")
           .append(toDB(entity.getCIV_RECV_NUM()))
			.append(",")
           .append(toDB(entity.getRECV_DT()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_PER_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_ENT_CHG_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_CONT_CHG_YN()))
			.append(",")
           .append(toDB(entity.getRECV_NUM()))
			.append(",")
           .append(toDB(entity.getATT_DOC()))
			.append(",")
           .append(toDB(entity.getDELI_DT()))
			.append(",")
           .append(toDB(entity.getDEFI_YN()))
			.append(",")
           .append(toDB(entity.getPROC_STE()))
			.append(",")
           .append(toDB(entity.getISSUE_ITEM()))
			.append(",")
           .append(toDB(entity.getNET_RECV_YN()))
			.append(",")
           .append(toDB(entity.getPROC_LIM()))
			.append(",")
           .append(toDB(entity.getINSP_NUM()))
			.append(",")
           .append(toDB(entity.getPROC_OFFI()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_PER_YN_CONT()))
			.append(",")
           .append(toDB(entity.getPLAN_ENT_CHG_YN_CONT()))
			.append(",")
           .append(toDB(entity.getPLAN_CONT_CHG_YN_CONT()))
			.append(",")
           .append(toDB(entity.getCHG_INSP()))
			.append(",")
           .append(toDB(entity.getINSP_ITEM()))
			.append(",")
           .append(toDB(entity.getETC_INSP_BAS()))
			.append(",")
           .append(toDB(entity.getWORK_ITEM_ETC()))
			.append(",")
           .append(toDB(entity.getUPD_DT_OLD()))
			.append(",")
           .append(toDB(entity.getBACKUP_TRANS_DT()))
			.append(",")
           .append(toDB(entity.getTAKE_TM()))
			.append(",")
           .append(toDB(entity.getUSER_NAME()))
			.append(",")
           .append(toDB(entity.getMW_PPS_GETR_ID()))
			.append(",")
           .append(toDB(entity.getOUTVARS()))
			.append(",")
           .append(toDB(entity.getMW_AFR_SHTNM()))
			.append(",")
           .append(toDB(entity.getMW_SE()))
			.append(",")
           .append(toDB(entity.getMW_CODE_CN()))
			.append(",")
           .append(toDB(entity.getTAKE_CONFRM_CODE()))
			.append(",")
           .append(toDB(entity.getDEAL_SE()))
			.append(",")
           .append(toDB(entity.getDEAL_CODE_CN()))
			.append(",")
           .append(toDB(entity.getTAKE_SE()))
			.append(",")
           .append(toDB(entity.getTAKE_CODE_CN()))
			.append(",")
           .append(toDB(entity.getREAL_DEAL_YMD()))
			.append(",")
           .append(toDB(entity.getMW_TAKE_NO()))
			.append(",")
           .append(toDB(entity.getETC1()))
			.append(",")
           .append(toDB(entity.getETC2()))
			.append(",")
           .append(toDB(entity.getETC3()))
			.append(",")
           .append(toDB(entity.getBEF_PLANER_NAME()))
			.append(",")
           .append(toDB(entity.getPROC_OFFI_ID()))
			.append(",")
           .append(toDB(entity.getADMIT_DT()))
			
    .append(" ) ");

   KJFLog.sql(sb.toString());


   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

    int i=1;
	
    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;

   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }
    return result ;
  }



  public String insertSql( ValueObject  obj) throws SQLException{

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : insert() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;


  StringBuffer sb = new StringBuffer();
  sb.append("insert into PT_UB_USEBEFORE ")
    .append(" ( SIDO_CODE,SIGUNGU_CODE,APPLPER_NM,APPLPER_REP,APPLPER_POSTNUM,APPLPER_ADDR,APPLPER_DETAILADDR,APPLPER_TELNUM,OPE_NAME,OPE_REP,OPE_TELNUM,COI_WRT_NUM,OPE_POSTNUM,OPE_ADDR,OPE_DETAILADDR,INSP_SPOT_NM,INSP_SPOT_POSTNUM,INSP_SPOT_ADDR,INSP_SPOT_DETAILADDR,PLANER_NM,WORK_ITEM,AREA,NUM_FL,USE,INSP_APPL_WORK,INSP_APPL_DT,INSP_DT,INSP_FEE,INSPER_NM,INSPER_POSI,JUDGM,PLAN_CONFIRM_YN,SW_BEF_REPO_DELINUM,SW_DT,EW_DT,INSP_WISH_YMD,OFFI_TELNUM,OFFI_NM,USEBEFINSP_DELINUM,SUV,REMARK,CER_DELI_YN,PLAN_CONFIRM_REMARK,NAPPL_YN,NAPPL_CAUSE,DOC_INSP_REMARK,WRT_ID,INS_DT,UPD_DT,CIV_RECV_NUM,RECV_DT,PLAN_CONFIRM_PER_YN,PLAN_ENT_CHG_YN,PLAN_CONT_CHG_YN,RECV_NUM,ATT_DOC,DELI_DT,DEFI_YN,PROC_STE,ISSUE_ITEM,NET_RECV_YN,PROC_LIM,INSP_NUM,PROC_OFFI,PLAN_CONFIRM_PER_YN_CONT,PLAN_ENT_CHG_YN_CONT,PLAN_CONT_CHG_YN_CONT,CHG_INSP,INSP_ITEM,ETC_INSP_BAS,WORK_ITEM_ETC,UPD_DT_OLD,BACKUP_TRANS_DT,TAKE_TM,USER_NAME,MW_PPS_GETR_ID,OUTVARS,MW_AFR_SHTNM,MW_SE,MW_CODE_CN,TAKE_CONFRM_CODE,DEAL_SE,DEAL_CODE_CN,TAKE_SE,TAKE_CODE_CN,REAL_DEAL_YMD,MW_TAKE_NO,ETC1,ETC2,ETC3,BEF_PLANER_NAME,PROC_OFFI_ID,ADMIT_DT ) ")
    .append(" values ( ")
      
           .append(toDB(entity.getSIDO_CODE()))
			.append(",")
           .append(toDB(entity.getSIGUNGU_CODE()))
			.append(",")
           .append(toDB(entity.getAPPLPER_NM()))
			.append(",")
           .append(toDB(entity.getAPPLPER_REP()))
			.append(",")
           .append(toDB(entity.getAPPLPER_POSTNUM()))
			.append(",")
           .append(toDB(entity.getAPPLPER_ADDR()))
			.append(",")
           .append(toDB(entity.getAPPLPER_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getAPPLPER_TELNUM()))
			.append(",")
           .append(toDB(entity.getOPE_NAME()))
			.append(",")
           .append(toDB(entity.getOPE_REP()))
			.append(",")
           .append(toDB(entity.getOPE_TELNUM()))
			.append(",")
           .append(toDB(entity.getCOI_WRT_NUM()))
			.append(",")
           .append(toDB(entity.getOPE_POSTNUM()))
			.append(",")
           .append(toDB(entity.getOPE_ADDR()))
			.append(",")
           .append(toDB(entity.getOPE_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_NM()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_POSTNUM()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_ADDR()))
			.append(",")
           .append(toDB(entity.getINSP_SPOT_DETAILADDR()))
			.append(",")
           .append(toDB(entity.getPLANER_NM()))
			.append(",")
           .append(toDB(entity.getWORK_ITEM()))
			.append(",")
           .append(toDB(entity.getAREA()))
			.append(",")
           .append(toDB(entity.getNUM_FL()))
			.append(",")
           .append(toDB(entity.getUSE()))
			.append(",")
           .append(toDB(entity.getINSP_APPL_WORK()))
			.append(",")
           .append(toDB(entity.getINSP_APPL_DT()))
			.append(",")
           .append(toDB(entity.getINSP_DT()))
			.append(",")
           .append(toDB(entity.getINSP_FEE()))
			.append(",")
           .append(toDB(entity.getINSPER_NM()))
			.append(",")
           .append(toDB(entity.getINSPER_POSI()))
			.append(",")
           .append(toDB(entity.getJUDGM()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_YN()))
			.append(",")
           .append(toDB(entity.getSW_BEF_REPO_DELINUM()))
			.append(",")
           .append(toDB(entity.getSW_DT()))
			.append(",")
           .append(toDB(entity.getEW_DT()))
			.append(",")
           .append(toDB(entity.getINSP_WISH_YMD()))
			.append(",")
           .append(toDB(entity.getOFFI_TELNUM()))
			.append(",")
           .append(toDB(entity.getOFFI_NM()))
			.append(",")
           .append(toDB(entity.getUSEBEFINSP_DELINUM()))
			.append(",")
           .append(toDB(entity.getSUV()))
			.append(",")
           .append(toDB(entity.getREMARK()))
			.append(",")
           .append(toDB(entity.getCER_DELI_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_REMARK()))
			.append(",")
           .append(toDB(entity.getNAPPL_YN()))
			.append(",")
           .append(toDB(entity.getNAPPL_CAUSE()))
			.append(",")
           .append(toDB(entity.getDOC_INSP_REMARK()))
			.append(",")
           .append(toDB(entity.getWRT_ID()))
			.append(",")
           .append(toDB(entity.getINS_DT()))
			.append(",")
           .append(toDB(entity.getUPD_DT()))
			.append(",")
           .append(toDB(entity.getCIV_RECV_NUM()))
			.append(",")
           .append(toDB(entity.getRECV_DT()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_PER_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_ENT_CHG_YN()))
			.append(",")
           .append(toDB(entity.getPLAN_CONT_CHG_YN()))
			.append(",")
           .append(toDB(entity.getRECV_NUM()))
			.append(",")
           .append(toDB(entity.getATT_DOC()))
			.append(",")
           .append(toDB(entity.getDELI_DT()))
			.append(",")
           .append(toDB(entity.getDEFI_YN()))
			.append(",")
           .append(toDB(entity.getPROC_STE()))
			.append(",")
           .append(toDB(entity.getISSUE_ITEM()))
			.append(",")
           .append(toDB(entity.getNET_RECV_YN()))
			.append(",")
           .append(toDB(entity.getPROC_LIM()))
			.append(",")
           .append(toDB(entity.getINSP_NUM()))
			.append(",")
           .append(toDB(entity.getPROC_OFFI()))
			.append(",")
           .append(toDB(entity.getPLAN_CONFIRM_PER_YN_CONT()))
			.append(",")
           .append(toDB(entity.getPLAN_ENT_CHG_YN_CONT()))
			.append(",")
           .append(toDB(entity.getPLAN_CONT_CHG_YN_CONT()))
			.append(",")
           .append(toDB(entity.getCHG_INSP()))
			.append(",")
           .append(toDB(entity.getINSP_ITEM()))
			.append(",")
           .append(toDB(entity.getETC_INSP_BAS()))
			.append(",")
           .append(toDB(entity.getWORK_ITEM_ETC()))
			.append(",")
           .append(toDB(entity.getUPD_DT_OLD()))
			.append(",")
           .append(toDB(entity.getBACKUP_TRANS_DT()))
			.append(",")
           .append(toDB(entity.getTAKE_TM()))
			.append(",")
           .append(toDB(entity.getUSER_NAME()))
			.append(",")
           .append(toDB(entity.getMW_PPS_GETR_ID()))
			.append(",")
           .append(toDB(entity.getOUTVARS()))
			.append(",")
           .append(toDB(entity.getMW_AFR_SHTNM()))
			.append(",")
           .append(toDB(entity.getMW_SE()))
			.append(",")
           .append(toDB(entity.getMW_CODE_CN()))
			.append(",")
           .append(toDB(entity.getTAKE_CONFRM_CODE()))
			.append(",")
           .append(toDB(entity.getDEAL_SE()))
			.append(",")
           .append(toDB(entity.getDEAL_CODE_CN()))
			.append(",")
           .append(toDB(entity.getTAKE_SE()))
			.append(",")
           .append(toDB(entity.getTAKE_CODE_CN()))
			.append(",")
           .append(toDB(entity.getREAL_DEAL_YMD()))
			.append(",")
           .append(toDB(entity.getMW_TAKE_NO()))
			.append(",")
           .append(toDB(entity.getETC1()))
			.append(",")
           .append(toDB(entity.getETC2()))
			.append(",")
           .append(toDB(entity.getETC3()))
			.append(",")
           .append(toDB(entity.getBEF_PLANER_NAME()))
			.append(",")
           .append(toDB(entity.getPROC_OFFI_ID()))
			.append(",")
           .append(toDB(entity.getADMIT_DT()))
			
    .append(" ) ");



    return sb.toString() ;
  }
  
  public int  update( ValueObject obj) throws SQLException{


    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : update() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set ")
       
        .append("APPLPER_NM = ")
        .append(toDB(entity.getAPPLPER_NM())).append(",")
        .append("APPLPER_REP = ")
        .append(toDB(entity.getAPPLPER_REP())).append(",")
        .append("APPLPER_POSTNUM = ")
        .append(toDB(entity.getAPPLPER_POSTNUM())).append(",")
        .append("APPLPER_ADDR = ")
        .append(toDB(entity.getAPPLPER_ADDR())).append(",")
        .append("APPLPER_DETAILADDR = ")
        .append(toDB(entity.getAPPLPER_DETAILADDR())).append(",")
        .append("APPLPER_TELNUM = ")
        .append(toDB(entity.getAPPLPER_TELNUM())).append(",")
        .append("OPE_NAME = ")
        .append(toDB(entity.getOPE_NAME())).append(",")
        .append("OPE_REP = ")
        .append(toDB(entity.getOPE_REP())).append(",")
        .append("OPE_TELNUM = ")
        .append(toDB(entity.getOPE_TELNUM())).append(",")
        .append("COI_WRT_NUM = ")
        .append(toDB(entity.getCOI_WRT_NUM())).append(",")
        .append("OPE_POSTNUM = ")
        .append(toDB(entity.getOPE_POSTNUM())).append(",")
        .append("OPE_ADDR = ")
        .append(toDB(entity.getOPE_ADDR())).append(",")
        .append("OPE_DETAILADDR = ")
        .append(toDB(entity.getOPE_DETAILADDR())).append(",")
        .append("INSP_SPOT_NM = ")
        .append(toDB(entity.getINSP_SPOT_NM())).append(",")
        .append("INSP_SPOT_POSTNUM = ")
        .append(toDB(entity.getINSP_SPOT_POSTNUM())).append(",")
        .append("INSP_SPOT_ADDR = ")
        .append(toDB(entity.getINSP_SPOT_ADDR())).append(",")
        .append("INSP_SPOT_DETAILADDR = ")
        .append(toDB(entity.getINSP_SPOT_DETAILADDR())).append(",")
        .append("PLANER_NM = ")
        .append(toDB(entity.getPLANER_NM())).append(",")
        .append("WORK_ITEM = ")
        .append(toDB(entity.getWORK_ITEM())).append(",")
        .append("AREA = ")
        .append(toDB(entity.getAREA())).append(",")
        .append("NUM_FL = ")
        .append(toDB(entity.getNUM_FL())).append(",")
        .append("USE = ")
        .append(toDB(entity.getUSE())).append(",")
        .append("INSP_APPL_WORK = ")
        .append(toDB(entity.getINSP_APPL_WORK())).append(",")
        .append("INSP_APPL_DT = ")
        .append(toDB(entity.getINSP_APPL_DT())).append(",")
        .append("INSP_DT = ")
        .append(toDB(entity.getINSP_DT())).append(",")
        .append("INSP_FEE = ")
        .append(toDB(entity.getINSP_FEE())).append(",")
        .append("INSPER_NM = ")
        .append(toDB(entity.getINSPER_NM())).append(",")
        .append("INSPER_POSI = ")
        .append(toDB(entity.getINSPER_POSI())).append(",")
        .append("JUDGM = ")
        .append(toDB(entity.getJUDGM())).append(",")
        .append("PLAN_CONFIRM_YN = ")
        .append(toDB(entity.getPLAN_CONFIRM_YN())).append(",")
        .append("SW_BEF_REPO_DELINUM = ")
        .append(toDB(entity.getSW_BEF_REPO_DELINUM())).append(",")
        .append("SW_DT = ")
        .append(toDB(entity.getSW_DT())).append(",")
        .append("EW_DT = ")
        .append(toDB(entity.getEW_DT())).append(",")
        .append("INSP_WISH_YMD = ")
        .append(toDB(entity.getINSP_WISH_YMD())).append(",")
        .append("OFFI_TELNUM = ")
        .append(toDB(entity.getOFFI_TELNUM())).append(",")
        .append("OFFI_NM = ")
        .append(toDB(entity.getOFFI_NM())).append(",")
        .append("USEBEFINSP_DELINUM = ")
        .append(toDB(entity.getUSEBEFINSP_DELINUM())).append(",")
        .append("SUV = ")
        .append(toDB(entity.getSUV())).append(",")
        .append("REMARK = ")
        .append(toDB(entity.getREMARK())).append(",")
        .append("CER_DELI_YN = ")
        .append(toDB(entity.getCER_DELI_YN())).append(",")
        .append("PLAN_CONFIRM_REMARK = ")
        .append(toDB(entity.getPLAN_CONFIRM_REMARK())).append(",")
        .append("NAPPL_YN = ")
        .append(toDB(entity.getNAPPL_YN())).append(",")
        .append("NAPPL_CAUSE = ")
        .append(toDB(entity.getNAPPL_CAUSE())).append(",")
        .append("DOC_INSP_REMARK = ")
        .append(toDB(entity.getDOC_INSP_REMARK())).append(",")
        .append("WRT_ID = ")
        .append(toDB(entity.getWRT_ID())).append(",")
        .append("INS_DT = ")
        .append(toDB(entity.getINS_DT())).append(",")
        .append("UPD_DT = ")
        .append(toDB(entity.getUPD_DT())).append(",")
        .append("CIV_RECV_NUM = ")
        .append(toDB(entity.getCIV_RECV_NUM())).append(",")
        .append("RECV_DT = ")
        .append(toDB(entity.getRECV_DT())).append(",")
        .append("PLAN_CONFIRM_PER_YN = ")
        .append(toDB(entity.getPLAN_CONFIRM_PER_YN())).append(",")
        .append("PLAN_ENT_CHG_YN = ")
        .append(toDB(entity.getPLAN_ENT_CHG_YN())).append(",")
        .append("PLAN_CONT_CHG_YN = ")
        .append(toDB(entity.getPLAN_CONT_CHG_YN())).append(",")
        .append("ATT_DOC = ")
        .append(toDB(entity.getATT_DOC())).append(",")
        .append("DELI_DT = ")
        .append(toDB(entity.getDELI_DT())).append(",")
        .append("DEFI_YN = ")
        .append(toDB(entity.getDEFI_YN())).append(",")
        .append("PROC_STE = ")
        .append(toDB(entity.getPROC_STE())).append(",")
        .append("ISSUE_ITEM = ")
        .append(toDB(entity.getISSUE_ITEM())).append(",")
        .append("NET_RECV_YN = ")
        .append(toDB(entity.getNET_RECV_YN())).append(",")
        .append("PROC_LIM = ")
        .append(toDB(entity.getPROC_LIM())).append(",")
        .append("INSP_NUM = ")
        .append(toDB(entity.getINSP_NUM())).append(",")
        .append("PROC_OFFI = ")
        .append(toDB(entity.getPROC_OFFI())).append(",")
        .append("PLAN_CONFIRM_PER_YN_CONT = ")
        .append(toDB(entity.getPLAN_CONFIRM_PER_YN_CONT())).append(",")
        .append("PLAN_ENT_CHG_YN_CONT = ")
        .append(toDB(entity.getPLAN_ENT_CHG_YN_CONT())).append(",")
        .append("PLAN_CONT_CHG_YN_CONT = ")
        .append(toDB(entity.getPLAN_CONT_CHG_YN_CONT())).append(",")
        .append("CHG_INSP = ")
        .append(toDB(entity.getCHG_INSP())).append(",")
        .append("INSP_ITEM = ")
        .append(toDB(entity.getINSP_ITEM())).append(",")
        .append("ETC_INSP_BAS = ")
        .append(toDB(entity.getETC_INSP_BAS())).append(",")
        .append("WORK_ITEM_ETC = ")
        .append(toDB(entity.getWORK_ITEM_ETC())).append(",")
        .append("UPD_DT_OLD = ")
        .append(toDB(entity.getUPD_DT_OLD())).append(",")
        .append("BACKUP_TRANS_DT = ")
        .append(toDB(entity.getBACKUP_TRANS_DT())).append(",")
        .append("TAKE_TM = ")
        .append(toDB(entity.getTAKE_TM())).append(",")
        .append("USER_NAME = ")
        .append(toDB(entity.getUSER_NAME())).append(",")
        .append("MW_PPS_GETR_ID = ")
        .append(toDB(entity.getMW_PPS_GETR_ID())).append(",")
        .append("OUTVARS = ")
        .append(toDB(entity.getOUTVARS())).append(",")
        .append("MW_AFR_SHTNM = ")
        .append(toDB(entity.getMW_AFR_SHTNM())).append(",")
        .append("MW_SE = ")
        .append(toDB(entity.getMW_SE())).append(",")
        .append("MW_CODE_CN = ")
        .append(toDB(entity.getMW_CODE_CN())).append(",")
        .append("TAKE_CONFRM_CODE = ")
        .append(toDB(entity.getTAKE_CONFRM_CODE())).append(",")
        .append("DEAL_SE = ")
        .append(toDB(entity.getDEAL_SE())).append(",")
        .append("DEAL_CODE_CN = ")
        .append(toDB(entity.getDEAL_CODE_CN())).append(",")
        .append("TAKE_SE = ")
        .append(toDB(entity.getTAKE_SE())).append(",")
        .append("TAKE_CODE_CN = ")
        .append(toDB(entity.getTAKE_CODE_CN())).append(",")
        .append("REAL_DEAL_YMD = ")
        .append(toDB(entity.getREAL_DEAL_YMD())).append(",")
        .append("MW_TAKE_NO = ")
        .append(toDB(entity.getMW_TAKE_NO())).append(",")
        .append("ETC1 = ")
        .append(toDB(entity.getETC1())).append(",")
        .append("ETC2 = ")
        .append(toDB(entity.getETC2())).append(",")
        .append("ETC3 = ")
        .append(toDB(entity.getETC3())).append(",")
        .append("BEF_PLANER_NAME = ")
        .append(toDB(entity.getBEF_PLANER_NAME())).append(",")
        .append("PROC_OFFI_ID = ")
        .append(toDB(entity.getPROC_OFFI_ID())).append(",")
        .append("ADMIT_DT = ")
        .append(toDB(entity.getADMIT_DT()))
        .append(" where  1=1 ");
       
         sb.append(" and SIDO_CODE = ").append( toDB(entity.getSIDO_CODE()));
         
         sb.append(" and SIGUNGU_CODE = ").append( toDB(entity.getSIGUNGU_CODE()));
         
         sb.append(" and RECV_NUM = ").append( toDB(entity.getRECV_NUM()));
         

   KJFLog.sql(sb.toString());

   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int i=1;
	
    result =ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

    return result ;
  }


  public String  updateSql( ValueObject obj) throws SQLException{


    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : update() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;


    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set ")
       
        .append("APPLPER_NM = ")
        .append(toDB(entity.getAPPLPER_NM())).append(",")
        .append("APPLPER_REP = ")
        .append(toDB(entity.getAPPLPER_REP())).append(",")
        .append("APPLPER_POSTNUM = ")
        .append(toDB(entity.getAPPLPER_POSTNUM())).append(",")
        .append("APPLPER_ADDR = ")
        .append(toDB(entity.getAPPLPER_ADDR())).append(",")
        .append("APPLPER_DETAILADDR = ")
        .append(toDB(entity.getAPPLPER_DETAILADDR())).append(",")
        .append("APPLPER_TELNUM = ")
        .append(toDB(entity.getAPPLPER_TELNUM())).append(",")
        .append("OPE_NAME = ")
        .append(toDB(entity.getOPE_NAME())).append(",")
        .append("OPE_REP = ")
        .append(toDB(entity.getOPE_REP())).append(",")
        .append("OPE_TELNUM = ")
        .append(toDB(entity.getOPE_TELNUM())).append(",")
        .append("COI_WRT_NUM = ")
        .append(toDB(entity.getCOI_WRT_NUM())).append(",")
        .append("OPE_POSTNUM = ")
        .append(toDB(entity.getOPE_POSTNUM())).append(",")
        .append("OPE_ADDR = ")
        .append(toDB(entity.getOPE_ADDR())).append(",")
        .append("OPE_DETAILADDR = ")
        .append(toDB(entity.getOPE_DETAILADDR())).append(",")
        .append("INSP_SPOT_NM = ")
        .append(toDB(entity.getINSP_SPOT_NM())).append(",")
        .append("INSP_SPOT_POSTNUM = ")
        .append(toDB(entity.getINSP_SPOT_POSTNUM())).append(",")
        .append("INSP_SPOT_ADDR = ")
        .append(toDB(entity.getINSP_SPOT_ADDR())).append(",")
        .append("INSP_SPOT_DETAILADDR = ")
        .append(toDB(entity.getINSP_SPOT_DETAILADDR())).append(",")
        .append("PLANER_NM = ")
        .append(toDB(entity.getPLANER_NM())).append(",")
        .append("WORK_ITEM = ")
        .append(toDB(entity.getWORK_ITEM())).append(",")
        .append("AREA = ")
        .append(toDB(entity.getAREA())).append(",")
        .append("NUM_FL = ")
        .append(toDB(entity.getNUM_FL())).append(",")
        .append("USE = ")
        .append(toDB(entity.getUSE())).append(",")
        .append("INSP_APPL_WORK = ")
        .append(toDB(entity.getINSP_APPL_WORK())).append(",")
        .append("INSP_APPL_DT = ")
        .append(toDB(entity.getINSP_APPL_DT())).append(",")
        .append("INSP_DT = ")
        .append(toDB(entity.getINSP_DT())).append(",")
        .append("INSP_FEE = ")
        .append(toDB(entity.getINSP_FEE())).append(",")
        .append("INSPER_NM = ")
        .append(toDB(entity.getINSPER_NM())).append(",")
        .append("INSPER_POSI = ")
        .append(toDB(entity.getINSPER_POSI())).append(",")
        .append("JUDGM = ")
        .append(toDB(entity.getJUDGM())).append(",")
        .append("PLAN_CONFIRM_YN = ")
        .append(toDB(entity.getPLAN_CONFIRM_YN())).append(",")
        .append("SW_BEF_REPO_DELINUM = ")
        .append(toDB(entity.getSW_BEF_REPO_DELINUM())).append(",")
        .append("SW_DT = ")
        .append(toDB(entity.getSW_DT())).append(",")
        .append("EW_DT = ")
        .append(toDB(entity.getEW_DT())).append(",")
        .append("INSP_WISH_YMD = ")
        .append(toDB(entity.getINSP_WISH_YMD())).append(",")
        .append("OFFI_TELNUM = ")
        .append(toDB(entity.getOFFI_TELNUM())).append(",")
        .append("OFFI_NM = ")
        .append(toDB(entity.getOFFI_NM())).append(",")
        .append("USEBEFINSP_DELINUM = ")
        .append(toDB(entity.getUSEBEFINSP_DELINUM())).append(",")
        .append("SUV = ")
        .append(toDB(entity.getSUV())).append(",")
        .append("REMARK = ")
        .append(toDB(entity.getREMARK())).append(",")
        .append("CER_DELI_YN = ")
        .append(toDB(entity.getCER_DELI_YN())).append(",")
        .append("PLAN_CONFIRM_REMARK = ")
        .append(toDB(entity.getPLAN_CONFIRM_REMARK())).append(",")
        .append("NAPPL_YN = ")
        .append(toDB(entity.getNAPPL_YN())).append(",")
        .append("NAPPL_CAUSE = ")
        .append(toDB(entity.getNAPPL_CAUSE())).append(",")
        .append("DOC_INSP_REMARK = ")
        .append(toDB(entity.getDOC_INSP_REMARK())).append(",")
        .append("WRT_ID = ")
        .append(toDB(entity.getWRT_ID())).append(",")
        .append("INS_DT = ")
        .append(toDB(entity.getINS_DT())).append(",")
        .append("UPD_DT = ")
        .append(toDB(entity.getUPD_DT())).append(",")
        .append("CIV_RECV_NUM = ")
        .append(toDB(entity.getCIV_RECV_NUM())).append(",")
        .append("RECV_DT = ")
        .append(toDB(entity.getRECV_DT())).append(",")
        .append("PLAN_CONFIRM_PER_YN = ")
        .append(toDB(entity.getPLAN_CONFIRM_PER_YN())).append(",")
        .append("PLAN_ENT_CHG_YN = ")
        .append(toDB(entity.getPLAN_ENT_CHG_YN())).append(",")
        .append("PLAN_CONT_CHG_YN = ")
        .append(toDB(entity.getPLAN_CONT_CHG_YN())).append(",")
        .append("ATT_DOC = ")
        .append(toDB(entity.getATT_DOC())).append(",")
        .append("DELI_DT = ")
        .append(toDB(entity.getDELI_DT())).append(",")
        .append("DEFI_YN = ")
        .append(toDB(entity.getDEFI_YN())).append(",")
        .append("PROC_STE = ")
        .append(toDB(entity.getPROC_STE())).append(",")
        .append("ISSUE_ITEM = ")
        .append(toDB(entity.getISSUE_ITEM())).append(",")
        .append("NET_RECV_YN = ")
        .append(toDB(entity.getNET_RECV_YN())).append(",")
        .append("PROC_LIM = ")
        .append(toDB(entity.getPROC_LIM())).append(",")
        .append("INSP_NUM = ")
        .append(toDB(entity.getINSP_NUM())).append(",")
        .append("PROC_OFFI = ")
        .append(toDB(entity.getPROC_OFFI())).append(",")
        .append("PLAN_CONFIRM_PER_YN_CONT = ")
        .append(toDB(entity.getPLAN_CONFIRM_PER_YN_CONT())).append(",")
        .append("PLAN_ENT_CHG_YN_CONT = ")
        .append(toDB(entity.getPLAN_ENT_CHG_YN_CONT())).append(",")
        .append("PLAN_CONT_CHG_YN_CONT = ")
        .append(toDB(entity.getPLAN_CONT_CHG_YN_CONT())).append(",")
        .append("CHG_INSP = ")
        .append(toDB(entity.getCHG_INSP())).append(",")
        .append("INSP_ITEM = ")
        .append(toDB(entity.getINSP_ITEM())).append(",")
        .append("ETC_INSP_BAS = ")
        .append(toDB(entity.getETC_INSP_BAS())).append(",")
        .append("WORK_ITEM_ETC = ")
        .append(toDB(entity.getWORK_ITEM_ETC())).append(",")
        .append("UPD_DT_OLD = ")
        .append(toDB(entity.getUPD_DT_OLD())).append(",")
        .append("BACKUP_TRANS_DT = ")
        .append(toDB(entity.getBACKUP_TRANS_DT())).append(",")
        .append("TAKE_TM = ")
        .append(toDB(entity.getTAKE_TM())).append(",")
        .append("USER_NAME = ")
        .append(toDB(entity.getUSER_NAME())).append(",")
        .append("MW_PPS_GETR_ID = ")
        .append(toDB(entity.getMW_PPS_GETR_ID())).append(",")
        .append("OUTVARS = ")
        .append(toDB(entity.getOUTVARS())).append(",")
        .append("MW_AFR_SHTNM = ")
        .append(toDB(entity.getMW_AFR_SHTNM())).append(",")
        .append("MW_SE = ")
        .append(toDB(entity.getMW_SE())).append(",")
        .append("MW_CODE_CN = ")
        .append(toDB(entity.getMW_CODE_CN())).append(",")
        .append("TAKE_CONFRM_CODE = ")
        .append(toDB(entity.getTAKE_CONFRM_CODE())).append(",")
        .append("DEAL_SE = ")
        .append(toDB(entity.getDEAL_SE())).append(",")
        .append("DEAL_CODE_CN = ")
        .append(toDB(entity.getDEAL_CODE_CN())).append(",")
        .append("TAKE_SE = ")
        .append(toDB(entity.getTAKE_SE())).append(",")
        .append("TAKE_CODE_CN = ")
        .append(toDB(entity.getTAKE_CODE_CN())).append(",")
        .append("REAL_DEAL_YMD = ")
        .append(toDB(entity.getREAL_DEAL_YMD())).append(",")
        .append("MW_TAKE_NO = ")
        .append(toDB(entity.getMW_TAKE_NO())).append(",")
        .append("ETC1 = ")
        .append(toDB(entity.getETC1())).append(",")
        .append("ETC2 = ")
        .append(toDB(entity.getETC2())).append(",")
        .append("ETC3 = ")
        .append(toDB(entity.getETC3())).append(",")
        .append("BEF_PLANER_NAME = ")
        .append(toDB(entity.getBEF_PLANER_NAME())).append(",")
        .append("PROC_OFFI_ID = ")
        .append(toDB(entity.getPROC_OFFI_ID())).append(",")
        .append("ADMIT_DT = ")
        .append(toDB(entity.getADMIT_DT()))
        .append(" where  1=1 ");
       
         sb.append(" and SIDO_CODE = ").append( toDB(entity.getSIDO_CODE()));
         
         sb.append(" and SIGUNGU_CODE = ").append( toDB(entity.getSIGUNGU_CODE()));
         
         sb.append(" and RECV_NUM = ").append( toDB(entity.getRECV_NUM()));
         

    return sb.toString() ;
  }
  
  
  public static HashMap default_update_field= new HashMap(0);
  static{
     
  }

  ///////////////////////////////////////////////////////////////////////////////////
  //������ �ʵ常�� �����Ѵ�.
  public int updateModifiedOnly(ValueObject obj, String[] fields) throws SQLException{



    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : updateModifiedOnly() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;

	HashMap clobs = new HashMap();
	

	Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()));
     
	  sb.append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()));
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     

   KJFLog.sql( sb.toString());

    try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int k=1;
    for(int i=0 ; i < fields.length ; i++){
       if(clobs.containsKey(fields[i])){
    	   
    	   ps.setString(k++,(entity.getByName(fields[i])).toString() );
       }
    }

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

	return result ;
  }




  public String updateModifiedOnlySql(ValueObject obj, String[] fields) throws SQLException{



    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : updateModifiedOnly() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;


	HashMap clobs = new HashMap();
	

    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()));
     
	  sb.append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()));
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     

	return sb.toString() ;
  }


  ///////////////////////////////////////////////////////////////////////////////////
  //Ư���ʵ带 ������ ��ü �ʵ带 �����Ѵ�.
  public int updateExcludeOnly(ValueObject obj, String[] fields) throws SQLException{

	fields= KJFUtil.getDifferenceOfSets(default_fields, fields);

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : updateModifiedOnly() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;

	HashMap clobs = new HashMap();
	

	Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()));
     
	  sb.append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()));
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     

   KJFLog.sql( sb.toString());

    try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int k=1;
    for(int i=0 ; i < fields.length ; i++){
       if(clobs.containsKey(fields[i])){
    	   
    	   ps.setString(k++,(entity.getByName(fields[i])).toString() );
       }
    }

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

	return result ;
  }
  
  
   public String updateExcludeOnlySql(ValueObject obj, String[] fields) throws SQLException{

	fields= KJFUtil.getDifferenceOfSets(default_fields, fields);

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : updateModifiedOnly() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;


	HashMap clobs = new HashMap();
	


    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_UB_USEBEFORE  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()));
     
	  sb.append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()));
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     
     
     
	return sb.toString() ;
  }
  
  
  
  public int delete(ValueObject obj) throws SQLException{

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : delete() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    StringBuffer sb = new StringBuffer();
    sb.append("delete from PT_UB_USEBEFORE  where  1=1")
      
	  .append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()))
      
	  .append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()))
      
	  .append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()))
       ;

   KJFLog.sql(sb.toString());


   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

   return result;
  }

  public String deleteSql(ValueObject obj) throws SQLException{

    if((obj instanceof PT_UB_USEBEFOREEntity) == false){
        throw new  SQLException("DAO ����(1): PT_UB_USEBEFORE : delete() ");
    }
    PT_UB_USEBEFOREEntity entity = (PT_UB_USEBEFOREEntity)obj;


    StringBuffer sb = new StringBuffer();
    sb.append("delete from PT_UB_USEBEFORE  where  1=1")
      
	  .append(" and SIDO_CODE = ").append(toDB(entity.getSIDO_CODE()))
      
	  .append(" and SIGUNGU_CODE = ").append(toDB(entity.getSIGUNGU_CODE()))
      
	  .append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()))
       ;


   return sb.toString();
  }


}//Class End
