

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_HOM_VIEW_DAY_COUNT
*  ���̺� ���� :
*  ���̺� PK   :  
*               PAGE_ID
*  ���̺� �÷� :  
*               PAGE_ID:VARCHAR2(50):  
*               REG_DATE:VARCHAR2(12):  
*               D_01:NUMBER(22):  
*               D_02:NUMBER(22):  
*               D_03:NUMBER(22):  
*               D_04:NUMBER(22):  
*               D_05:NUMBER(22):  
*               D_06:NUMBER(22):  
*               D_07:NUMBER(22):  
*               D_08:NUMBER(22):  
*               D_09:NUMBER(22):  
*               D_10:NUMBER(22):  
*               D_11:NUMBER(22):  
*               D_12:NUMBER(22):  
*               D_13:NUMBER(22):  
*               D_14:NUMBER(22):  
*               D_15:NUMBER(22):  
*               D_16:NUMBER(22):  
*               D_17:NUMBER(22):  
*               D_18:NUMBER(22):  
*               D_19:NUMBER(22):  
*               D_20:NUMBER(22):  
*               D_21:NUMBER(22):  
*               D_22:NUMBER(22):  
*               D_23:NUMBER(22):  
*               D_24:NUMBER(22):  
*               D_25:NUMBER(22):  
*               D_26:NUMBER(22):  
*               D_27:NUMBER(22):  
*               D_28:NUMBER(22):  
*               D_29:NUMBER(22):  
*               D_30:NUMBER(22):  
*               D_31:NUMBER(22):  
*               MONTH_TOTAL:NUMBER(22):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_HOM_VIEW_DAY_COUNTHelper{

  final static public String PAGE_ID = "PAGE_ID";
  final static public String REG_DATE = "REG_DATE";
  final static public String D_01 = "D_01";
  final static public String D_02 = "D_02";
  final static public String D_03 = "D_03";
  final static public String D_04 = "D_04";
  final static public String D_05 = "D_05";
  final static public String D_06 = "D_06";
  final static public String D_07 = "D_07";
  final static public String D_08 = "D_08";
  final static public String D_09 = "D_09";
  final static public String D_10 = "D_10";
  final static public String D_11 = "D_11";
  final static public String D_12 = "D_12";
  final static public String D_13 = "D_13";
  final static public String D_14 = "D_14";
  final static public String D_15 = "D_15";
  final static public String D_16 = "D_16";
  final static public String D_17 = "D_17";
  final static public String D_18 = "D_18";
  final static public String D_19 = "D_19";
  final static public String D_20 = "D_20";
  final static public String D_21 = "D_21";
  final static public String D_22 = "D_22";
  final static public String D_23 = "D_23";
  final static public String D_24 = "D_24";
  final static public String D_25 = "D_25";
  final static public String D_26 = "D_26";
  final static public String D_27 = "D_27";
  final static public String D_28 = "D_28";
  final static public String D_29 = "D_29";
  final static public String D_30 = "D_30";
  final static public String D_31 = "D_31";
  final static public String MONTH_TOTAL = "MONTH_TOTAL";
  


  public static HashMap fieldMap = new HashMap(34);
  static{
  fieldMap.put(PAGE_ID,new Integer(1) );
  fieldMap.put(REG_DATE,new Integer(2) );
  fieldMap.put(D_01,new Integer(3) );
  fieldMap.put(D_02,new Integer(4) );
  fieldMap.put(D_03,new Integer(5) );
  fieldMap.put(D_04,new Integer(6) );
  fieldMap.put(D_05,new Integer(7) );
  fieldMap.put(D_06,new Integer(8) );
  fieldMap.put(D_07,new Integer(9) );
  fieldMap.put(D_08,new Integer(10) );
  fieldMap.put(D_09,new Integer(11) );
  fieldMap.put(D_10,new Integer(12) );
  fieldMap.put(D_11,new Integer(13) );
  fieldMap.put(D_12,new Integer(14) );
  fieldMap.put(D_13,new Integer(15) );
  fieldMap.put(D_14,new Integer(16) );
  fieldMap.put(D_15,new Integer(17) );
  fieldMap.put(D_16,new Integer(18) );
  fieldMap.put(D_17,new Integer(19) );
  fieldMap.put(D_18,new Integer(20) );
  fieldMap.put(D_19,new Integer(21) );
  fieldMap.put(D_20,new Integer(22) );
  fieldMap.put(D_21,new Integer(23) );
  fieldMap.put(D_22,new Integer(24) );
  fieldMap.put(D_23,new Integer(25) );
  fieldMap.put(D_24,new Integer(26) );
  fieldMap.put(D_25,new Integer(27) );
  fieldMap.put(D_26,new Integer(28) );
  fieldMap.put(D_27,new Integer(29) );
  fieldMap.put(D_28,new Integer(30) );
  fieldMap.put(D_29,new Integer(31) );
  fieldMap.put(D_30,new Integer(32) );
  fieldMap.put(D_31,new Integer(33) );
  fieldMap.put(MONTH_TOTAL,new Integer(34) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_HOM_VIEW_DAY_COUNT";
     final public static String PREFIX = "sp.dao.PT_HOM_VIEW_DAY_COUNT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       PAGE_ID };
     final public static String FIELD_LIST[] = { 
       PAGE_ID,REG_DATE,D_01,D_02,D_03,D_04,D_05,D_06,D_07,D_08,D_09,D_10,D_11,D_12,D_13,D_14,D_15,D_16,D_17,D_18,D_19,D_20,D_21,D_22,D_23,D_24,D_25,D_26,D_27,D_28,D_29,D_30,D_31,MONTH_TOTAL };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
             case 28 : 
	                  return  "";
             case 29 : 
	                  return  "";
             case 30 : 
	                  return  "";
             case 31 : 
	                  return  "";
             case 32 : 
	                  return  "";
             case 33 : 
	                  return  "";
             case 34 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_HOM_VIEW_DAY_COUNTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PAGE_ID").append("'")
            .append(" value='").append(""+ent.getPAGE_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REG_DATE").append("'")
            .append(" value='").append(""+ent.getREG_DATE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_01").append("'")
            .append(" value='").append(""+ent.getD_01()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_02").append("'")
            .append(" value='").append(""+ent.getD_02()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_03").append("'")
            .append(" value='").append(""+ent.getD_03()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_04").append("'")
            .append(" value='").append(""+ent.getD_04()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_05").append("'")
            .append(" value='").append(""+ent.getD_05()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_06").append("'")
            .append(" value='").append(""+ent.getD_06()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_07").append("'")
            .append(" value='").append(""+ent.getD_07()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_08").append("'")
            .append(" value='").append(""+ent.getD_08()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_09").append("'")
            .append(" value='").append(""+ent.getD_09()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_10").append("'")
            .append(" value='").append(""+ent.getD_10()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_11").append("'")
            .append(" value='").append(""+ent.getD_11()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_12").append("'")
            .append(" value='").append(""+ent.getD_12()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_13").append("'")
            .append(" value='").append(""+ent.getD_13()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_14").append("'")
            .append(" value='").append(""+ent.getD_14()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_15").append("'")
            .append(" value='").append(""+ent.getD_15()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_16").append("'")
            .append(" value='").append(""+ent.getD_16()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_17").append("'")
            .append(" value='").append(""+ent.getD_17()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_18").append("'")
            .append(" value='").append(""+ent.getD_18()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_19").append("'")
            .append(" value='").append(""+ent.getD_19()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_20").append("'")
            .append(" value='").append(""+ent.getD_20()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_21").append("'")
            .append(" value='").append(""+ent.getD_21()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_22").append("'")
            .append(" value='").append(""+ent.getD_22()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_23").append("'")
            .append(" value='").append(""+ent.getD_23()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_24").append("'")
            .append(" value='").append(""+ent.getD_24()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_25").append("'")
            .append(" value='").append(""+ent.getD_25()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_26").append("'")
            .append(" value='").append(""+ent.getD_26()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_27").append("'")
            .append(" value='").append(""+ent.getD_27()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_28").append("'")
            .append(" value='").append(""+ent.getD_28()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_29").append("'")
            .append(" value='").append(""+ent.getD_29()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_30").append("'")
            .append(" value='").append(""+ent.getD_30()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("D_31").append("'")
            .append(" value='").append(""+ent.getD_31()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MONTH_TOTAL").append("'")
            .append(" value='").append(""+ent.getMONTH_TOTAL()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
