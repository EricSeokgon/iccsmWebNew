

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_SIDO_CODE
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(4):  
*               SIDO_NM:VARCHAR2(20):  
*               SIGUNGU_NM:VARCHAR2(40):  
*               TEL:VARCHAR2(24):  
*               OFFPART:VARCHAR2(100):  
*               AREA_CODE:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               REMARK:VARCHAR2(255):  
*               HOME:VARCHAR2(128):  
*               ADDR:VARCHAR2(128):  
*               SIDO_CAPTAIN:VARCHAR2(40):  
*               SIDO_FULL_NM:VARCHAR2(50):  
*               SIDO_NM_CUT:VARCHAR2(10):  
*               SIGUNGU_NM_CUT:VARCHAR2(30):  
*               COI_WRT_NUM:VARCHAR2(4):  
*               NUM2:VARCHAR2(4):  
*               SIDO_SEQ:VARCHAR2(4):  
*               SIGUNGU_SEQ:VARCHAR2(5):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_SIDO_CODEHelper{

  final static public String SEQ = "SEQ";
  final static public String SIDO_NM = "SIDO_NM";
  final static public String SIGUNGU_NM = "SIGUNGU_NM";
  final static public String TEL = "TEL";
  final static public String OFFPART = "OFFPART";
  final static public String AREA_CODE = "AREA_CODE";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String REMARK = "REMARK";
  final static public String HOME = "HOME";
  final static public String ADDR = "ADDR";
  final static public String SIDO_CAPTAIN = "SIDO_CAPTAIN";
  final static public String SIDO_FULL_NM = "SIDO_FULL_NM";
  final static public String SIDO_NM_CUT = "SIDO_NM_CUT";
  final static public String SIGUNGU_NM_CUT = "SIGUNGU_NM_CUT";
  final static public String COI_WRT_NUM = "COI_WRT_NUM";
  final static public String NUM2 = "NUM2";
  final static public String SIDO_SEQ = "SIDO_SEQ";
  final static public String SIGUNGU_SEQ = "SIGUNGU_SEQ";
  


  public static HashMap fieldMap = new HashMap(20);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(SIDO_NM,new Integer(2) );
  fieldMap.put(SIGUNGU_NM,new Integer(3) );
  fieldMap.put(TEL,new Integer(4) );
  fieldMap.put(OFFPART,new Integer(5) );
  fieldMap.put(AREA_CODE,new Integer(6) );
  fieldMap.put(WRT_ID,new Integer(7) );
  fieldMap.put(INS_DT,new Integer(8) );
  fieldMap.put(UPD_DT,new Integer(9) );
  fieldMap.put(REMARK,new Integer(10) );
  fieldMap.put(HOME,new Integer(11) );
  fieldMap.put(ADDR,new Integer(12) );
  fieldMap.put(SIDO_CAPTAIN,new Integer(13) );
  fieldMap.put(SIDO_FULL_NM,new Integer(14) );
  fieldMap.put(SIDO_NM_CUT,new Integer(15) );
  fieldMap.put(SIGUNGU_NM_CUT,new Integer(16) );
  fieldMap.put(COI_WRT_NUM,new Integer(17) );
  fieldMap.put(NUM2,new Integer(18) );
  fieldMap.put(SIDO_SEQ,new Integer(19) );
  fieldMap.put(SIGUNGU_SEQ,new Integer(20) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_SIDO_CODE";
     final public static String PREFIX = "sp.dao.PT_SIDO_CODE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,SIDO_NM,SIGUNGU_NM,TEL,OFFPART,AREA_CODE,WRT_ID,INS_DT,UPD_DT,REMARK,HOME,ADDR,SIDO_CAPTAIN,SIDO_FULL_NM,SIDO_NM_CUT,SIGUNGU_NM_CUT,COI_WRT_NUM,NUM2,SIDO_SEQ,SIGUNGU_SEQ };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_SIDO_CODEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_NM").append("'")
            .append(" value='").append(""+ent.getSIDO_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_NM").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TEL").append("'")
            .append(" value='").append(""+ent.getTEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFPART").append("'")
            .append(" value='").append(""+ent.getOFFPART()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("AREA_CODE").append("'")
            .append(" value='").append(""+ent.getAREA_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REMARK").append("'")
            .append(" value='").append(""+ent.getREMARK()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("HOME").append("'")
            .append(" value='").append(""+ent.getHOME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR").append("'")
            .append(" value='").append(""+ent.getADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CAPTAIN").append("'")
            .append(" value='").append(""+ent.getSIDO_CAPTAIN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_FULL_NM").append("'")
            .append(" value='").append(""+ent.getSIDO_FULL_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_NM_CUT").append("'")
            .append(" value='").append(""+ent.getSIDO_NM_CUT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_NM_CUT").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_NM_CUT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COI_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getCOI_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NUM2").append("'")
            .append(" value='").append(""+ent.getNUM2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_SEQ").append("'")
            .append(" value='").append(""+ent.getSIDO_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_SEQ").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_SEQ()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
