

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_HMS_HISTORY
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(11):  
*               MENU_ID:VARCHAR2(32):  
*               VERSION:VARCHAR2(32):  
*               CONTENT:CLOB:  
*               USE_YN:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               WRT_NM:VARCHAR2(32):  
*               INS_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_HMS_HISTORYHelper{

  final static public String SEQ = "SEQ";
  final static public String MENU_ID = "MENU_ID";
  final static public String VERSION = "VERSION";
  final static public String CONTENT = "CONTENT";
  final static public String USE_YN = "USE_YN";
  final static public String WRT_ID = "WRT_ID";
  final static public String WRT_NM = "WRT_NM";
  final static public String INS_DT = "INS_DT";
  


  public static HashMap fieldMap = new HashMap(8);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(MENU_ID,new Integer(2) );
  fieldMap.put(VERSION,new Integer(3) );
  fieldMap.put(CONTENT,new Integer(4) );
  fieldMap.put(USE_YN,new Integer(5) );
  fieldMap.put(WRT_ID,new Integer(6) );
  fieldMap.put(WRT_NM,new Integer(7) );
  fieldMap.put(INS_DT,new Integer(8) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_HMS_HISTORY";
     final public static String PREFIX = "sp.dao.PT_HMS_HISTORY";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,MENU_ID,VERSION,CONTENT,USE_YN,WRT_ID,WRT_NM,INS_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_HMS_HISTORYEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MENU_ID").append("'")
            .append(" value='").append(""+ent.getMENU_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("VERSION").append("'")
            .append(" value='").append(""+ent.getVERSION()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONTENT").append("'")
            .append(" value='").append(""+ent.getCONTENT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USE_YN").append("'")
            .append(" value='").append(""+ent.getUSE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_NM").append("'")
            .append(" value='").append(""+ent.getWRT_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
