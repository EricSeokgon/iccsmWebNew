

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_COMPANY_DIAGNOSTIC
*  ���̺� ���� :
*  ���̺� PK   :  
*               CHGBRE_SEQ  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               CHGBRE_SEQ:VARCHAR2(4):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               DIAG_ORG_CODE:VARCHAR2(6):  
*               PAY_CAP:VARCHAR2(15):  
*               REA_CAP:VARCHAR2(15):  
*               TUP_AOM:VARCHAR2(15):  
*               TUP_CLASS_CODE:VARCHAR2(6):  
*               COMPANY_DIAG_CLASS_CODE:VARCHAR2(6):  
*               COMPANY_DIAG_BASDT:VARCHAR2(8):  
*               COMPANY_DIAG_ISSUEDT:VARCHAR2(8):  
*               DIAG_NM_NM:VARCHAR2(20):  
*               DIAG_NM_WRT_NUM:VARCHAR2(12):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_COMPANY_DIAGNOSTICHelper{

  final static public String CHGBRE_SEQ = "CHGBRE_SEQ";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String DIAG_ORG_CODE = "DIAG_ORG_CODE";
  final static public String PAY_CAP = "PAY_CAP";
  final static public String REA_CAP = "REA_CAP";
  final static public String TUP_AOM = "TUP_AOM";
  final static public String TUP_CLASS_CODE = "TUP_CLASS_CODE";
  final static public String COMPANY_DIAG_CLASS_CODE = "COMPANY_DIAG_CLASS_CODE";
  final static public String COMPANY_DIAG_BASDT = "COMPANY_DIAG_BASDT";
  final static public String COMPANY_DIAG_ISSUEDT = "COMPANY_DIAG_ISSUEDT";
  final static public String DIAG_NM_NM = "DIAG_NM_NM";
  final static public String DIAG_NM_WRT_NUM = "DIAG_NM_WRT_NUM";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  


  public static HashMap fieldMap = new HashMap(15);
  static{
  fieldMap.put(CHGBRE_SEQ,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(DIAG_ORG_CODE,new Integer(3) );
  fieldMap.put(PAY_CAP,new Integer(4) );
  fieldMap.put(REA_CAP,new Integer(5) );
  fieldMap.put(TUP_AOM,new Integer(6) );
  fieldMap.put(TUP_CLASS_CODE,new Integer(7) );
  fieldMap.put(COMPANY_DIAG_CLASS_CODE,new Integer(8) );
  fieldMap.put(COMPANY_DIAG_BASDT,new Integer(9) );
  fieldMap.put(COMPANY_DIAG_ISSUEDT,new Integer(10) );
  fieldMap.put(DIAG_NM_NM,new Integer(11) );
  fieldMap.put(DIAG_NM_WRT_NUM,new Integer(12) );
  fieldMap.put(WRT_ID,new Integer(13) );
  fieldMap.put(UPD_DT,new Integer(14) );
  fieldMap.put(INS_DT,new Integer(15) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_COMPANY_DIAGNOSTIC";
     final public static String PREFIX = "sp.dao.PT_R_COMPANY_DIAGNOSTIC";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM,DIAG_ORG_CODE,PAY_CAP,REA_CAP,TUP_AOM,TUP_CLASS_CODE,COMPANY_DIAG_CLASS_CODE,COMPANY_DIAG_BASDT,COMPANY_DIAG_ISSUEDT,DIAG_NM_NM,DIAG_NM_WRT_NUM,WRT_ID,UPD_DT,INS_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_COMPANY_DIAGNOSTICEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHGBRE_SEQ").append("'")
            .append(" value='").append(""+ent.getCHGBRE_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_ORG_CODE").append("'")
            .append(" value='").append(""+ent.getDIAG_ORG_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PAY_CAP").append("'")
            .append(" value='").append(""+ent.getPAY_CAP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REA_CAP").append("'")
            .append(" value='").append(""+ent.getREA_CAP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TUP_AOM").append("'")
            .append(" value='").append(""+ent.getTUP_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TUP_CLASS_CODE").append("'")
            .append(" value='").append(""+ent.getTUP_CLASS_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_CLASS_CODE").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_CLASS_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_BASDT").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_BASDT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_ISSUEDT").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_ISSUEDT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_NM_NM").append("'")
            .append(" value='").append(""+ent.getDIAG_NM_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_NM_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getDIAG_NM_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
