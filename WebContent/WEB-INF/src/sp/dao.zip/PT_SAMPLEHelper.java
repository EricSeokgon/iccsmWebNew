

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_SAMPLE
*  ���̺� ���� :
*  ���̺� PK   :  
*               REC_NUM  
*               REG_NUM
*  ���̺� �÷� :  
*               REC_NUM:VARCHAR2(32):  
*               REG_NUM:VARCHAR2(32):  
*               SC_CODE:VARCHAR2(2):  
*               SGG_CODE:VARCHAR2(2):  
*               REC_DATE:VARCHAR2(24):  
*               PRO_PERIOD:VARCHAR2(24):  
*               PRO_DUTY:VARCHAR2(16):  
*               PRO_REC_NUM:VARCHAR2(16):  
*               COMPANY_NM:VARCHAR2(32):  
*               APPLICANT:VARCHAR2(24):  
*               TEL:VARCHAR2(16):  
*               FAX:VARCHAR2(16):  
*               REMEMBRANCER:VARCHAR2(24):  
*               SSN1:NUMBER(6):  
*               SSN2:NUMBER(7):  
*               POST_CODE:VARCHAR2(8):  
*               ADDR:VARCHAR2(64):  
*               ADDR_ETC:VARCHAR2(64):  
*               PUBLIC_WORK:VARCHAR2(8):  
*               REP_NUM:VARCHAR2(32):  
*               REC_DUTY:VARCHAR2(24):  
*               REC_WRITE:VARCHAR2(16):  
*               REC_INS_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               UDP_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               NOTE:VARCHAR2(128):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_SAMPLEHelper{

  final static public String REC_NUM = "REC_NUM";
  final static public String REG_NUM = "REG_NUM";
  final static public String SC_CODE = "SC_CODE";
  final static public String SGG_CODE = "SGG_CODE";
  final static public String REC_DATE = "REC_DATE";
  final static public String PRO_PERIOD = "PRO_PERIOD";
  final static public String PRO_DUTY = "PRO_DUTY";
  final static public String PRO_REC_NUM = "PRO_REC_NUM";
  final static public String COMPANY_NM = "COMPANY_NM";
  final static public String APPLICANT = "APPLICANT";
  final static public String TEL = "TEL";
  final static public String FAX = "FAX";
  final static public String REMEMBRANCER = "REMEMBRANCER";
  final static public String SSN1 = "SSN1";
  final static public String SSN2 = "SSN2";
  final static public String POST_CODE = "POST_CODE";
  final static public String ADDR = "ADDR";
  final static public String ADDR_ETC = "ADDR_ETC";
  final static public String PUBLIC_WORK = "PUBLIC_WORK";
  final static public String REP_NUM = "REP_NUM";
  final static public String REC_DUTY = "REC_DUTY";
  final static public String REC_WRITE = "REC_WRITE";
  final static public String REC_INS_DT = "REC_INS_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UDP_DT = "UDP_DT";
  final static public String INS_DT = "INS_DT";
  final static public String NOTE = "NOTE";
  


  public static HashMap fieldMap = new HashMap(27);
  static{
  fieldMap.put(REC_NUM,new Integer(1) );
  fieldMap.put(REG_NUM,new Integer(2) );
  fieldMap.put(SC_CODE,new Integer(3) );
  fieldMap.put(SGG_CODE,new Integer(4) );
  fieldMap.put(REC_DATE,new Integer(5) );
  fieldMap.put(PRO_PERIOD,new Integer(6) );
  fieldMap.put(PRO_DUTY,new Integer(7) );
  fieldMap.put(PRO_REC_NUM,new Integer(8) );
  fieldMap.put(COMPANY_NM,new Integer(9) );
  fieldMap.put(APPLICANT,new Integer(10) );
  fieldMap.put(TEL,new Integer(11) );
  fieldMap.put(FAX,new Integer(12) );
  fieldMap.put(REMEMBRANCER,new Integer(13) );
  fieldMap.put(SSN1,new Integer(14) );
  fieldMap.put(SSN2,new Integer(15) );
  fieldMap.put(POST_CODE,new Integer(16) );
  fieldMap.put(ADDR,new Integer(17) );
  fieldMap.put(ADDR_ETC,new Integer(18) );
  fieldMap.put(PUBLIC_WORK,new Integer(19) );
  fieldMap.put(REP_NUM,new Integer(20) );
  fieldMap.put(REC_DUTY,new Integer(21) );
  fieldMap.put(REC_WRITE,new Integer(22) );
  fieldMap.put(REC_INS_DT,new Integer(23) );
  fieldMap.put(WRT_ID,new Integer(24) );
  fieldMap.put(UDP_DT,new Integer(25) );
  fieldMap.put(INS_DT,new Integer(26) );
  fieldMap.put(NOTE,new Integer(27) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_SAMPLE";
     final public static String PREFIX = "sp.dao.PT_SAMPLE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       REC_NUM,REG_NUM };
     final public static String FIELD_LIST[] = { 
       REC_NUM,REG_NUM,SC_CODE,SGG_CODE,REC_DATE,PRO_PERIOD,PRO_DUTY,PRO_REC_NUM,COMPANY_NM,APPLICANT,TEL,FAX,REMEMBRANCER,SSN1,SSN2,POST_CODE,ADDR,ADDR_ETC,PUBLIC_WORK,REP_NUM,REC_DUTY,REC_WRITE,REC_INS_DT,WRT_ID,UDP_DT,INS_DT,NOTE };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_SAMPLEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REC_NUM").append("'")
            .append(" value='").append(""+ent.getREC_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REG_NUM").append("'")
            .append(" value='").append(""+ent.getREG_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SC_CODE").append("'")
            .append(" value='").append(""+ent.getSC_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SGG_CODE").append("'")
            .append(" value='").append(""+ent.getSGG_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REC_DATE").append("'")
            .append(" value='").append(""+ent.getREC_DATE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PRO_PERIOD").append("'")
            .append(" value='").append(""+ent.getPRO_PERIOD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PRO_DUTY").append("'")
            .append(" value='").append(""+ent.getPRO_DUTY()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PRO_REC_NUM").append("'")
            .append(" value='").append(""+ent.getPRO_REC_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_NM").append("'")
            .append(" value='").append(""+ent.getCOMPANY_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("APPLICANT").append("'")
            .append(" value='").append(""+ent.getAPPLICANT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TEL").append("'")
            .append(" value='").append(""+ent.getTEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("FAX").append("'")
            .append(" value='").append(""+ent.getFAX()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REMEMBRANCER").append("'")
            .append(" value='").append(""+ent.getREMEMBRANCER()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SSN1").append("'")
            .append(" value='").append(""+ent.getSSN1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SSN2").append("'")
            .append(" value='").append(""+ent.getSSN2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("POST_CODE").append("'")
            .append(" value='").append(""+ent.getPOST_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR").append("'")
            .append(" value='").append(""+ent.getADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_ETC").append("'")
            .append(" value='").append(""+ent.getADDR_ETC()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PUBLIC_WORK").append("'")
            .append(" value='").append(""+ent.getPUBLIC_WORK()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NUM").append("'")
            .append(" value='").append(""+ent.getREP_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REC_DUTY").append("'")
            .append(" value='").append(""+ent.getREC_DUTY()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REC_WRITE").append("'")
            .append(" value='").append(""+ent.getREC_WRITE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REC_INS_DT").append("'")
            .append(" value='").append(""+ent.getREC_INS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UDP_DT").append("'")
            .append(" value='").append(""+ent.getUDP_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NOTE").append("'")
            .append(" value='").append(""+ent.getNOTE()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
