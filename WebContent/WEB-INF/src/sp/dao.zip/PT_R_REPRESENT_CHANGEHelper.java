

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_REPRESENT_CHANGE
*  ���̺� ���� :
*  ���̺� PK   :  
*               CHGBRE_SEQ  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               CHGBRE_SEQ:VARCHAR2(4):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               REP_SSN1:VARCHAR2(18):  
*               REP_SSN2:VARCHAR2(21):  
*               REP_NM_KOR:VARCHAR2(20):  
*               REP_NM_HAN:VARCHAR2(20):  
*               CHAR_REF_YN:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_REPRESENT_CHANGEHelper{

  final static public String CHGBRE_SEQ = "CHGBRE_SEQ";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String REP_SSN1 = "REP_SSN1";
  final static public String REP_SSN2 = "REP_SSN2";
  final static public String REP_NM_KOR = "REP_NM_KOR";
  final static public String REP_NM_HAN = "REP_NM_HAN";
  final static public String CHAR_REF_YN = "CHAR_REF_YN";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  


  public static HashMap fieldMap = new HashMap(10);
  static{
  fieldMap.put(CHGBRE_SEQ,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(REP_SSN1,new Integer(3) );
  fieldMap.put(REP_SSN2,new Integer(4) );
  fieldMap.put(REP_NM_KOR,new Integer(5) );
  fieldMap.put(REP_NM_HAN,new Integer(6) );
  fieldMap.put(CHAR_REF_YN,new Integer(7) );
  fieldMap.put(WRT_ID,new Integer(8) );
  fieldMap.put(UPD_DT,new Integer(9) );
  fieldMap.put(INS_DT,new Integer(10) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_REPRESENT_CHANGE";
     final public static String PREFIX = "sp.dao.PT_R_REPRESENT_CHANGE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM,REP_SSN1,REP_SSN2,REP_NM_KOR,REP_NM_HAN,CHAR_REF_YN,WRT_ID,UPD_DT,INS_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_REPRESENT_CHANGEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHGBRE_SEQ").append("'")
            .append(" value='").append(""+ent.getCHGBRE_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_SSN1").append("'")
            .append(" value='").append(""+ent.getREP_SSN1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_SSN2").append("'")
            .append(" value='").append(""+ent.getREP_SSN2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NM_KOR").append("'")
            .append(" value='").append(""+ent.getREP_NM_KOR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NM_HAN").append("'")
            .append(" value='").append(""+ent.getREP_NM_HAN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHAR_REF_YN").append("'")
            .append(" value='").append(""+ent.getCHAR_REF_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
