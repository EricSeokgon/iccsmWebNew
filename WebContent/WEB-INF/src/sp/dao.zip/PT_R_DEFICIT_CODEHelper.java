

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_DEFICIT_CODE
*  ���̺� ���� :
*  ���̺� PK   :  
*               DEFI_CODE  
*               DEFI_GROUP
*  ���̺� �÷� :  
*               DEFI_CODE:VARCHAR2(6):  
*               CONT:VARCHAR2(500):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               DEFI_GROUP:VARCHAR2(6):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_DEFICIT_CODEHelper{

  final static public String DEFI_CODE = "DEFI_CODE";
  final static public String CONT = "CONT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String DEFI_GROUP = "DEFI_GROUP";
  


  public static HashMap fieldMap = new HashMap(6);
  static{
  fieldMap.put(DEFI_CODE,new Integer(1) );
  fieldMap.put(CONT,new Integer(2) );
  fieldMap.put(WRT_ID,new Integer(3) );
  fieldMap.put(UPD_DT,new Integer(4) );
  fieldMap.put(INS_DT,new Integer(5) );
  fieldMap.put(DEFI_GROUP,new Integer(6) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_DEFICIT_CODE";
     final public static String PREFIX = "sp.dao.PT_R_DEFICIT_CODE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       DEFI_CODE,DEFI_GROUP };
     final public static String FIELD_LIST[] = { 
       DEFI_CODE,CONT,WRT_ID,UPD_DT,INS_DT,DEFI_GROUP };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_DEFICIT_CODEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DEFI_CODE").append("'")
            .append(" value='").append(""+ent.getDEFI_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONT").append("'")
            .append(" value='").append(""+ent.getCONT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DEFI_GROUP").append("'")
            .append(" value='").append(""+ent.getDEFI_GROUP()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
