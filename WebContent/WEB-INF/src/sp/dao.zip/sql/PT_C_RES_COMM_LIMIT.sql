
create table PT_C_RES_COMM_LIMIT(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    PGP_CAF NUMBER(10)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    PGP_PMS NUMBER(10)  , /* */
    NBS_4_CAF NUMBER(10)  , /* */
    NBS_4_PMS NUMBER(10)  , /* */
    NBS_6_CAF NUMBER(10)  , /* */
    NBS_6_PMS NUMBER(10)  , /* */
    NBS_7_CAF NUMBER(10)  , /* */
    NBS_7_PMS NUMBER(10)  , /* */
    NBS_8_CAF NUMBER(10)  , /* */
    NBS_9_PMS NUMBER(10)  , /* */
    NBS_9_CAF NUMBER(10)  , /* */
    NBS_8_PMS NUMBER(10)  , /* */
    TBS_TECOM_CAF NUMBER(10)  , /* */
    TBS_TECOM_PMS NUMBER(10)  , /* */
    TBS_EXCH_CAF NUMBER(10)  , /* */
    TBS_EXCH_PMS NUMBER(10)  , /* */
    PRIMARY KEY(SEQ)
   );
