
create table PT_C_RES_FIXING_FLAG(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    FIR_COMMIT_DT VARCHAR2(24)  , /* */
    USE VARCHAR2(50)  , /* */
    REMARK VARCHAR2(125)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    WATT VARCHAR2(12)  , /* */
    RE_ST_QTT NUMBER(10)  , /* */
    MO_ST_QTT NUMBER(10)  , /* */
    PRIMARY KEY(SEQ)
   );
