
create table PT_C_RES_ONLY_LINE(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    ITEM_NM VARCHAR2(100)  , /* */
    LINE_QTT NUMBER(20)  , /* */
    JOINT_CIR VARCHAR2(50)  , /* */
    JOINT_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    JOINT_ORG_NUM VARCHAR2(20)  , /* */
    PRIMARY KEY(SEQ)
   );
