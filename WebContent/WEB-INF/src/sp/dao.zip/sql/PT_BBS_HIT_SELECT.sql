
SELECT 
	CT_ID, BOARD_SEQ, IPADDR 
FROM   PT_BBS_HIT ;
                   
