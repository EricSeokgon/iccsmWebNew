
create table PT_C_RES_MOBILE_PHONE(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    SKT_QTT NUMBER(10)  , /* */
    SKT_AOM NUMBER(20)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    KTF_QTT NUMBER(10)  , /* */
    KTF_AOM NUMBER(20)  , /* */
    LGT_QTT NUMBER(10)  , /* */
    LGT_AOM NUMBER(20)  , /* */
    QTT_010 NUMBER(10)  , /* */
    AOM_010 NUMBER(20)  , /* */
    WATT VARCHAR2(12)  , /* */
    PRIMARY KEY(SEQ)
   );
