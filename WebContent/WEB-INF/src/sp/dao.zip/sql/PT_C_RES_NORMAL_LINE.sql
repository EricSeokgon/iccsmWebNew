
create table PT_C_RES_NORMAL_LINE(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    NOR_TEL NUMBER(10)  , /* */
    DID NUMBER(10)  , /* */
    DOD_INSIDE NUMBER(10)  , /* */
    REMARK VARCHAR2(125)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    DOD_SINGLE NUMBER(10)  , /* */
    PRIMARY KEY(SEQ)
   );
