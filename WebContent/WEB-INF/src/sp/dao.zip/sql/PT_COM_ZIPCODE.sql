
create table PT_COM_ZIPCODE(
    SEQ VARCHAR2(5)  , /* */
    ZIPCODE VARCHAR2(7)  , /* */
    SIDO VARCHAR2(6)  , /* */
    GUGUN VARCHAR2(30)  , /* */
    DONG VARCHAR2(100)  , /* */
    BUNJI VARCHAR2(30)  , /* */
    PRIMARY KEY()
   );
