
create table PT_C_RES_IPT(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    IPP_ITEM_NM VARCHAR2(100)  , /* */
    IPM_QTT NUMBER(10)  , /* */
    IPP_INSTAL_DT VARCHAR2(12)  , /* */
    IPP_ESTAB_AOM NUMBER(20)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    IPP_PDT VARCHAR2(100)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    IPM_PDT VARCHAR2(100)  , /* */
    IPM_ITEM_NM VARCHAR2(100)  , /* */
    IPM_ESTAB_AOM NUMBER(20)  , /* */
    PRIMARY KEY(SEQ)
   );
