

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_OTOB_COM_CODE
*  ���̺� ���� :
*  ���̺� PK   :  
*               OTOB_COM_CODE
*  ���̺� �÷� :  
*               OTOB_COM_CODE:VARCHAR2(6):  
*               OTOB_COM_TOB_CONT:VARCHAR2(50):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_OTOB_COM_CODEHelper{

  final static public String OTOB_COM_CODE = "OTOB_COM_CODE";
  final static public String OTOB_COM_TOB_CONT = "OTOB_COM_TOB_CONT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  


  public static HashMap fieldMap = new HashMap(5);
  static{
  fieldMap.put(OTOB_COM_CODE,new Integer(1) );
  fieldMap.put(OTOB_COM_TOB_CONT,new Integer(2) );
  fieldMap.put(WRT_ID,new Integer(3) );
  fieldMap.put(UPD_DT,new Integer(4) );
  fieldMap.put(INS_DT,new Integer(5) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_OTOB_COM_CODE";
     final public static String PREFIX = "sp.dao.PT_R_OTOB_COM_CODE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       OTOB_COM_CODE };
     final public static String FIELD_LIST[] = { 
       OTOB_COM_CODE,OTOB_COM_TOB_CONT,WRT_ID,UPD_DT,INS_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_OTOB_COM_CODEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OTOB_COM_CODE").append("'")
            .append(" value='").append(""+ent.getOTOB_COM_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OTOB_COM_TOB_CONT").append("'")
            .append(" value='").append(""+ent.getOTOB_COM_TOB_CONT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
