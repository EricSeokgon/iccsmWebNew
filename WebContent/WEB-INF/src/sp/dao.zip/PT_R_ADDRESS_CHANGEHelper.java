

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ADDRESS_CHANGE
*  ���̺� ���� :
*  ���̺� PK   :  
*               CHGBRE_SEQ  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               CHGBRE_SEQ:VARCHAR2(10):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(3):  
*               POST_NUM:VARCHAR2(6):  
*               ADDR:VARCHAR2(100):  
*               DETAIL_ADDR:VARCHAR2(100):  
*               OFFICE_AREA:VARCHAR2(10):  
*               TEL_NUM:VARCHAR2(20):  
*               FAX_NUM:VARCHAR2(20):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               ETC1:VARCHAR2(30):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_ADDRESS_CHANGEHelper{

  final static public String CHGBRE_SEQ = "CHGBRE_SEQ";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String POST_NUM = "POST_NUM";
  final static public String ADDR = "ADDR";
  final static public String DETAIL_ADDR = "DETAIL_ADDR";
  final static public String OFFICE_AREA = "OFFICE_AREA";
  final static public String TEL_NUM = "TEL_NUM";
  final static public String FAX_NUM = "FAX_NUM";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String ETC1 = "ETC1";
  


  public static HashMap fieldMap = new HashMap(13);
  static{
  fieldMap.put(CHGBRE_SEQ,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(SIDO_CODE,new Integer(3) );
  fieldMap.put(POST_NUM,new Integer(4) );
  fieldMap.put(ADDR,new Integer(5) );
  fieldMap.put(DETAIL_ADDR,new Integer(6) );
  fieldMap.put(OFFICE_AREA,new Integer(7) );
  fieldMap.put(TEL_NUM,new Integer(8) );
  fieldMap.put(FAX_NUM,new Integer(9) );
  fieldMap.put(WRT_ID,new Integer(10) );
  fieldMap.put(UPD_DT,new Integer(11) );
  fieldMap.put(INS_DT,new Integer(12) );
  fieldMap.put(ETC1,new Integer(13) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_ADDRESS_CHANGE";
     final public static String PREFIX = "sp.dao.PT_R_ADDRESS_CHANGE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       CHGBRE_SEQ,TMP_WRT_NUM,SIDO_CODE,POST_NUM,ADDR,DETAIL_ADDR,OFFICE_AREA,TEL_NUM,FAX_NUM,WRT_ID,UPD_DT,INS_DT,ETC1 };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_ADDRESS_CHANGEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHGBRE_SEQ").append("'")
            .append(" value='").append(""+ent.getCHGBRE_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("POST_NUM").append("'")
            .append(" value='").append(""+ent.getPOST_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR").append("'")
            .append(" value='").append(""+ent.getADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DETAIL_ADDR").append("'")
            .append(" value='").append(""+ent.getDETAIL_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFICE_AREA").append("'")
            .append(" value='").append(""+ent.getOFFICE_AREA()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TEL_NUM").append("'")
            .append(" value='").append(""+ent.getTEL_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("FAX_NUM").append("'")
            .append(" value='").append(""+ent.getFAX_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC1").append("'")
            .append(" value='").append(""+ent.getETC1()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
