

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_C_RES_MOBILE_PHONE
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(4):  
*               ORG_NM:VARCHAR2(52):  
*               SIDO_CODE:VARCHAR2(5):  
*               SKT_QTT:NUMBER(10):  
*               SKT_AOM:NUMBER(20):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(12):  
*               SIGUNGU_CODE:VARCHAR2(5):  
*               KTF_QTT:NUMBER(10):  
*               KTF_AOM:NUMBER(20):  
*               LGT_QTT:NUMBER(10):  
*               LGT_AOM:NUMBER(20):  
*               QTT_010:NUMBER(10):  
*               AOM_010:NUMBER(20):  
*               WATT:VARCHAR2(12):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_C_RES_MOBILE_PHONEHelper{

  final static public String SEQ = "SEQ";
  final static public String ORG_NM = "ORG_NM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String SKT_QTT = "SKT_QTT";
  final static public String SKT_AOM = "SKT_AOM";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String SIGUNGU_CODE = "SIGUNGU_CODE";
  final static public String KTF_QTT = "KTF_QTT";
  final static public String KTF_AOM = "KTF_AOM";
  final static public String LGT_QTT = "LGT_QTT";
  final static public String LGT_AOM = "LGT_AOM";
  final static public String QTT_010 = "QTT_010";
  final static public String AOM_010 = "AOM_010";
  final static public String WATT = "WATT";
  


  public static HashMap fieldMap = new HashMap(16);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(ORG_NM,new Integer(2) );
  fieldMap.put(SIDO_CODE,new Integer(3) );
  fieldMap.put(SKT_QTT,new Integer(4) );
  fieldMap.put(SKT_AOM,new Integer(5) );
  fieldMap.put(INS_DT,new Integer(6) );
  fieldMap.put(UPD_DT,new Integer(7) );
  fieldMap.put(WRT_ID,new Integer(8) );
  fieldMap.put(SIGUNGU_CODE,new Integer(9) );
  fieldMap.put(KTF_QTT,new Integer(10) );
  fieldMap.put(KTF_AOM,new Integer(11) );
  fieldMap.put(LGT_QTT,new Integer(12) );
  fieldMap.put(LGT_AOM,new Integer(13) );
  fieldMap.put(QTT_010,new Integer(14) );
  fieldMap.put(AOM_010,new Integer(15) );
  fieldMap.put(WATT,new Integer(16) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_C_RES_MOBILE_PHONE";
     final public static String PREFIX = "sp.dao.PT_C_RES_MOBILE_PHONE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,ORG_NM,SIDO_CODE,SKT_QTT,SKT_AOM,INS_DT,UPD_DT,WRT_ID,SIGUNGU_CODE,KTF_QTT,KTF_AOM,LGT_QTT,LGT_AOM,QTT_010,AOM_010,WATT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_C_RES_MOBILE_PHONEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ORG_NM").append("'")
            .append(" value='").append(""+ent.getORG_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SKT_QTT").append("'")
            .append(" value='").append(""+ent.getSKT_QTT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SKT_AOM").append("'")
            .append(" value='").append(""+ent.getSKT_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_CODE").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("KTF_QTT").append("'")
            .append(" value='").append(""+ent.getKTF_QTT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("KTF_AOM").append("'")
            .append(" value='").append(""+ent.getKTF_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LGT_QTT").append("'")
            .append(" value='").append(""+ent.getLGT_QTT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LGT_AOM").append("'")
            .append(" value='").append(""+ent.getLGT_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("QTT_010").append("'")
            .append(" value='").append(""+ent.getQTT_010()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("AOM_010").append("'")
            .append(" value='").append(""+ent.getAOM_010()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WATT").append("'")
            .append(" value='").append(""+ent.getWATT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
