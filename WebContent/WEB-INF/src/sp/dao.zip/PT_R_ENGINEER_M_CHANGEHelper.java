

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ENGINEER_M_CHANGE
*  ���̺� ���� :
*  ���̺� PK   :  
*               CARE_BOOK_ISSUE_NUM  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:VARCHAR2(12):  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(12):  
*               DT:VARCHAR2(24):  
*               CHG_ITEM:VARCHAR2(10):  
*               CHG_ITEMS:VARCHAR2(20):  
*               CONFIRM:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(24):  
*               ETC1:VARCHAR2(20):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_ENGINEER_M_CHANGEHelper{

  final static public String SEQ = "SEQ";
  final static public String CARE_BOOK_ISSUE_NUM = "CARE_BOOK_ISSUE_NUM";
  final static public String DT = "DT";
  final static public String CHG_ITEM = "CHG_ITEM";
  final static public String CHG_ITEMS = "CHG_ITEMS";
  final static public String CONFIRM = "CONFIRM";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_DT = "WRT_DT";
  final static public String ETC1 = "ETC1";
  


  public static HashMap fieldMap = new HashMap(10);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(CARE_BOOK_ISSUE_NUM,new Integer(2) );
  fieldMap.put(DT,new Integer(3) );
  fieldMap.put(CHG_ITEM,new Integer(4) );
  fieldMap.put(CHG_ITEMS,new Integer(5) );
  fieldMap.put(CONFIRM,new Integer(6) );
  fieldMap.put(WRT_ID,new Integer(7) );
  fieldMap.put(UPD_DT,new Integer(8) );
  fieldMap.put(WRT_DT,new Integer(9) );
  fieldMap.put(ETC1,new Integer(10) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_ENGINEER_M_CHANGE";
     final public static String PREFIX = "sp.dao.PT_R_ENGINEER_M_CHANGE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CARE_BOOK_ISSUE_NUM,SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,CARE_BOOK_ISSUE_NUM,DT,CHG_ITEM,CHG_ITEMS,CONFIRM,WRT_ID,UPD_DT,WRT_DT,ETC1 };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_ENGINEER_M_CHANGEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_ISSUE_NUM").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_ISSUE_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DT").append("'")
            .append(" value='").append(""+ent.getDT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHG_ITEM").append("'")
            .append(" value='").append(""+ent.getCHG_ITEM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CHG_ITEMS").append("'")
            .append(" value='").append(""+ent.getCHG_ITEMS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONFIRM").append("'")
            .append(" value='").append(""+ent.getCONFIRM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC1").append("'")
            .append(" value='").append(""+ent.getETC1()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
