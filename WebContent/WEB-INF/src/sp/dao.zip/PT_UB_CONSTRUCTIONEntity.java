

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_CONSTRUCTION
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE  
*               SIGUNGU_CODE
*  ���̺� �÷� :  
*               ORPE_NM:VARCHAR2(50):  
*               ORPE_TEL:VARCHAR2(24):  
*               ORPE_POSTNUM:VARCHAR2(16):  
*               ORPE_ADDR:VARCHAR2(64):  
*               ORPE_DETAILADDR:VARCHAR2(128):  
*               PLANER_NAME:VARCHAR2(100):  
*               PLANER_NM:VARCHAR2(50):  
*               PLANER_TEL:VARCHAR2(24):  
*               PLANER_POSTNUM:VARCHAR2(16):  
*               PLANER_ADDR:VARCHAR2(64):  
*               PLANER_DETAILADDR:VARCHAR2(128):  
*               RECV_DT:VARCHAR2(24):  
*               STRU_COMMIT_NUM:VARCHAR2(50):  
*               STRU_ADDR_POSTNUM:VARCHAR2(16):  
*               STRU_ADDR_ADDR:VARCHAR2(64):  
*               STRU_ADDR_DETAILADDR:VARCHAR2(128):  
*               USE:VARCHAR2(100):  
*               AREA:VARCHAR2(10):  
*               NUM_FL:VARCHAR2(200):  
*               WORK_ITEM:VARCHAR2(250):  
*               STE:VARCHAR2(5):  
*               SUV_APPL:VARCHAR2(25):  
*               CONFIRMER_NM:VARCHAR2(25):  
*               CONFIRMER_POSI:VARCHAR2(50):  
*               CONFIRMER_TEL:VARCHAR2(24):  
*               INSP_OPIN:VARCHAR2(200):  
*               PRE_ITEM:VARCHAR2(200):  
*               SW_BEF_REPO_DELINUM:VARCHAR2(40):  
*               REPO_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               CIV_RECV_NUM:VARCHAR2(20):  
*               SIDO_CODE:VARCHAR2(5):  
*               SIGUNGU_CODE:VARCHAR2(4):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               RECV_NUM:VARCHAR2(12):  
*               INSP_BAS:VARCHAR2(255):  
*               CER_DELI_NUM:VARCHAR2(26):  
*               CER_DELI_CONFIRM:VARCHAR2(15):  
*               INSP_APPL_DT:VARCHAR2(24):  
*               PROC_STE:VARCHAR2(4):  
*               CER_DELI_YN:VARCHAR2(4):  
*               PROC_OFFI_NM:VARCHAR2(20):  
*               WORK_ITEM_ETC:VARCHAR2(200):  
*               ETC_INSP_BAS:VARCHAR2(200):  
*               UPD_DT_OLD:VARCHAR2(24):  
*               BACKUP_TRANS_DT:VARCHAR2(24):  
*               CONFIRMER_OFFI_ID:VARCHAR2(20):  
*               CHG_INSP:VARCHAR2(1):  
*               STRU_INFO_BIGO:VARCHAR2(1):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_UB_CONSTRUCTIONEntity extends ValueObject{

  
     private String ORPE_NM;
  
     private String ORPE_TEL;
  
     private String ORPE_POSTNUM;
  
     private String ORPE_ADDR;
  
     private String ORPE_DETAILADDR;
  
     private String PLANER_NAME;
  
     private String PLANER_NM;
  
     private String PLANER_TEL;
  
     private String PLANER_POSTNUM;
  
     private String PLANER_ADDR;
  
     private String PLANER_DETAILADDR;
  
     private String RECV_DT;
  
     private String STRU_COMMIT_NUM;
  
     private String STRU_ADDR_POSTNUM;
  
     private String STRU_ADDR_ADDR;
  
     private String STRU_ADDR_DETAILADDR;
  
     private String USE;
  
     private String AREA;
  
     private String NUM_FL;
  
     private String WORK_ITEM;
  
     private String STE;
  
     private String SUV_APPL;
  
     private String CONFIRMER_NM;
  
     private String CONFIRMER_POSI;
  
     private String CONFIRMER_TEL;
  
     private String INSP_OPIN;
  
     private String PRE_ITEM;
  
     private String SW_BEF_REPO_DELINUM;
  
     private String REPO_DT;
  
     private String WRT_ID;
  
     private String CIV_RECV_NUM;
  
     private String SIDO_CODE;
  
     private String SIGUNGU_CODE;
  
     private String INS_DT;
  
     private String UPD_DT;
  
     private String RECV_NUM;
  
     private String INSP_BAS;
  
     private String CER_DELI_NUM;
  
     private String CER_DELI_CONFIRM;
  
     private String INSP_APPL_DT;
  
     private String PROC_STE;
  
     private String CER_DELI_YN;
  
     private String PROC_OFFI_NM;
  
     private String WORK_ITEM_ETC;
  
     private String ETC_INSP_BAS;
  
     private String UPD_DT_OLD;
  
     private String BACKUP_TRANS_DT;
  
     private String CONFIRMER_OFFI_ID;
  
     private String CHG_INSP;
  
     private String STRU_INFO_BIGO;
  

//�����ڸ� �����
    public PT_UB_CONSTRUCTIONEntity(){
    }
    
    
    public PT_UB_CONSTRUCTIONEntity(String RECV_NUM,String SIDO_CODE,String SIGUNGU_CODE ){
       this.setRECV_NUM(RECV_NUM);
       this.setSIDO_CODE(SIDO_CODE);
       this.setSIGUNGU_CODE(SIGUNGU_CODE);
       
    }
      
    public PT_UB_CONSTRUCTIONEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("RECV_NUM");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("RECV_NUM",value);
       
       value = ent.getByName("SIDO_CODE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SIDO_CODE",value);
       
       value = ent.getByName("SIGUNGU_CODE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SIGUNGU_CODE",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.ORPE_NM =request.getParameter("ORPE_NM");
		this.ORPE_TEL =request.getParameter("ORPE_TEL");
		this.ORPE_POSTNUM =request.getParameter("ORPE_POSTNUM");
		this.ORPE_ADDR =request.getParameter("ORPE_ADDR");
		this.ORPE_DETAILADDR =request.getParameter("ORPE_DETAILADDR");
		this.PLANER_NAME =request.getParameter("PLANER_NAME");
		this.PLANER_NM =request.getParameter("PLANER_NM");
		this.PLANER_TEL =request.getParameter("PLANER_TEL");
		this.PLANER_POSTNUM =request.getParameter("PLANER_POSTNUM");
		this.PLANER_ADDR =request.getParameter("PLANER_ADDR");
		this.PLANER_DETAILADDR =request.getParameter("PLANER_DETAILADDR");
		this.RECV_DT =request.getParameter("RECV_DT");
		this.STRU_COMMIT_NUM =request.getParameter("STRU_COMMIT_NUM");
		this.STRU_ADDR_POSTNUM =request.getParameter("STRU_ADDR_POSTNUM");
		this.STRU_ADDR_ADDR =request.getParameter("STRU_ADDR_ADDR");
		this.STRU_ADDR_DETAILADDR =request.getParameter("STRU_ADDR_DETAILADDR");
		this.USE =request.getParameter("USE");
		this.AREA =request.getParameter("AREA");
		this.NUM_FL =request.getParameter("NUM_FL");
		this.WORK_ITEM =request.getParameter("WORK_ITEM");
		this.STE =request.getParameter("STE");
		this.SUV_APPL =request.getParameter("SUV_APPL");
		this.CONFIRMER_NM =request.getParameter("CONFIRMER_NM");
		this.CONFIRMER_POSI =request.getParameter("CONFIRMER_POSI");
		this.CONFIRMER_TEL =request.getParameter("CONFIRMER_TEL");
		this.INSP_OPIN =request.getParameter("INSP_OPIN");
		this.PRE_ITEM =request.getParameter("PRE_ITEM");
		this.SW_BEF_REPO_DELINUM =request.getParameter("SW_BEF_REPO_DELINUM");
		this.REPO_DT =request.getParameter("REPO_DT");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.CIV_RECV_NUM =request.getParameter("CIV_RECV_NUM");
		this.SIDO_CODE =request.getParameter("SIDO_CODE");
		this.SIGUNGU_CODE =request.getParameter("SIGUNGU_CODE");
		this.INS_DT =request.getParameter("INS_DT");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.RECV_NUM =request.getParameter("RECV_NUM");
		this.INSP_BAS =request.getParameter("INSP_BAS");
		this.CER_DELI_NUM =request.getParameter("CER_DELI_NUM");
		this.CER_DELI_CONFIRM =request.getParameter("CER_DELI_CONFIRM");
		this.INSP_APPL_DT =request.getParameter("INSP_APPL_DT");
		this.PROC_STE =request.getParameter("PROC_STE");
		this.CER_DELI_YN =request.getParameter("CER_DELI_YN");
		this.PROC_OFFI_NM =request.getParameter("PROC_OFFI_NM");
		this.WORK_ITEM_ETC =request.getParameter("WORK_ITEM_ETC");
		this.ETC_INSP_BAS =request.getParameter("ETC_INSP_BAS");
		this.UPD_DT_OLD =request.getParameter("UPD_DT_OLD");
		this.BACKUP_TRANS_DT =request.getParameter("BACKUP_TRANS_DT");
		this.CONFIRMER_OFFI_ID =request.getParameter("CONFIRMER_OFFI_ID");
		this.CHG_INSP =request.getParameter("CHG_INSP");
		this.STRU_INFO_BIGO =request.getParameter("STRU_INFO_BIGO");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.ORPE_NM =KJFMi.dsGet(ds, arg_row, "ORPE_NM");
		this.ORPE_TEL =KJFMi.dsGet(ds, arg_row, "ORPE_TEL");
		this.ORPE_POSTNUM =KJFMi.dsGet(ds, arg_row, "ORPE_POSTNUM");
		this.ORPE_ADDR =KJFMi.dsGet(ds, arg_row, "ORPE_ADDR");
		this.ORPE_DETAILADDR =KJFMi.dsGet(ds, arg_row, "ORPE_DETAILADDR");
		this.PLANER_NAME =KJFMi.dsGet(ds, arg_row, "PLANER_NAME");
		this.PLANER_NM =KJFMi.dsGet(ds, arg_row, "PLANER_NM");
		this.PLANER_TEL =KJFMi.dsGet(ds, arg_row, "PLANER_TEL");
		this.PLANER_POSTNUM =KJFMi.dsGet(ds, arg_row, "PLANER_POSTNUM");
		this.PLANER_ADDR =KJFMi.dsGet(ds, arg_row, "PLANER_ADDR");
		this.PLANER_DETAILADDR =KJFMi.dsGet(ds, arg_row, "PLANER_DETAILADDR");
		this.RECV_DT =KJFMi.dsGet(ds, arg_row, "RECV_DT");
		this.STRU_COMMIT_NUM =KJFMi.dsGet(ds, arg_row, "STRU_COMMIT_NUM");
		this.STRU_ADDR_POSTNUM =KJFMi.dsGet(ds, arg_row, "STRU_ADDR_POSTNUM");
		this.STRU_ADDR_ADDR =KJFMi.dsGet(ds, arg_row, "STRU_ADDR_ADDR");
		this.STRU_ADDR_DETAILADDR =KJFMi.dsGet(ds, arg_row, "STRU_ADDR_DETAILADDR");
		this.USE =KJFMi.dsGet(ds, arg_row, "USE");
		this.AREA =KJFMi.dsGet(ds, arg_row, "AREA");
		this.NUM_FL =KJFMi.dsGet(ds, arg_row, "NUM_FL");
		this.WORK_ITEM =KJFMi.dsGet(ds, arg_row, "WORK_ITEM");
		this.STE =KJFMi.dsGet(ds, arg_row, "STE");
		this.SUV_APPL =KJFMi.dsGet(ds, arg_row, "SUV_APPL");
		this.CONFIRMER_NM =KJFMi.dsGet(ds, arg_row, "CONFIRMER_NM");
		this.CONFIRMER_POSI =KJFMi.dsGet(ds, arg_row, "CONFIRMER_POSI");
		this.CONFIRMER_TEL =KJFMi.dsGet(ds, arg_row, "CONFIRMER_TEL");
		this.INSP_OPIN =KJFMi.dsGet(ds, arg_row, "INSP_OPIN");
		this.PRE_ITEM =KJFMi.dsGet(ds, arg_row, "PRE_ITEM");
		this.SW_BEF_REPO_DELINUM =KJFMi.dsGet(ds, arg_row, "SW_BEF_REPO_DELINUM");
		this.REPO_DT =KJFMi.dsGet(ds, arg_row, "REPO_DT");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.CIV_RECV_NUM =KJFMi.dsGet(ds, arg_row, "CIV_RECV_NUM");
		this.SIDO_CODE =KJFMi.dsGet(ds, arg_row, "SIDO_CODE");
		this.SIGUNGU_CODE =KJFMi.dsGet(ds, arg_row, "SIGUNGU_CODE");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.RECV_NUM =KJFMi.dsGet(ds, arg_row, "RECV_NUM");
		this.INSP_BAS =KJFMi.dsGet(ds, arg_row, "INSP_BAS");
		this.CER_DELI_NUM =KJFMi.dsGet(ds, arg_row, "CER_DELI_NUM");
		this.CER_DELI_CONFIRM =KJFMi.dsGet(ds, arg_row, "CER_DELI_CONFIRM");
		this.INSP_APPL_DT =KJFMi.dsGet(ds, arg_row, "INSP_APPL_DT");
		this.PROC_STE =KJFMi.dsGet(ds, arg_row, "PROC_STE");
		this.CER_DELI_YN =KJFMi.dsGet(ds, arg_row, "CER_DELI_YN");
		this.PROC_OFFI_NM =KJFMi.dsGet(ds, arg_row, "PROC_OFFI_NM");
		this.WORK_ITEM_ETC =KJFMi.dsGet(ds, arg_row, "WORK_ITEM_ETC");
		this.ETC_INSP_BAS =KJFMi.dsGet(ds, arg_row, "ETC_INSP_BAS");
		this.UPD_DT_OLD =KJFMi.dsGet(ds, arg_row, "UPD_DT_OLD");
		this.BACKUP_TRANS_DT =KJFMi.dsGet(ds, arg_row, "BACKUP_TRANS_DT");
		this.CONFIRMER_OFFI_ID =KJFMi.dsGet(ds, arg_row, "CONFIRMER_OFFI_ID");
		this.CHG_INSP =KJFMi.dsGet(ds, arg_row, "CHG_INSP");
		this.STRU_INFO_BIGO =KJFMi.dsGet(ds, arg_row, "STRU_INFO_BIGO");
				
    }    
    
//Getter �Լ��� �����
  
     public String getORPE_NM(){
             return ORPE_NM;
     };
  
     public String getORPE_TEL(){
             return ORPE_TEL;
     };
  
     public String getORPE_POSTNUM(){
             return ORPE_POSTNUM;
     };
  
     public String getORPE_ADDR(){
             return ORPE_ADDR;
     };
  
     public String getORPE_DETAILADDR(){
             return ORPE_DETAILADDR;
     };
  
     public String getPLANER_NAME(){
             return PLANER_NAME;
     };
  
     public String getPLANER_NM(){
             return PLANER_NM;
     };
  
     public String getPLANER_TEL(){
             return PLANER_TEL;
     };
  
     public String getPLANER_POSTNUM(){
             return PLANER_POSTNUM;
     };
  
     public String getPLANER_ADDR(){
             return PLANER_ADDR;
     };
  
     public String getPLANER_DETAILADDR(){
             return PLANER_DETAILADDR;
     };
  
     public String getRECV_DT(){
             return RECV_DT;
     };
  
     public String getSTRU_COMMIT_NUM(){
             return STRU_COMMIT_NUM;
     };
  
     public String getSTRU_ADDR_POSTNUM(){
             return STRU_ADDR_POSTNUM;
     };
  
     public String getSTRU_ADDR_ADDR(){
             return STRU_ADDR_ADDR;
     };
  
     public String getSTRU_ADDR_DETAILADDR(){
             return STRU_ADDR_DETAILADDR;
     };
  
     public String getUSE(){
             return USE;
     };
  
     public String getAREA(){
             return AREA;
     };
  
     public String getNUM_FL(){
             return NUM_FL;
     };
  
     public String getWORK_ITEM(){
             return WORK_ITEM;
     };
  
     public String getSTE(){
             return STE;
     };
  
     public String getSUV_APPL(){
             return SUV_APPL;
     };
  
     public String getCONFIRMER_NM(){
             return CONFIRMER_NM;
     };
  
     public String getCONFIRMER_POSI(){
             return CONFIRMER_POSI;
     };
  
     public String getCONFIRMER_TEL(){
             return CONFIRMER_TEL;
     };
  
     public String getINSP_OPIN(){
             return INSP_OPIN;
     };
  
     public String getPRE_ITEM(){
             return PRE_ITEM;
     };
  
     public String getSW_BEF_REPO_DELINUM(){
             return SW_BEF_REPO_DELINUM;
     };
  
     public String getREPO_DT(){
             return REPO_DT;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getCIV_RECV_NUM(){
             return CIV_RECV_NUM;
     };
  
     public String getSIDO_CODE(){
             return SIDO_CODE;
     };
  
     public String getSIGUNGU_CODE(){
             return SIGUNGU_CODE;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getRECV_NUM(){
             return RECV_NUM;
     };
  
     public String getINSP_BAS(){
             return INSP_BAS;
     };
  
     public String getCER_DELI_NUM(){
             return CER_DELI_NUM;
     };
  
     public String getCER_DELI_CONFIRM(){
             return CER_DELI_CONFIRM;
     };
  
     public String getINSP_APPL_DT(){
             return INSP_APPL_DT;
     };
  
     public String getPROC_STE(){
             return PROC_STE;
     };
  
     public String getCER_DELI_YN(){
             return CER_DELI_YN;
     };
  
     public String getPROC_OFFI_NM(){
             return PROC_OFFI_NM;
     };
  
     public String getWORK_ITEM_ETC(){
             return WORK_ITEM_ETC;
     };
  
     public String getETC_INSP_BAS(){
             return ETC_INSP_BAS;
     };
  
     public String getUPD_DT_OLD(){
             return UPD_DT_OLD;
     };
  
     public String getBACKUP_TRANS_DT(){
             return BACKUP_TRANS_DT;
     };
  
     public String getCONFIRMER_OFFI_ID(){
             return CONFIRMER_OFFI_ID;
     };
  
     public String getCHG_INSP(){
             return CHG_INSP;
     };
  
     public String getSTRU_INFO_BIGO(){
             return STRU_INFO_BIGO;
     };
  

//Setter �Լ��� �����
  
     public void setORPE_NM(String ORPE_NM){
            this.ORPE_NM=ORPE_NM;
     };
  
     public void setORPE_TEL(String ORPE_TEL){
            this.ORPE_TEL=ORPE_TEL;
     };
  
     public void setORPE_POSTNUM(String ORPE_POSTNUM){
            this.ORPE_POSTNUM=ORPE_POSTNUM;
     };
  
     public void setORPE_ADDR(String ORPE_ADDR){
            this.ORPE_ADDR=ORPE_ADDR;
     };
  
     public void setORPE_DETAILADDR(String ORPE_DETAILADDR){
            this.ORPE_DETAILADDR=ORPE_DETAILADDR;
     };
  
     public void setPLANER_NAME(String PLANER_NAME){
            this.PLANER_NAME=PLANER_NAME;
     };
  
     public void setPLANER_NM(String PLANER_NM){
            this.PLANER_NM=PLANER_NM;
     };
  
     public void setPLANER_TEL(String PLANER_TEL){
            this.PLANER_TEL=PLANER_TEL;
     };
  
     public void setPLANER_POSTNUM(String PLANER_POSTNUM){
            this.PLANER_POSTNUM=PLANER_POSTNUM;
     };
  
     public void setPLANER_ADDR(String PLANER_ADDR){
            this.PLANER_ADDR=PLANER_ADDR;
     };
  
     public void setPLANER_DETAILADDR(String PLANER_DETAILADDR){
            this.PLANER_DETAILADDR=PLANER_DETAILADDR;
     };
  
     public void setRECV_DT(String RECV_DT){
            this.RECV_DT=RECV_DT;
     };
  
     public void setSTRU_COMMIT_NUM(String STRU_COMMIT_NUM){
            this.STRU_COMMIT_NUM=STRU_COMMIT_NUM;
     };
  
     public void setSTRU_ADDR_POSTNUM(String STRU_ADDR_POSTNUM){
            this.STRU_ADDR_POSTNUM=STRU_ADDR_POSTNUM;
     };
  
     public void setSTRU_ADDR_ADDR(String STRU_ADDR_ADDR){
            this.STRU_ADDR_ADDR=STRU_ADDR_ADDR;
     };
  
     public void setSTRU_ADDR_DETAILADDR(String STRU_ADDR_DETAILADDR){
            this.STRU_ADDR_DETAILADDR=STRU_ADDR_DETAILADDR;
     };
  
     public void setUSE(String USE){
            this.USE=USE;
     };
  
     public void setAREA(String AREA){
            this.AREA=AREA;
     };
  
     public void setNUM_FL(String NUM_FL){
            this.NUM_FL=NUM_FL;
     };
  
     public void setWORK_ITEM(String WORK_ITEM){
            this.WORK_ITEM=WORK_ITEM;
     };
  
     public void setSTE(String STE){
            this.STE=STE;
     };
  
     public void setSUV_APPL(String SUV_APPL){
            this.SUV_APPL=SUV_APPL;
     };
  
     public void setCONFIRMER_NM(String CONFIRMER_NM){
            this.CONFIRMER_NM=CONFIRMER_NM;
     };
  
     public void setCONFIRMER_POSI(String CONFIRMER_POSI){
            this.CONFIRMER_POSI=CONFIRMER_POSI;
     };
  
     public void setCONFIRMER_TEL(String CONFIRMER_TEL){
            this.CONFIRMER_TEL=CONFIRMER_TEL;
     };
  
     public void setINSP_OPIN(String INSP_OPIN){
            this.INSP_OPIN=INSP_OPIN;
     };
  
     public void setPRE_ITEM(String PRE_ITEM){
            this.PRE_ITEM=PRE_ITEM;
     };
  
     public void setSW_BEF_REPO_DELINUM(String SW_BEF_REPO_DELINUM){
            this.SW_BEF_REPO_DELINUM=SW_BEF_REPO_DELINUM;
     };
  
     public void setREPO_DT(String REPO_DT){
            this.REPO_DT=REPO_DT;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setCIV_RECV_NUM(String CIV_RECV_NUM){
            this.CIV_RECV_NUM=CIV_RECV_NUM;
     };
  
     public void setSIDO_CODE(String SIDO_CODE){
            this.SIDO_CODE=SIDO_CODE;
     };
  
     public void setSIGUNGU_CODE(String SIGUNGU_CODE){
            this.SIGUNGU_CODE=SIGUNGU_CODE;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setRECV_NUM(String RECV_NUM){
            this.RECV_NUM=RECV_NUM;
     };
  
     public void setINSP_BAS(String INSP_BAS){
            this.INSP_BAS=INSP_BAS;
     };
  
     public void setCER_DELI_NUM(String CER_DELI_NUM){
            this.CER_DELI_NUM=CER_DELI_NUM;
     };
  
     public void setCER_DELI_CONFIRM(String CER_DELI_CONFIRM){
            this.CER_DELI_CONFIRM=CER_DELI_CONFIRM;
     };
  
     public void setINSP_APPL_DT(String INSP_APPL_DT){
            this.INSP_APPL_DT=INSP_APPL_DT;
     };
  
     public void setPROC_STE(String PROC_STE){
            this.PROC_STE=PROC_STE;
     };
  
     public void setCER_DELI_YN(String CER_DELI_YN){
            this.CER_DELI_YN=CER_DELI_YN;
     };
  
     public void setPROC_OFFI_NM(String PROC_OFFI_NM){
            this.PROC_OFFI_NM=PROC_OFFI_NM;
     };
  
     public void setWORK_ITEM_ETC(String WORK_ITEM_ETC){
            this.WORK_ITEM_ETC=WORK_ITEM_ETC;
     };
  
     public void setETC_INSP_BAS(String ETC_INSP_BAS){
            this.ETC_INSP_BAS=ETC_INSP_BAS;
     };
  
     public void setUPD_DT_OLD(String UPD_DT_OLD){
            this.UPD_DT_OLD=UPD_DT_OLD;
     };
  
     public void setBACKUP_TRANS_DT(String BACKUP_TRANS_DT){
            this.BACKUP_TRANS_DT=BACKUP_TRANS_DT;
     };
  
     public void setCONFIRMER_OFFI_ID(String CONFIRMER_OFFI_ID){
            this.CONFIRMER_OFFI_ID=CONFIRMER_OFFI_ID;
     };
  
     public void setCHG_INSP(String CHG_INSP){
            this.CHG_INSP=CHG_INSP;
     };
  
     public void setSTRU_INFO_BIGO(String STRU_INFO_BIGO){
            this.STRU_INFO_BIGO=STRU_INFO_BIGO;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("ORPE_NM:"+ this.getORPE_NM()+"\n");
      
      strB.append("ORPE_TEL:"+ this.getORPE_TEL()+"\n");
      
      strB.append("ORPE_POSTNUM:"+ this.getORPE_POSTNUM()+"\n");
      
      strB.append("ORPE_ADDR:"+ this.getORPE_ADDR()+"\n");
      
      strB.append("ORPE_DETAILADDR:"+ this.getORPE_DETAILADDR()+"\n");
      
      strB.append("PLANER_NAME:"+ this.getPLANER_NAME()+"\n");
      
      strB.append("PLANER_NM:"+ this.getPLANER_NM()+"\n");
      
      strB.append("PLANER_TEL:"+ this.getPLANER_TEL()+"\n");
      
      strB.append("PLANER_POSTNUM:"+ this.getPLANER_POSTNUM()+"\n");
      
      strB.append("PLANER_ADDR:"+ this.getPLANER_ADDR()+"\n");
      
      strB.append("PLANER_DETAILADDR:"+ this.getPLANER_DETAILADDR()+"\n");
      
      strB.append("RECV_DT:"+ this.getRECV_DT()+"\n");
      
      strB.append("STRU_COMMIT_NUM:"+ this.getSTRU_COMMIT_NUM()+"\n");
      
      strB.append("STRU_ADDR_POSTNUM:"+ this.getSTRU_ADDR_POSTNUM()+"\n");
      
      strB.append("STRU_ADDR_ADDR:"+ this.getSTRU_ADDR_ADDR()+"\n");
      
      strB.append("STRU_ADDR_DETAILADDR:"+ this.getSTRU_ADDR_DETAILADDR()+"\n");
      
      strB.append("USE:"+ this.getUSE()+"\n");
      
      strB.append("AREA:"+ this.getAREA()+"\n");
      
      strB.append("NUM_FL:"+ this.getNUM_FL()+"\n");
      
      strB.append("WORK_ITEM:"+ this.getWORK_ITEM()+"\n");
      
      strB.append("STE:"+ this.getSTE()+"\n");
      
      strB.append("SUV_APPL:"+ this.getSUV_APPL()+"\n");
      
      strB.append("CONFIRMER_NM:"+ this.getCONFIRMER_NM()+"\n");
      
      strB.append("CONFIRMER_POSI:"+ this.getCONFIRMER_POSI()+"\n");
      
      strB.append("CONFIRMER_TEL:"+ this.getCONFIRMER_TEL()+"\n");
      
      strB.append("INSP_OPIN:"+ this.getINSP_OPIN()+"\n");
      
      strB.append("PRE_ITEM:"+ this.getPRE_ITEM()+"\n");
      
      strB.append("SW_BEF_REPO_DELINUM:"+ this.getSW_BEF_REPO_DELINUM()+"\n");
      
      strB.append("REPO_DT:"+ this.getREPO_DT()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("CIV_RECV_NUM:"+ this.getCIV_RECV_NUM()+"\n");
      
      strB.append("SIDO_CODE:"+ this.getSIDO_CODE()+"\n");
      
      strB.append("SIGUNGU_CODE:"+ this.getSIGUNGU_CODE()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("RECV_NUM:"+ this.getRECV_NUM()+"\n");
      
      strB.append("INSP_BAS:"+ this.getINSP_BAS()+"\n");
      
      strB.append("CER_DELI_NUM:"+ this.getCER_DELI_NUM()+"\n");
      
      strB.append("CER_DELI_CONFIRM:"+ this.getCER_DELI_CONFIRM()+"\n");
      
      strB.append("INSP_APPL_DT:"+ this.getINSP_APPL_DT()+"\n");
      
      strB.append("PROC_STE:"+ this.getPROC_STE()+"\n");
      
      strB.append("CER_DELI_YN:"+ this.getCER_DELI_YN()+"\n");
      
      strB.append("PROC_OFFI_NM:"+ this.getPROC_OFFI_NM()+"\n");
      
      strB.append("WORK_ITEM_ETC:"+ this.getWORK_ITEM_ETC()+"\n");
      
      strB.append("ETC_INSP_BAS:"+ this.getETC_INSP_BAS()+"\n");
      
      strB.append("UPD_DT_OLD:"+ this.getUPD_DT_OLD()+"\n");
      
      strB.append("BACKUP_TRANS_DT:"+ this.getBACKUP_TRANS_DT()+"\n");
      
      strB.append("CONFIRMER_OFFI_ID:"+ this.getCONFIRMER_OFFI_ID()+"\n");
      
      strB.append("CHG_INSP:"+ this.getCHG_INSP()+"\n");
      
      strB.append("STRU_INFO_BIGO:"+ this.getSTRU_INFO_BIGO()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_UB_CONSTRUCTIONHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_UB_CONSTRUCTIONHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_UB_CONSTRUCTIONHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_UB_CONSTRUCTIONHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_UB_CONSTRUCTIONHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[3];
       values[0]= this.getRECV_NUM();
       values[1]= this.getSIDO_CODE();
       values[2]= this.getSIGUNGU_CODE();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_UB_CONSTRUCTIONEntity();
  }

  public ValueObject getClone(){
         PT_UB_CONSTRUCTIONEntity newEnt = new PT_UB_CONSTRUCTIONEntity();
	 
          newEnt.setORPE_NM(this.getORPE_NM());
         
          newEnt.setORPE_TEL(this.getORPE_TEL());
         
          newEnt.setORPE_POSTNUM(this.getORPE_POSTNUM());
         
          newEnt.setORPE_ADDR(this.getORPE_ADDR());
         
          newEnt.setORPE_DETAILADDR(this.getORPE_DETAILADDR());
         
          newEnt.setPLANER_NAME(this.getPLANER_NAME());
         
          newEnt.setPLANER_NM(this.getPLANER_NM());
         
          newEnt.setPLANER_TEL(this.getPLANER_TEL());
         
          newEnt.setPLANER_POSTNUM(this.getPLANER_POSTNUM());
         
          newEnt.setPLANER_ADDR(this.getPLANER_ADDR());
         
          newEnt.setPLANER_DETAILADDR(this.getPLANER_DETAILADDR());
         
          newEnt.setRECV_DT(this.getRECV_DT());
         
          newEnt.setSTRU_COMMIT_NUM(this.getSTRU_COMMIT_NUM());
         
          newEnt.setSTRU_ADDR_POSTNUM(this.getSTRU_ADDR_POSTNUM());
         
          newEnt.setSTRU_ADDR_ADDR(this.getSTRU_ADDR_ADDR());
         
          newEnt.setSTRU_ADDR_DETAILADDR(this.getSTRU_ADDR_DETAILADDR());
         
          newEnt.setUSE(this.getUSE());
         
          newEnt.setAREA(this.getAREA());
         
          newEnt.setNUM_FL(this.getNUM_FL());
         
          newEnt.setWORK_ITEM(this.getWORK_ITEM());
         
          newEnt.setSTE(this.getSTE());
         
          newEnt.setSUV_APPL(this.getSUV_APPL());
         
          newEnt.setCONFIRMER_NM(this.getCONFIRMER_NM());
         
          newEnt.setCONFIRMER_POSI(this.getCONFIRMER_POSI());
         
          newEnt.setCONFIRMER_TEL(this.getCONFIRMER_TEL());
         
          newEnt.setINSP_OPIN(this.getINSP_OPIN());
         
          newEnt.setPRE_ITEM(this.getPRE_ITEM());
         
          newEnt.setSW_BEF_REPO_DELINUM(this.getSW_BEF_REPO_DELINUM());
         
          newEnt.setREPO_DT(this.getREPO_DT());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setCIV_RECV_NUM(this.getCIV_RECV_NUM());
         
          newEnt.setSIDO_CODE(this.getSIDO_CODE());
         
          newEnt.setSIGUNGU_CODE(this.getSIGUNGU_CODE());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setRECV_NUM(this.getRECV_NUM());
         
          newEnt.setINSP_BAS(this.getINSP_BAS());
         
          newEnt.setCER_DELI_NUM(this.getCER_DELI_NUM());
         
          newEnt.setCER_DELI_CONFIRM(this.getCER_DELI_CONFIRM());
         
          newEnt.setINSP_APPL_DT(this.getINSP_APPL_DT());
         
          newEnt.setPROC_STE(this.getPROC_STE());
         
          newEnt.setCER_DELI_YN(this.getCER_DELI_YN());
         
          newEnt.setPROC_OFFI_NM(this.getPROC_OFFI_NM());
         
          newEnt.setWORK_ITEM_ETC(this.getWORK_ITEM_ETC());
         
          newEnt.setETC_INSP_BAS(this.getETC_INSP_BAS());
         
          newEnt.setUPD_DT_OLD(this.getUPD_DT_OLD());
         
          newEnt.setBACKUP_TRANS_DT(this.getBACKUP_TRANS_DT());
         
          newEnt.setCONFIRMER_OFFI_ID(this.getCONFIRMER_OFFI_ID());
         
          newEnt.setCHG_INSP(this.getCHG_INSP());
         
          newEnt.setSTRU_INFO_BIGO(this.getSTRU_INFO_BIGO());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_UB_CONSTRUCTIONHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getORPE_NM();
        
             case 2 :
                 return  this.getORPE_TEL();
        
             case 3 :
                 return  this.getORPE_POSTNUM();
        
             case 4 :
                 return  this.getORPE_ADDR();
        
             case 5 :
                 return  this.getORPE_DETAILADDR();
        
             case 6 :
                 return  this.getPLANER_NAME();
        
             case 7 :
                 return  this.getPLANER_NM();
        
             case 8 :
                 return  this.getPLANER_TEL();
        
             case 9 :
                 return  this.getPLANER_POSTNUM();
        
             case 10 :
                 return  this.getPLANER_ADDR();
        
             case 11 :
                 return  this.getPLANER_DETAILADDR();
        
             case 12 :
                 return  this.getRECV_DT();
        
             case 13 :
                 return  this.getSTRU_COMMIT_NUM();
        
             case 14 :
                 return  this.getSTRU_ADDR_POSTNUM();
        
             case 15 :
                 return  this.getSTRU_ADDR_ADDR();
        
             case 16 :
                 return  this.getSTRU_ADDR_DETAILADDR();
        
             case 17 :
                 return  this.getUSE();
        
             case 18 :
                 return  this.getAREA();
        
             case 19 :
                 return  this.getNUM_FL();
        
             case 20 :
                 return  this.getWORK_ITEM();
        
             case 21 :
                 return  this.getSTE();
        
             case 22 :
                 return  this.getSUV_APPL();
        
             case 23 :
                 return  this.getCONFIRMER_NM();
        
             case 24 :
                 return  this.getCONFIRMER_POSI();
        
             case 25 :
                 return  this.getCONFIRMER_TEL();
        
             case 26 :
                 return  this.getINSP_OPIN();
        
             case 27 :
                 return  this.getPRE_ITEM();
        
             case 28 :
                 return  this.getSW_BEF_REPO_DELINUM();
        
             case 29 :
                 return  this.getREPO_DT();
        
             case 30 :
                 return  this.getWRT_ID();
        
             case 31 :
                 return  this.getCIV_RECV_NUM();
        
             case 32 :
                 return  this.getSIDO_CODE();
        
             case 33 :
                 return  this.getSIGUNGU_CODE();
        
             case 34 :
                 return  this.getINS_DT();
        
             case 35 :
                 return  this.getUPD_DT();
        
             case 36 :
                 return  this.getRECV_NUM();
        
             case 37 :
                 return  this.getINSP_BAS();
        
             case 38 :
                 return  this.getCER_DELI_NUM();
        
             case 39 :
                 return  this.getCER_DELI_CONFIRM();
        
             case 40 :
                 return  this.getINSP_APPL_DT();
        
             case 41 :
                 return  this.getPROC_STE();
        
             case 42 :
                 return  this.getCER_DELI_YN();
        
             case 43 :
                 return  this.getPROC_OFFI_NM();
        
             case 44 :
                 return  this.getWORK_ITEM_ETC();
        
             case 45 :
                 return  this.getETC_INSP_BAS();
        
             case 46 :
                 return  this.getUPD_DT_OLD();
        
             case 47 :
                 return  this.getBACKUP_TRANS_DT();
        
             case 48 :
                 return  this.getCONFIRMER_OFFI_ID();
        
             case 49 :
                 return  this.getCHG_INSP();
        
             case 50 :
                 return  this.getSTRU_INFO_BIGO();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_UB_CONSTRUCTIONHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setORPE_NM((String)value);
	            return;  
        
             case 2 :
                    this.setORPE_TEL((String)value);
	            return;  
        
             case 3 :
                    this.setORPE_POSTNUM((String)value);
	            return;  
        
             case 4 :
                    this.setORPE_ADDR((String)value);
	            return;  
        
             case 5 :
                    this.setORPE_DETAILADDR((String)value);
	            return;  
        
             case 6 :
                    this.setPLANER_NAME((String)value);
	            return;  
        
             case 7 :
                    this.setPLANER_NM((String)value);
	            return;  
        
             case 8 :
                    this.setPLANER_TEL((String)value);
	            return;  
        
             case 9 :
                    this.setPLANER_POSTNUM((String)value);
	            return;  
        
             case 10 :
                    this.setPLANER_ADDR((String)value);
	            return;  
        
             case 11 :
                    this.setPLANER_DETAILADDR((String)value);
	            return;  
        
             case 12 :
                    this.setRECV_DT((String)value);
	            return;  
        
             case 13 :
                    this.setSTRU_COMMIT_NUM((String)value);
	            return;  
        
             case 14 :
                    this.setSTRU_ADDR_POSTNUM((String)value);
	            return;  
        
             case 15 :
                    this.setSTRU_ADDR_ADDR((String)value);
	            return;  
        
             case 16 :
                    this.setSTRU_ADDR_DETAILADDR((String)value);
	            return;  
        
             case 17 :
                    this.setUSE((String)value);
	            return;  
        
             case 18 :
                    this.setAREA((String)value);
	            return;  
        
             case 19 :
                    this.setNUM_FL((String)value);
	            return;  
        
             case 20 :
                    this.setWORK_ITEM((String)value);
	            return;  
        
             case 21 :
                    this.setSTE((String)value);
	            return;  
        
             case 22 :
                    this.setSUV_APPL((String)value);
	            return;  
        
             case 23 :
                    this.setCONFIRMER_NM((String)value);
	            return;  
        
             case 24 :
                    this.setCONFIRMER_POSI((String)value);
	            return;  
        
             case 25 :
                    this.setCONFIRMER_TEL((String)value);
	            return;  
        
             case 26 :
                    this.setINSP_OPIN((String)value);
	            return;  
        
             case 27 :
                    this.setPRE_ITEM((String)value);
	            return;  
        
             case 28 :
                    this.setSW_BEF_REPO_DELINUM((String)value);
	            return;  
        
             case 29 :
                    this.setREPO_DT((String)value);
	            return;  
        
             case 30 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 31 :
                    this.setCIV_RECV_NUM((String)value);
	            return;  
        
             case 32 :
                    this.setSIDO_CODE((String)value);
	            return;  
        
             case 33 :
                    this.setSIGUNGU_CODE((String)value);
	            return;  
        
             case 34 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 35 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 36 :
                    this.setRECV_NUM((String)value);
	            return;  
        
             case 37 :
                    this.setINSP_BAS((String)value);
	            return;  
        
             case 38 :
                    this.setCER_DELI_NUM((String)value);
	            return;  
        
             case 39 :
                    this.setCER_DELI_CONFIRM((String)value);
	            return;  
        
             case 40 :
                    this.setINSP_APPL_DT((String)value);
	            return;  
        
             case 41 :
                    this.setPROC_STE((String)value);
	            return;  
        
             case 42 :
                    this.setCER_DELI_YN((String)value);
	            return;  
        
             case 43 :
                    this.setPROC_OFFI_NM((String)value);
	            return;  
        
             case 44 :
                    this.setWORK_ITEM_ETC((String)value);
	            return;  
        
             case 45 :
                    this.setETC_INSP_BAS((String)value);
	            return;  
        
             case 46 :
                    this.setUPD_DT_OLD((String)value);
	            return;  
        
             case 47 :
                    this.setBACKUP_TRANS_DT((String)value);
	            return;  
        
             case 48 :
                    this.setCONFIRMER_OFFI_ID((String)value);
	            return;  
        
             case 49 :
                    this.setCHG_INSP((String)value);
	            return;  
        
             case 50 :
                    this.setSTRU_INFO_BIGO((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_UB_CONSTRUCTIONHelper.toXML(this);
  }
  
}
