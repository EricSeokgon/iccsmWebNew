

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_BBS_BOARD
*  ���̺� ���� :
*  ���̺� PK   :  
*               INDEX1  
*               INDEX2
*  ���̺� �÷� :  
*               CT_ID:VARCHAR2(16):  
*               BOARD_SEQ:NUMBER(22):  
*               INDEX1:NUMBER(22):  
*               INDEX2:NUMBER(22):  
*               DEPTH:NUMBER(22):  
*               SD_CD:VARCHAR2(4):  
*               SGG_CD:VARCHAR2(4):  
*               USER_ID:VARCHAR2(16):  
*               USER_NAME:VARCHAR2(50):  
*               USER_EMAIL:VARCHAR2(100):  
*               USER_PASS:VARCHAR2(16):  
*               USER_IP:VARCHAR2(18):  
*               USER_TEL:VARCHAR2(14):  
*               USER_HOMEPAGE:VARCHAR2(255):  
*               SUBJECT:VARCHAR2(200):  
*               CONTENT:CLOB:  
*               REPLIED_YN:VARCHAR2(1):  
*               SECRET_YN:VARCHAR2(1):  
*               NOTICE_YN:VARCHAR2(1):  
*               READ_NUM:NUMBER(22):  
*               UPD_DT:VARCHAR2(23):  
*               INS_DT:VARCHAR2(23):  
*               WRT_ID:VARCHAR2(16):  
*               ETC_1:VARCHAR2(255):  
*               ETC_2:VARCHAR2(255):  
*               ETC_3:VARCHAR2(255):  
*               ETC_4:VARCHAR2(255):  
*               ETC_5:VARCHAR2(255):  
*               ETC_6:VARCHAR2(255):  
*               ETC_7:VARCHAR2(255):  
*               ETC_8:VARCHAR2(255):  
*               ETC_9:VARCHAR2(255):  
*               ETC_10:VARCHAR2(255):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_BBS_BOARDHelper{

  final static public String CT_ID = "CT_ID";
  final static public String BOARD_SEQ = "BOARD_SEQ";
  final static public String INDEX1 = "INDEX1";
  final static public String INDEX2 = "INDEX2";
  final static public String DEPTH = "DEPTH";
  final static public String SD_CD = "SD_CD";
  final static public String SGG_CD = "SGG_CD";
  final static public String USER_ID = "USER_ID";
  final static public String USER_NAME = "USER_NAME";
  final static public String USER_EMAIL = "USER_EMAIL";
  final static public String USER_PASS = "USER_PASS";
  final static public String USER_IP = "USER_IP";
  final static public String USER_TEL = "USER_TEL";
  final static public String USER_HOMEPAGE = "USER_HOMEPAGE";
  final static public String SUBJECT = "SUBJECT";
  final static public String CONTENT = "CONTENT";
  final static public String REPLIED_YN = "REPLIED_YN";
  final static public String SECRET_YN = "SECRET_YN";
  final static public String NOTICE_YN = "NOTICE_YN";
  final static public String READ_NUM = "READ_NUM";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String ETC_1 = "ETC_1";
  final static public String ETC_2 = "ETC_2";
  final static public String ETC_3 = "ETC_3";
  final static public String ETC_4 = "ETC_4";
  final static public String ETC_5 = "ETC_5";
  final static public String ETC_6 = "ETC_6";
  final static public String ETC_7 = "ETC_7";
  final static public String ETC_8 = "ETC_8";
  final static public String ETC_9 = "ETC_9";
  final static public String ETC_10 = "ETC_10";
  


  public static HashMap fieldMap = new HashMap(33);
  static{
  fieldMap.put(CT_ID,new Integer(1) );
  fieldMap.put(BOARD_SEQ,new Integer(2) );
  fieldMap.put(INDEX1,new Integer(3) );
  fieldMap.put(INDEX2,new Integer(4) );
  fieldMap.put(DEPTH,new Integer(5) );
  fieldMap.put(SD_CD,new Integer(6) );
  fieldMap.put(SGG_CD,new Integer(7) );
  fieldMap.put(USER_ID,new Integer(8) );
  fieldMap.put(USER_NAME,new Integer(9) );
  fieldMap.put(USER_EMAIL,new Integer(10) );
  fieldMap.put(USER_PASS,new Integer(11) );
  fieldMap.put(USER_IP,new Integer(12) );
  fieldMap.put(USER_TEL,new Integer(13) );
  fieldMap.put(USER_HOMEPAGE,new Integer(14) );
  fieldMap.put(SUBJECT,new Integer(15) );
  fieldMap.put(CONTENT,new Integer(16) );
  fieldMap.put(REPLIED_YN,new Integer(17) );
  fieldMap.put(SECRET_YN,new Integer(18) );
  fieldMap.put(NOTICE_YN,new Integer(19) );
  fieldMap.put(READ_NUM,new Integer(20) );
  fieldMap.put(UPD_DT,new Integer(21) );
  fieldMap.put(INS_DT,new Integer(22) );
  fieldMap.put(WRT_ID,new Integer(23) );
  fieldMap.put(ETC_1,new Integer(24) );
  fieldMap.put(ETC_2,new Integer(25) );
  fieldMap.put(ETC_3,new Integer(26) );
  fieldMap.put(ETC_4,new Integer(27) );
  fieldMap.put(ETC_5,new Integer(28) );
  fieldMap.put(ETC_6,new Integer(29) );
  fieldMap.put(ETC_7,new Integer(30) );
  fieldMap.put(ETC_8,new Integer(31) );
  fieldMap.put(ETC_9,new Integer(32) );
  fieldMap.put(ETC_10,new Integer(33) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_BBS_BOARD";
     final public static String PREFIX = "sp.dao.PT_BBS_BOARD";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       INDEX1,INDEX2 };
     final public static String FIELD_LIST[] = { 
       CT_ID,BOARD_SEQ,INDEX1,INDEX2,DEPTH,SD_CD,SGG_CD,USER_ID,USER_NAME,USER_EMAIL,USER_PASS,USER_IP,USER_TEL,USER_HOMEPAGE,SUBJECT,CONTENT,REPLIED_YN,SECRET_YN,NOTICE_YN,READ_NUM,UPD_DT,INS_DT,WRT_ID,ETC_1,ETC_2,ETC_3,ETC_4,ETC_5,ETC_6,ETC_7,ETC_8,ETC_9,ETC_10 };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
             case 28 : 
	                  return  "";
             case 29 : 
	                  return  "";
             case 30 : 
	                  return  "";
             case 31 : 
	                  return  "";
             case 32 : 
	                  return  "";
             case 33 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_BBS_BOARDEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CT_ID").append("'")
            .append(" value='").append(""+ent.getCT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_SEQ").append("'")
            .append(" value='").append(""+ent.getBOARD_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INDEX1").append("'")
            .append(" value='").append(""+ent.getINDEX1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INDEX2").append("'")
            .append(" value='").append(""+ent.getINDEX2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DEPTH").append("'")
            .append(" value='").append(""+ent.getDEPTH()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SD_CD").append("'")
            .append(" value='").append(""+ent.getSD_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SGG_CD").append("'")
            .append(" value='").append(""+ent.getSGG_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_ID").append("'")
            .append(" value='").append(""+ent.getUSER_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_NAME").append("'")
            .append(" value='").append(""+ent.getUSER_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_EMAIL").append("'")
            .append(" value='").append(""+ent.getUSER_EMAIL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_PASS").append("'")
            .append(" value='").append(""+ent.getUSER_PASS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_IP").append("'")
            .append(" value='").append(""+ent.getUSER_IP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_TEL").append("'")
            .append(" value='").append(""+ent.getUSER_TEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_HOMEPAGE").append("'")
            .append(" value='").append(""+ent.getUSER_HOMEPAGE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJECT").append("'")
            .append(" value='").append(""+ent.getSUBJECT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONTENT").append("'")
            .append(" value='").append(""+ent.getCONTENT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REPLIED_YN").append("'")
            .append(" value='").append(""+ent.getREPLIED_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SECRET_YN").append("'")
            .append(" value='").append(""+ent.getSECRET_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NOTICE_YN").append("'")
            .append(" value='").append(""+ent.getNOTICE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("READ_NUM").append("'")
            .append(" value='").append(""+ent.getREAD_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_1").append("'")
            .append(" value='").append(""+ent.getETC_1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_2").append("'")
            .append(" value='").append(""+ent.getETC_2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_3").append("'")
            .append(" value='").append(""+ent.getETC_3()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_4").append("'")
            .append(" value='").append(""+ent.getETC_4()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_5").append("'")
            .append(" value='").append(""+ent.getETC_5()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_6").append("'")
            .append(" value='").append(""+ent.getETC_6()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_7").append("'")
            .append(" value='").append(""+ent.getETC_7()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_8").append("'")
            .append(" value='").append(""+ent.getETC_8()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_9").append("'")
            .append(" value='").append(""+ent.getETC_9()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ETC_10").append("'")
            .append(" value='").append(""+ent.getETC_10()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
