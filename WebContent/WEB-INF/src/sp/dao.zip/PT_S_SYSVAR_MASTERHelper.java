

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_S_SYSVAR_MASTER
*  ���̺� ���� :
*  ���̺� PK   :  
*               SIDO_CODE  
*               SIGUNGU_CODE
*  ���̺� �÷� :  
*               SIDO_CODE:VARCHAR2(4):  
*               SIGUNGU_CODE:VARCHAR2(5):  
*               NEW_WRT:NUMBER(3):  
*               BAS_STA:NUMBER(3):  
*               AFF:NUMBER(3):  
*               ASSI_TRAN:NUMBER(3):  
*               USEBEF_INSP:NUMBER(3):  
*               CYTYSEAL:VARCHAR2(26):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               SERVER_ADDR:VARCHAR2(100):  
*               SERVER_YN:VARCHAR2(1):  
*               SEND_SYS_ID:VARCHAR2(40):  
*               RECV_SYS_ID:VARCHAR2(40):  
*               CITYSEAL_USE_YN:CHAR(1):  
*               CITYSEAL_WIDTH:VARCHAR2(5):  
*               CITYSEAL_HEIGHT:VARCHAR2(5):  
*               GROUPWARE_MODULE_TYPE:VARCHAR2(20):  
*               ONLINE_CERT_USE_YN:CHAR(1):  
*               APPL_GUBUN:CHAR(1):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_S_SYSVAR_MASTERHelper{

  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String SIGUNGU_CODE = "SIGUNGU_CODE";
  final static public String NEW_WRT = "NEW_WRT";
  final static public String BAS_STA = "BAS_STA";
  final static public String AFF = "AFF";
  final static public String ASSI_TRAN = "ASSI_TRAN";
  final static public String USEBEF_INSP = "USEBEF_INSP";
  final static public String CYTYSEAL = "CYTYSEAL";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String SERVER_ADDR = "SERVER_ADDR";
  final static public String SERVER_YN = "SERVER_YN";
  final static public String SEND_SYS_ID = "SEND_SYS_ID";
  final static public String RECV_SYS_ID = "RECV_SYS_ID";
  final static public String CITYSEAL_USE_YN = "CITYSEAL_USE_YN";
  final static public String CITYSEAL_WIDTH = "CITYSEAL_WIDTH";
  final static public String CITYSEAL_HEIGHT = "CITYSEAL_HEIGHT";
  final static public String GROUPWARE_MODULE_TYPE = "GROUPWARE_MODULE_TYPE";
  final static public String ONLINE_CERT_USE_YN = "ONLINE_CERT_USE_YN";
  final static public String APPL_GUBUN = "APPL_GUBUN";
  


  public static HashMap fieldMap = new HashMap(21);
  static{
  fieldMap.put(SIDO_CODE,new Integer(1) );
  fieldMap.put(SIGUNGU_CODE,new Integer(2) );
  fieldMap.put(NEW_WRT,new Integer(3) );
  fieldMap.put(BAS_STA,new Integer(4) );
  fieldMap.put(AFF,new Integer(5) );
  fieldMap.put(ASSI_TRAN,new Integer(6) );
  fieldMap.put(USEBEF_INSP,new Integer(7) );
  fieldMap.put(CYTYSEAL,new Integer(8) );
  fieldMap.put(WRT_ID,new Integer(9) );
  fieldMap.put(INS_DT,new Integer(10) );
  fieldMap.put(UPD_DT,new Integer(11) );
  fieldMap.put(SERVER_ADDR,new Integer(12) );
  fieldMap.put(SERVER_YN,new Integer(13) );
  fieldMap.put(SEND_SYS_ID,new Integer(14) );
  fieldMap.put(RECV_SYS_ID,new Integer(15) );
  fieldMap.put(CITYSEAL_USE_YN,new Integer(16) );
  fieldMap.put(CITYSEAL_WIDTH,new Integer(17) );
  fieldMap.put(CITYSEAL_HEIGHT,new Integer(18) );
  fieldMap.put(GROUPWARE_MODULE_TYPE,new Integer(19) );
  fieldMap.put(ONLINE_CERT_USE_YN,new Integer(20) );
  fieldMap.put(APPL_GUBUN,new Integer(21) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_S_SYSVAR_MASTER";
     final public static String PREFIX = "sp.dao.PT_S_SYSVAR_MASTER";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SIDO_CODE,SIGUNGU_CODE };
     final public static String FIELD_LIST[] = { 
       SIDO_CODE,SIGUNGU_CODE,NEW_WRT,BAS_STA,AFF,ASSI_TRAN,USEBEF_INSP,CYTYSEAL,WRT_ID,INS_DT,UPD_DT,SERVER_ADDR,SERVER_YN,SEND_SYS_ID,RECV_SYS_ID,CITYSEAL_USE_YN,CITYSEAL_WIDTH,CITYSEAL_HEIGHT,GROUPWARE_MODULE_TYPE,ONLINE_CERT_USE_YN,APPL_GUBUN };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_S_SYSVAR_MASTEREntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_CODE").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NEW_WRT").append("'")
            .append(" value='").append(""+ent.getNEW_WRT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BAS_STA").append("'")
            .append(" value='").append(""+ent.getBAS_STA()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("AFF").append("'")
            .append(" value='").append(""+ent.getAFF()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ASSI_TRAN").append("'")
            .append(" value='").append(""+ent.getASSI_TRAN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USEBEF_INSP").append("'")
            .append(" value='").append(""+ent.getUSEBEF_INSP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CYTYSEAL").append("'")
            .append(" value='").append(""+ent.getCYTYSEAL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SERVER_ADDR").append("'")
            .append(" value='").append(""+ent.getSERVER_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SERVER_YN").append("'")
            .append(" value='").append(""+ent.getSERVER_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEND_SYS_ID").append("'")
            .append(" value='").append(""+ent.getSEND_SYS_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_SYS_ID").append("'")
            .append(" value='").append(""+ent.getRECV_SYS_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CITYSEAL_USE_YN").append("'")
            .append(" value='").append(""+ent.getCITYSEAL_USE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CITYSEAL_WIDTH").append("'")
            .append(" value='").append(""+ent.getCITYSEAL_WIDTH()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CITYSEAL_HEIGHT").append("'")
            .append(" value='").append(""+ent.getCITYSEAL_HEIGHT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("GROUPWARE_MODULE_TYPE").append("'")
            .append(" value='").append(""+ent.getGROUPWARE_MODULE_TYPE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ONLINE_CERT_USE_YN").append("'")
            .append(" value='").append(""+ent.getONLINE_CERT_USE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("APPL_GUBUN").append("'")
            .append(" value='").append(""+ent.getAPPL_GUBUN()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
