

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_S_WORK_ITEM
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ  
*               TMP_WRT_NUM  
*               WRT_NUM
*  ���̺� �÷� :  
*               WRT_NUM:VARCHAR2(12):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               WORKNM:VARCHAR2(200):  
*               SPOT_ADDR:VARCHAR2(200):  
*               CONT_WRT_YN:VARCHAR2(1):  
*               ENGINEER_ARR_NOTE:VARCHAR2(1):  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(12):  
*               SPOT_TEL:VARCHAR2(17):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               SEQ:NUMBER(4):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_S_WORK_ITEMHelper{

  final static public String WRT_NUM = "WRT_NUM";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String WORKNM = "WORKNM";
  final static public String SPOT_ADDR = "SPOT_ADDR";
  final static public String CONT_WRT_YN = "CONT_WRT_YN";
  final static public String ENGINEER_ARR_NOTE = "ENGINEER_ARR_NOTE";
  final static public String CARE_BOOK_ISSUE_NUM = "CARE_BOOK_ISSUE_NUM";
  final static public String SPOT_TEL = "SPOT_TEL";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String SEQ = "SEQ";
  


  public static HashMap fieldMap = new HashMap(12);
  static{
  fieldMap.put(WRT_NUM,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(WORKNM,new Integer(3) );
  fieldMap.put(SPOT_ADDR,new Integer(4) );
  fieldMap.put(CONT_WRT_YN,new Integer(5) );
  fieldMap.put(ENGINEER_ARR_NOTE,new Integer(6) );
  fieldMap.put(CARE_BOOK_ISSUE_NUM,new Integer(7) );
  fieldMap.put(SPOT_TEL,new Integer(8) );
  fieldMap.put(INS_DT,new Integer(9) );
  fieldMap.put(UPD_DT,new Integer(10) );
  fieldMap.put(WRT_ID,new Integer(11) );
  fieldMap.put(SEQ,new Integer(12) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_S_WORK_ITEM";
     final public static String PREFIX = "sp.dao.PT_S_WORK_ITEM";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ,TMP_WRT_NUM,WRT_NUM };
     final public static String FIELD_LIST[] = { 
       WRT_NUM,TMP_WRT_NUM,WORKNM,SPOT_ADDR,CONT_WRT_YN,ENGINEER_ARR_NOTE,CARE_BOOK_ISSUE_NUM,SPOT_TEL,INS_DT,UPD_DT,WRT_ID,SEQ };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_S_WORK_ITEMEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_NUM").append("'")
            .append(" value='").append(""+ent.getWRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WORKNM").append("'")
            .append(" value='").append(""+ent.getWORKNM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOT_ADDR").append("'")
            .append(" value='").append(""+ent.getSPOT_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONT_WRT_YN").append("'")
            .append(" value='").append(""+ent.getCONT_WRT_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_ARR_NOTE").append("'")
            .append(" value='").append(""+ent.getENGINEER_ARR_NOTE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_ISSUE_NUM").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_ISSUE_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOT_TEL").append("'")
            .append(" value='").append(""+ent.getSPOT_TEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
