

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_BBS_COM_CODE
*  ���̺� ���� :
*  ���̺� PK   :  
*               CODE  
*               CODE_GROUP
*  ���̺� �÷� :  
*               CODE_GROUP:VARCHAR2(16):  
*               CODE:VARCHAR2(16):  
*               CODE_NAME:VARCHAR2(50):  
*               BIGO:VARCHAR2(100):  
*               ORDER_NUM:NUMBER(22):  
*               USE_YN:VARCHAR2(1):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_BBS_COM_CODEHelper{

  final static public String CODE_GROUP = "CODE_GROUP";
  final static public String CODE = "CODE";
  final static public String CODE_NAME = "CODE_NAME";
  final static public String BIGO = "BIGO";
  final static public String ORDER_NUM = "ORDER_NUM";
  final static public String USE_YN = "USE_YN";
  


  public static HashMap fieldMap = new HashMap(6);
  static{
  fieldMap.put(CODE_GROUP,new Integer(1) );
  fieldMap.put(CODE,new Integer(2) );
  fieldMap.put(CODE_NAME,new Integer(3) );
  fieldMap.put(BIGO,new Integer(4) );
  fieldMap.put(ORDER_NUM,new Integer(5) );
  fieldMap.put(USE_YN,new Integer(6) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_BBS_COM_CODE";
     final public static String PREFIX = "sp.dao.PT_BBS_COM_CODE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CODE,CODE_GROUP };
     final public static String FIELD_LIST[] = { 
       CODE_GROUP,CODE,CODE_NAME,BIGO,ORDER_NUM,USE_YN };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_BBS_COM_CODEEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CODE_GROUP").append("'")
            .append(" value='").append(""+ent.getCODE_GROUP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CODE").append("'")
            .append(" value='").append(""+ent.getCODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CODE_NAME").append("'")
            .append(" value='").append(""+ent.getCODE_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BIGO").append("'")
            .append(" value='").append(""+ent.getBIGO()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ORDER_NUM").append("'")
            .append(" value='").append(""+ent.getORDER_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USE_YN").append("'")
            .append(" value='").append(""+ent.getUSE_YN()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
