

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_BASIC_STATEMENT
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE
*  ���̺� �÷� :  
*               RECV_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               RECV_DT:VARCHAR2(8):  
*               RECV_TIME:VARCHAR2(4):  
*               PROC_LIM:VARCHAR2(8):  
*               OFFI_PART:VARCHAR2(50):  
*               OFFI_PART_REBO_WRT_NUM:VARCHAR2(12):  
*               COI_WRT_NUM:VARCHAR2(12):  
*               DEFI_STE:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               NAME:VARCHAR2(50):  
*               REP_NM_KOR:VARCHAR2(20):  
*               ADDR_ADDR:VARCHAR2(200):  
*               WRT_DT:VARCHAR2(8):  
*               PROC_TIME:VARCHAR2(6):  
*               ADDR_DETAIL_ADDR:VARCHAR2(120):  
*               ADDR_POST_NUM:VARCHAR2(6):  
*               TMP_WRT_NUM:VARCHAR2(12):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_R_BASIC_STATEMENTEntity extends ValueObject{

  
     private String RECV_NUM;
  
     private String SIDO_CODE;
  
     private String RECV_DT;
  
     private String RECV_TIME;
  
     private String PROC_LIM;
  
     private String OFFI_PART;
  
     private String OFFI_PART_REBO_WRT_NUM;
  
     private String COI_WRT_NUM;
  
     private String DEFI_STE;
  
     private String WRT_ID;
  
     private String UPD_DT;
  
     private String INS_DT;
  
     private String NAME;
  
     private String REP_NM_KOR;
  
     private String ADDR_ADDR;
  
     private String WRT_DT;
  
     private String PROC_TIME;
  
     private String ADDR_DETAIL_ADDR;
  
     private String ADDR_POST_NUM;
  
     private String TMP_WRT_NUM;
  

//�����ڸ� �����
    public PT_R_BASIC_STATEMENTEntity(){
    }
    
    
    public PT_R_BASIC_STATEMENTEntity(String RECV_NUM,String SIDO_CODE ){
       this.setRECV_NUM(RECV_NUM);
       this.setSIDO_CODE(SIDO_CODE);
       
    }
      
    public PT_R_BASIC_STATEMENTEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("RECV_NUM");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("RECV_NUM",value);
       
       value = ent.getByName("SIDO_CODE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SIDO_CODE",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.RECV_NUM =request.getParameter("RECV_NUM");
		this.SIDO_CODE =request.getParameter("SIDO_CODE");
		this.RECV_DT =request.getParameter("RECV_DT");
		this.RECV_TIME =request.getParameter("RECV_TIME");
		this.PROC_LIM =request.getParameter("PROC_LIM");
		this.OFFI_PART =request.getParameter("OFFI_PART");
		this.OFFI_PART_REBO_WRT_NUM =request.getParameter("OFFI_PART_REBO_WRT_NUM");
		this.COI_WRT_NUM =request.getParameter("COI_WRT_NUM");
		this.DEFI_STE =request.getParameter("DEFI_STE");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.INS_DT =request.getParameter("INS_DT");
		this.NAME =request.getParameter("NAME");
		this.REP_NM_KOR =request.getParameter("REP_NM_KOR");
		this.ADDR_ADDR =request.getParameter("ADDR_ADDR");
		this.WRT_DT =request.getParameter("WRT_DT");
		this.PROC_TIME =request.getParameter("PROC_TIME");
		this.ADDR_DETAIL_ADDR =request.getParameter("ADDR_DETAIL_ADDR");
		this.ADDR_POST_NUM =request.getParameter("ADDR_POST_NUM");
		this.TMP_WRT_NUM =request.getParameter("TMP_WRT_NUM");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.RECV_NUM =KJFMi.dsGet(ds, arg_row, "RECV_NUM");
		this.SIDO_CODE =KJFMi.dsGet(ds, arg_row, "SIDO_CODE");
		this.RECV_DT =KJFMi.dsGet(ds, arg_row, "RECV_DT");
		this.RECV_TIME =KJFMi.dsGet(ds, arg_row, "RECV_TIME");
		this.PROC_LIM =KJFMi.dsGet(ds, arg_row, "PROC_LIM");
		this.OFFI_PART =KJFMi.dsGet(ds, arg_row, "OFFI_PART");
		this.OFFI_PART_REBO_WRT_NUM =KJFMi.dsGet(ds, arg_row, "OFFI_PART_REBO_WRT_NUM");
		this.COI_WRT_NUM =KJFMi.dsGet(ds, arg_row, "COI_WRT_NUM");
		this.DEFI_STE =KJFMi.dsGet(ds, arg_row, "DEFI_STE");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.NAME =KJFMi.dsGet(ds, arg_row, "NAME");
		this.REP_NM_KOR =KJFMi.dsGet(ds, arg_row, "REP_NM_KOR");
		this.ADDR_ADDR =KJFMi.dsGet(ds, arg_row, "ADDR_ADDR");
		this.WRT_DT =KJFMi.dsGet(ds, arg_row, "WRT_DT");
		this.PROC_TIME =KJFMi.dsGet(ds, arg_row, "PROC_TIME");
		this.ADDR_DETAIL_ADDR =KJFMi.dsGet(ds, arg_row, "ADDR_DETAIL_ADDR");
		this.ADDR_POST_NUM =KJFMi.dsGet(ds, arg_row, "ADDR_POST_NUM");
		this.TMP_WRT_NUM =KJFMi.dsGet(ds, arg_row, "TMP_WRT_NUM");
				
    }    
    
//Getter �Լ��� �����
  
     public String getRECV_NUM(){
             return RECV_NUM;
     };
  
     public String getSIDO_CODE(){
             return SIDO_CODE;
     };
  
     public String getRECV_DT(){
             return RECV_DT;
     };
  
     public String getRECV_TIME(){
             return RECV_TIME;
     };
  
     public String getPROC_LIM(){
             return PROC_LIM;
     };
  
     public String getOFFI_PART(){
             return OFFI_PART;
     };
  
     public String getOFFI_PART_REBO_WRT_NUM(){
             return OFFI_PART_REBO_WRT_NUM;
     };
  
     public String getCOI_WRT_NUM(){
             return COI_WRT_NUM;
     };
  
     public String getDEFI_STE(){
             return DEFI_STE;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getNAME(){
             return NAME;
     };
  
     public String getREP_NM_KOR(){
             return REP_NM_KOR;
     };
  
     public String getADDR_ADDR(){
             return ADDR_ADDR;
     };
  
     public String getWRT_DT(){
             return WRT_DT;
     };
  
     public String getPROC_TIME(){
             return PROC_TIME;
     };
  
     public String getADDR_DETAIL_ADDR(){
             return ADDR_DETAIL_ADDR;
     };
  
     public String getADDR_POST_NUM(){
             return ADDR_POST_NUM;
     };
  
     public String getTMP_WRT_NUM(){
             return TMP_WRT_NUM;
     };
  

//Setter �Լ��� �����
  
     public void setRECV_NUM(String RECV_NUM){
            this.RECV_NUM=RECV_NUM;
     };
  
     public void setSIDO_CODE(String SIDO_CODE){
            this.SIDO_CODE=SIDO_CODE;
     };
  
     public void setRECV_DT(String RECV_DT){
            this.RECV_DT=RECV_DT;
     };
  
     public void setRECV_TIME(String RECV_TIME){
            this.RECV_TIME=RECV_TIME;
     };
  
     public void setPROC_LIM(String PROC_LIM){
            this.PROC_LIM=PROC_LIM;
     };
  
     public void setOFFI_PART(String OFFI_PART){
            this.OFFI_PART=OFFI_PART;
     };
  
     public void setOFFI_PART_REBO_WRT_NUM(String OFFI_PART_REBO_WRT_NUM){
            this.OFFI_PART_REBO_WRT_NUM=OFFI_PART_REBO_WRT_NUM;
     };
  
     public void setCOI_WRT_NUM(String COI_WRT_NUM){
            this.COI_WRT_NUM=COI_WRT_NUM;
     };
  
     public void setDEFI_STE(String DEFI_STE){
            this.DEFI_STE=DEFI_STE;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setNAME(String NAME){
            this.NAME=NAME;
     };
  
     public void setREP_NM_KOR(String REP_NM_KOR){
            this.REP_NM_KOR=REP_NM_KOR;
     };
  
     public void setADDR_ADDR(String ADDR_ADDR){
            this.ADDR_ADDR=ADDR_ADDR;
     };
  
     public void setWRT_DT(String WRT_DT){
            this.WRT_DT=WRT_DT;
     };
  
     public void setPROC_TIME(String PROC_TIME){
            this.PROC_TIME=PROC_TIME;
     };
  
     public void setADDR_DETAIL_ADDR(String ADDR_DETAIL_ADDR){
            this.ADDR_DETAIL_ADDR=ADDR_DETAIL_ADDR;
     };
  
     public void setADDR_POST_NUM(String ADDR_POST_NUM){
            this.ADDR_POST_NUM=ADDR_POST_NUM;
     };
  
     public void setTMP_WRT_NUM(String TMP_WRT_NUM){
            this.TMP_WRT_NUM=TMP_WRT_NUM;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("RECV_NUM:"+ this.getRECV_NUM()+"\n");
      
      strB.append("SIDO_CODE:"+ this.getSIDO_CODE()+"\n");
      
      strB.append("RECV_DT:"+ this.getRECV_DT()+"\n");
      
      strB.append("RECV_TIME:"+ this.getRECV_TIME()+"\n");
      
      strB.append("PROC_LIM:"+ this.getPROC_LIM()+"\n");
      
      strB.append("OFFI_PART:"+ this.getOFFI_PART()+"\n");
      
      strB.append("OFFI_PART_REBO_WRT_NUM:"+ this.getOFFI_PART_REBO_WRT_NUM()+"\n");
      
      strB.append("COI_WRT_NUM:"+ this.getCOI_WRT_NUM()+"\n");
      
      strB.append("DEFI_STE:"+ this.getDEFI_STE()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("NAME:"+ this.getNAME()+"\n");
      
      strB.append("REP_NM_KOR:"+ this.getREP_NM_KOR()+"\n");
      
      strB.append("ADDR_ADDR:"+ this.getADDR_ADDR()+"\n");
      
      strB.append("WRT_DT:"+ this.getWRT_DT()+"\n");
      
      strB.append("PROC_TIME:"+ this.getPROC_TIME()+"\n");
      
      strB.append("ADDR_DETAIL_ADDR:"+ this.getADDR_DETAIL_ADDR()+"\n");
      
      strB.append("ADDR_POST_NUM:"+ this.getADDR_POST_NUM()+"\n");
      
      strB.append("TMP_WRT_NUM:"+ this.getTMP_WRT_NUM()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_R_BASIC_STATEMENTHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_R_BASIC_STATEMENTHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_R_BASIC_STATEMENTHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_R_BASIC_STATEMENTHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_R_BASIC_STATEMENTHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[2];
       values[0]= this.getRECV_NUM();
       values[1]= this.getSIDO_CODE();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_R_BASIC_STATEMENTEntity();
  }

  public ValueObject getClone(){
         PT_R_BASIC_STATEMENTEntity newEnt = new PT_R_BASIC_STATEMENTEntity();
	 
          newEnt.setRECV_NUM(this.getRECV_NUM());
         
          newEnt.setSIDO_CODE(this.getSIDO_CODE());
         
          newEnt.setRECV_DT(this.getRECV_DT());
         
          newEnt.setRECV_TIME(this.getRECV_TIME());
         
          newEnt.setPROC_LIM(this.getPROC_LIM());
         
          newEnt.setOFFI_PART(this.getOFFI_PART());
         
          newEnt.setOFFI_PART_REBO_WRT_NUM(this.getOFFI_PART_REBO_WRT_NUM());
         
          newEnt.setCOI_WRT_NUM(this.getCOI_WRT_NUM());
         
          newEnt.setDEFI_STE(this.getDEFI_STE());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setNAME(this.getNAME());
         
          newEnt.setREP_NM_KOR(this.getREP_NM_KOR());
         
          newEnt.setADDR_ADDR(this.getADDR_ADDR());
         
          newEnt.setWRT_DT(this.getWRT_DT());
         
          newEnt.setPROC_TIME(this.getPROC_TIME());
         
          newEnt.setADDR_DETAIL_ADDR(this.getADDR_DETAIL_ADDR());
         
          newEnt.setADDR_POST_NUM(this.getADDR_POST_NUM());
         
          newEnt.setTMP_WRT_NUM(this.getTMP_WRT_NUM());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_R_BASIC_STATEMENTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getRECV_NUM();
        
             case 2 :
                 return  this.getSIDO_CODE();
        
             case 3 :
                 return  this.getRECV_DT();
        
             case 4 :
                 return  this.getRECV_TIME();
        
             case 5 :
                 return  this.getPROC_LIM();
        
             case 6 :
                 return  this.getOFFI_PART();
        
             case 7 :
                 return  this.getOFFI_PART_REBO_WRT_NUM();
        
             case 8 :
                 return  this.getCOI_WRT_NUM();
        
             case 9 :
                 return  this.getDEFI_STE();
        
             case 10 :
                 return  this.getWRT_ID();
        
             case 11 :
                 return  this.getUPD_DT();
        
             case 12 :
                 return  this.getINS_DT();
        
             case 13 :
                 return  this.getNAME();
        
             case 14 :
                 return  this.getREP_NM_KOR();
        
             case 15 :
                 return  this.getADDR_ADDR();
        
             case 16 :
                 return  this.getWRT_DT();
        
             case 17 :
                 return  this.getPROC_TIME();
        
             case 18 :
                 return  this.getADDR_DETAIL_ADDR();
        
             case 19 :
                 return  this.getADDR_POST_NUM();
        
             case 20 :
                 return  this.getTMP_WRT_NUM();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_R_BASIC_STATEMENTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setRECV_NUM((String)value);
	            return;  
        
             case 2 :
                    this.setSIDO_CODE((String)value);
	            return;  
        
             case 3 :
                    this.setRECV_DT((String)value);
	            return;  
        
             case 4 :
                    this.setRECV_TIME((String)value);
	            return;  
        
             case 5 :
                    this.setPROC_LIM((String)value);
	            return;  
        
             case 6 :
                    this.setOFFI_PART((String)value);
	            return;  
        
             case 7 :
                    this.setOFFI_PART_REBO_WRT_NUM((String)value);
	            return;  
        
             case 8 :
                    this.setCOI_WRT_NUM((String)value);
	            return;  
        
             case 9 :
                    this.setDEFI_STE((String)value);
	            return;  
        
             case 10 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 11 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 12 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 13 :
                    this.setNAME((String)value);
	            return;  
        
             case 14 :
                    this.setREP_NM_KOR((String)value);
	            return;  
        
             case 15 :
                    this.setADDR_ADDR((String)value);
	            return;  
        
             case 16 :
                    this.setWRT_DT((String)value);
	            return;  
        
             case 17 :
                    this.setPROC_TIME((String)value);
	            return;  
        
             case 18 :
                    this.setADDR_DETAIL_ADDR((String)value);
	            return;  
        
             case 19 :
                    this.setADDR_POST_NUM((String)value);
	            return;  
        
             case 20 :
                    this.setTMP_WRT_NUM((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_R_BASIC_STATEMENTHelper.toXML(this);
  }
  
}
