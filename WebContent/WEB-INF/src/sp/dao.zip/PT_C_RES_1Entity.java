

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_C_RES_1
*  ���̺� ���� :
*  ���̺� PK   :
*  ���̺� �÷� :  
*               SEQ:VARCHAR2(4):  
*               SIDO_NM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               ITEM_NM:VARCHAR2(50):  
*               LINE_NUM:NUMBER(10):  
*               LINE_CH_NUM:NUMBER(10):  
*               LINE_E1_NUM:NUMBER(10):  
*               SET_DT:VARCHAR2(24):  
*               EQU_COST:VARCHAR2(12):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               ETC:VARCHAR2(50):  
*               SIGUNGU_CODE:VARCHAR2(4):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_C_RES_1Entity extends ValueObject{

  
     private String SEQ;
  
     private String SIDO_NM;
  
     private String SIDO_CODE;
  
     private String ITEM_NM;
  
     private String LINE_NUM;
  
     private String LINE_CH_NUM;
  
     private String LINE_E1_NUM;
  
     private String SET_DT;
  
     private String EQU_COST;
  
     private String UPD_DT;
  
     private String INS_DT;
  
     private String ETC;
  
     private String SIGUNGU_CODE;
  

//�����ڸ� �����
    public PT_C_RES_1Entity(){
    }
    
      
    public PT_C_RES_1Entity(ValueObject ent) throws Exception{
       Object value = null; 
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.SEQ =request.getParameter("SEQ");
		this.SIDO_NM =request.getParameter("SIDO_NM");
		this.SIDO_CODE =request.getParameter("SIDO_CODE");
		this.ITEM_NM =request.getParameter("ITEM_NM");
		this.LINE_NUM =request.getParameter("LINE_NUM");
		this.LINE_CH_NUM =request.getParameter("LINE_CH_NUM");
		this.LINE_E1_NUM =request.getParameter("LINE_E1_NUM");
		this.SET_DT =request.getParameter("SET_DT");
		this.EQU_COST =request.getParameter("EQU_COST");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.INS_DT =request.getParameter("INS_DT");
		this.ETC =request.getParameter("ETC");
		this.SIGUNGU_CODE =request.getParameter("SIGUNGU_CODE");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.SEQ =KJFMi.dsGet(ds, arg_row, "SEQ");
		this.SIDO_NM =KJFMi.dsGet(ds, arg_row, "SIDO_NM");
		this.SIDO_CODE =KJFMi.dsGet(ds, arg_row, "SIDO_CODE");
		this.ITEM_NM =KJFMi.dsGet(ds, arg_row, "ITEM_NM");
		this.LINE_NUM =KJFMi.dsGet(ds, arg_row, "LINE_NUM");
		this.LINE_CH_NUM =KJFMi.dsGet(ds, arg_row, "LINE_CH_NUM");
		this.LINE_E1_NUM =KJFMi.dsGet(ds, arg_row, "LINE_E1_NUM");
		this.SET_DT =KJFMi.dsGet(ds, arg_row, "SET_DT");
		this.EQU_COST =KJFMi.dsGet(ds, arg_row, "EQU_COST");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.ETC =KJFMi.dsGet(ds, arg_row, "ETC");
		this.SIGUNGU_CODE =KJFMi.dsGet(ds, arg_row, "SIGUNGU_CODE");
				
    }    
    
//Getter �Լ��� �����
  
     public String getSEQ(){
             return SEQ;
     };
  
     public String getSIDO_NM(){
             return SIDO_NM;
     };
  
     public String getSIDO_CODE(){
             return SIDO_CODE;
     };
  
     public String getITEM_NM(){
             return ITEM_NM;
     };
  
     public String getLINE_NUM(){
             return LINE_NUM;
     };
  
     public String getLINE_CH_NUM(){
             return LINE_CH_NUM;
     };
  
     public String getLINE_E1_NUM(){
             return LINE_E1_NUM;
     };
  
     public String getSET_DT(){
             return SET_DT;
     };
  
     public String getEQU_COST(){
             return EQU_COST;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getETC(){
             return ETC;
     };
  
     public String getSIGUNGU_CODE(){
             return SIGUNGU_CODE;
     };
  

//Setter �Լ��� �����
  
     public void setSEQ(String SEQ){
            this.SEQ=SEQ;
     };
  
     public void setSIDO_NM(String SIDO_NM){
            this.SIDO_NM=SIDO_NM;
     };
  
     public void setSIDO_CODE(String SIDO_CODE){
            this.SIDO_CODE=SIDO_CODE;
     };
  
     public void setITEM_NM(String ITEM_NM){
            this.ITEM_NM=ITEM_NM;
     };
  
     public void setLINE_NUM(String LINE_NUM){
            this.LINE_NUM=LINE_NUM;
     };
  
     public void setLINE_CH_NUM(String LINE_CH_NUM){
            this.LINE_CH_NUM=LINE_CH_NUM;
     };
  
     public void setLINE_E1_NUM(String LINE_E1_NUM){
            this.LINE_E1_NUM=LINE_E1_NUM;
     };
  
     public void setSET_DT(String SET_DT){
            this.SET_DT=SET_DT;
     };
  
     public void setEQU_COST(String EQU_COST){
            this.EQU_COST=EQU_COST;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setETC(String ETC){
            this.ETC=ETC;
     };
  
     public void setSIGUNGU_CODE(String SIGUNGU_CODE){
            this.SIGUNGU_CODE=SIGUNGU_CODE;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("SEQ:"+ this.getSEQ()+"\n");
      
      strB.append("SIDO_NM:"+ this.getSIDO_NM()+"\n");
      
      strB.append("SIDO_CODE:"+ this.getSIDO_CODE()+"\n");
      
      strB.append("ITEM_NM:"+ this.getITEM_NM()+"\n");
      
      strB.append("LINE_NUM:"+ this.getLINE_NUM()+"\n");
      
      strB.append("LINE_CH_NUM:"+ this.getLINE_CH_NUM()+"\n");
      
      strB.append("LINE_E1_NUM:"+ this.getLINE_E1_NUM()+"\n");
      
      strB.append("SET_DT:"+ this.getSET_DT()+"\n");
      
      strB.append("EQU_COST:"+ this.getEQU_COST()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("ETC:"+ this.getETC()+"\n");
      
      strB.append("SIGUNGU_CODE:"+ this.getSIGUNGU_CODE()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_C_RES_1Helper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_C_RES_1Helper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_C_RES_1Helper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_C_RES_1Helper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_C_RES_1Helper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[0];
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_C_RES_1Entity();
  }

  public ValueObject getClone(){
         PT_C_RES_1Entity newEnt = new PT_C_RES_1Entity();
	 
          newEnt.setSEQ(this.getSEQ());
         
          newEnt.setSIDO_NM(this.getSIDO_NM());
         
          newEnt.setSIDO_CODE(this.getSIDO_CODE());
         
          newEnt.setITEM_NM(this.getITEM_NM());
         
          newEnt.setLINE_NUM(this.getLINE_NUM());
         
          newEnt.setLINE_CH_NUM(this.getLINE_CH_NUM());
         
          newEnt.setLINE_E1_NUM(this.getLINE_E1_NUM());
         
          newEnt.setSET_DT(this.getSET_DT());
         
          newEnt.setEQU_COST(this.getEQU_COST());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setETC(this.getETC());
         
          newEnt.setSIGUNGU_CODE(this.getSIGUNGU_CODE());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_C_RES_1Helper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getSEQ();
        
             case 2 :
                 return  this.getSIDO_NM();
        
             case 3 :
                 return  this.getSIDO_CODE();
        
             case 4 :
                 return  this.getITEM_NM();
        
             case 5 :
                 return  this.getLINE_NUM();
        
             case 6 :
                 return  this.getLINE_CH_NUM();
        
             case 7 :
                 return  this.getLINE_E1_NUM();
        
             case 8 :
                 return  this.getSET_DT();
        
             case 9 :
                 return  this.getEQU_COST();
        
             case 10 :
                 return  this.getUPD_DT();
        
             case 11 :
                 return  this.getINS_DT();
        
             case 12 :
                 return  this.getETC();
        
             case 13 :
                 return  this.getSIGUNGU_CODE();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_C_RES_1Helper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setSEQ((String)value);
	            return;  
        
             case 2 :
                    this.setSIDO_NM((String)value);
	            return;  
        
             case 3 :
                    this.setSIDO_CODE((String)value);
	            return;  
        
             case 4 :
                    this.setITEM_NM((String)value);
	            return;  
        
             case 5 :
                    this.setLINE_NUM((String)value);
	            return;  
        
             case 6 :
                    this.setLINE_CH_NUM((String)value);
	            return;  
        
             case 7 :
                    this.setLINE_E1_NUM((String)value);
	            return;  
        
             case 8 :
                    this.setSET_DT((String)value);
	            return;  
        
             case 9 :
                    this.setEQU_COST((String)value);
	            return;  
        
             case 10 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 11 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 12 :
                    this.setETC((String)value);
	            return;  
        
             case 13 :
                    this.setSIGUNGU_CODE((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_C_RES_1Helper.toXML(this);
  }
  
}
