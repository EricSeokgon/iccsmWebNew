

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ENGINEER_CHANGE_TEMP
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SEQ  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               SEQ:NUMBER(4):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               RECV_NUM:VARCHAR2(12):  
*               ENGINEER_NM:VARCHAR2(20):  
*               ENGINEER_SSN1:VARCHAR2(18):  
*               ENGINEER_SSN2:VARCHAR2(21):  
*               EMPL_YMD:VARCHAR2(8):  
*               RET_YMD:VARCHAR2(8):  
*               REMARK:VARCHAR2(256):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               TMP_FIELD:VARCHAR2(20):  
*               CARE_BOOK_VAL_START_DT:VARCHAR2(24):  
*               CARE_BOOK_VAL_END_DT:VARCHAR2(24):  
*               ISSUE_DT:VARCHAR2(24):  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(30):  
*               CARE_BOOK_VAL_START_DT1:VARCHAR2(30):  
*               CARE_BOOK_VAL_START_DT2:VARCHAR2(30):  
*               ENG_PROC:VARCHAR2(2):  
*               ENG_TARGET:VARCHAR2(2):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_ENGINEER_CHANGE_TEMPHelper{

  final static public String SEQ = "SEQ";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String RECV_NUM = "RECV_NUM";
  final static public String ENGINEER_NM = "ENGINEER_NM";
  final static public String ENGINEER_SSN1 = "ENGINEER_SSN1";
  final static public String ENGINEER_SSN2 = "ENGINEER_SSN2";
  final static public String EMPL_YMD = "EMPL_YMD";
  final static public String RET_YMD = "RET_YMD";
  final static public String REMARK = "REMARK";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String TMP_FIELD = "TMP_FIELD";
  final static public String CARE_BOOK_VAL_START_DT = "CARE_BOOK_VAL_START_DT";
  final static public String CARE_BOOK_VAL_END_DT = "CARE_BOOK_VAL_END_DT";
  final static public String ISSUE_DT = "ISSUE_DT";
  final static public String CARE_BOOK_ISSUE_NUM = "CARE_BOOK_ISSUE_NUM";
  final static public String CARE_BOOK_VAL_START_DT1 = "CARE_BOOK_VAL_START_DT1";
  final static public String CARE_BOOK_VAL_START_DT2 = "CARE_BOOK_VAL_START_DT2";
  final static public String ENG_PROC = "ENG_PROC";
  final static public String ENG_TARGET = "ENG_TARGET";
  


  public static HashMap fieldMap = new HashMap(21);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(RECV_NUM,new Integer(3) );
  fieldMap.put(ENGINEER_NM,new Integer(4) );
  fieldMap.put(ENGINEER_SSN1,new Integer(5) );
  fieldMap.put(ENGINEER_SSN2,new Integer(6) );
  fieldMap.put(EMPL_YMD,new Integer(7) );
  fieldMap.put(RET_YMD,new Integer(8) );
  fieldMap.put(REMARK,new Integer(9) );
  fieldMap.put(WRT_ID,new Integer(10) );
  fieldMap.put(UPD_DT,new Integer(11) );
  fieldMap.put(INS_DT,new Integer(12) );
  fieldMap.put(TMP_FIELD,new Integer(13) );
  fieldMap.put(CARE_BOOK_VAL_START_DT,new Integer(14) );
  fieldMap.put(CARE_BOOK_VAL_END_DT,new Integer(15) );
  fieldMap.put(ISSUE_DT,new Integer(16) );
  fieldMap.put(CARE_BOOK_ISSUE_NUM,new Integer(17) );
  fieldMap.put(CARE_BOOK_VAL_START_DT1,new Integer(18) );
  fieldMap.put(CARE_BOOK_VAL_START_DT2,new Integer(19) );
  fieldMap.put(ENG_PROC,new Integer(20) );
  fieldMap.put(ENG_TARGET,new Integer(21) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_ENGINEER_CHANGE_TEMP";
     final public static String PREFIX = "sp.dao.PT_R_ENGINEER_CHANGE_TEMP";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SEQ,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       SEQ,TMP_WRT_NUM,RECV_NUM,ENGINEER_NM,ENGINEER_SSN1,ENGINEER_SSN2,EMPL_YMD,RET_YMD,REMARK,WRT_ID,UPD_DT,INS_DT,TMP_FIELD,CARE_BOOK_VAL_START_DT,CARE_BOOK_VAL_END_DT,ISSUE_DT,CARE_BOOK_ISSUE_NUM,CARE_BOOK_VAL_START_DT1,CARE_BOOK_VAL_START_DT2,ENG_PROC,ENG_TARGET };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_ENGINEER_CHANGE_TEMPEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_NM").append("'")
            .append(" value='").append(""+ent.getENGINEER_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_SSN1").append("'")
            .append(" value='").append(""+ent.getENGINEER_SSN1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_SSN2").append("'")
            .append(" value='").append(""+ent.getENGINEER_SSN2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("EMPL_YMD").append("'")
            .append(" value='").append(""+ent.getEMPL_YMD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RET_YMD").append("'")
            .append(" value='").append(""+ent.getRET_YMD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REMARK").append("'")
            .append(" value='").append(""+ent.getREMARK()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_FIELD").append("'")
            .append(" value='").append(""+ent.getTMP_FIELD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_START_DT").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_START_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_END_DT").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_END_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ISSUE_DT").append("'")
            .append(" value='").append(""+ent.getISSUE_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_ISSUE_NUM").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_ISSUE_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_START_DT1").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_START_DT1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_START_DT2").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_START_DT2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENG_PROC").append("'")
            .append(" value='").append(""+ent.getENG_PROC()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENG_TARGET").append("'")
            .append(" value='").append(""+ent.getENG_TARGET()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
