

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_BBS_COM_CT
*  ���̺� ���� :
*  ���̺� PK   :  
*               CT_ID
*  ���̺� �÷� :  
*               CT_ID:VARCHAR2(30):  
*               BOARD_NAME:VARCHAR2(50):  
*               BOARD_URL:VARCHAR2(128):  
*               BOARD_CATEGORY:VARCHAR2(128):  
*               BOARD_TYPE:VARCHAR2(64):  
*               BOARD_SKIN:VARCHAR2(64):  
*               BOARD_WIDTH:VARCHAR2(10):  
*               BOARD_ALIGN:VARCHAR2(20):  
*               BBS_OWNER:VARCHAR2(16):  
*               BBS_GROUP:VARCHAR2(32):  
*               BBS_DEPTH:NUMBER(5):  
*               CUT_TITLE:NUMBER(5):  
*               ROWPERPAGE:NUMBER(5):  
*               NEW_DAY:NUMBER(5):  
*               TITLE_WRT_YN:VARCHAR2(1):  
*               TITLE_DATE_YN:VARCHAR2(1):  
*               TITLE_HIT_YN:VARCHAR2(1):  
*               TITLE_IP_YN:VARCHAR2(1):  
*               HEADER_HTML:CLOB:  
*               MAIN_HTML:CLOB:  
*               BOTTOM_HTML:CLOB:  
*               LIST_LEVEL:VARCHAR2(36):  
*               READ_LEVEL:VARCHAR2(36):  
*               WRITE_LEVEL:VARCHAR2(36):  
*               ATTACH_YN:VARCHAR2(1):  
*               FILE_SIZE:NUMBER(5):  
*               ATT_NUM:NUMBER(5):  
*               REPLY_YN:VARCHAR2(1):  
*               ONE_LINE_YN:VARCHAR2(1):  
*               SECRET_YN:VARCHAR2(1):  
*               USE_YN:VARCHAR2(1):  
*               DIV_USE_YN:VARCHAR2(1):  
*               SD_DIV_YN:VARCHAR2(1):  
*               SGG_DIV_YN:VARCHAR2(1):  
*               VIEW_LIST_YN:VARCHAR2(1):  
*               ONE_ONE_YN:VARCHAR2(1):  
*               FILTER:VARCHAR2(50):  
*               TABLE_ONE_YN:VARCHAR2(1):  
*               SUBJ_1:VARCHAR2(50):  
*               SUBJ_2:VARCHAR2(50):  
*               SUBJ_3:VARCHAR2(50):  
*               SUBJ_4:VARCHAR2(50):  
*               SUBJ_5:VARCHAR2(50):  
*               SUBJ_6:VARCHAR2(50):  
*               SUBJ_7:VARCHAR2(50):  
*               SUBJ_8:VARCHAR2(50):  
*               SUBJ_9:VARCHAR2(50):  
*               SUBJ_10:VARCHAR2(50):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               PUBLIC_DIV_YN:VARCHAR2(1):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_BBS_COM_CTHelper{

  final static public String CT_ID = "CT_ID";
  final static public String BOARD_NAME = "BOARD_NAME";
  final static public String BOARD_URL = "BOARD_URL";
  final static public String BOARD_CATEGORY = "BOARD_CATEGORY";
  final static public String BOARD_TYPE = "BOARD_TYPE";
  final static public String BOARD_SKIN = "BOARD_SKIN";
  final static public String BOARD_WIDTH = "BOARD_WIDTH";
  final static public String BOARD_ALIGN = "BOARD_ALIGN";
  final static public String BBS_OWNER = "BBS_OWNER";
  final static public String BBS_GROUP = "BBS_GROUP";
  final static public String BBS_DEPTH = "BBS_DEPTH";
  final static public String CUT_TITLE = "CUT_TITLE";
  final static public String ROWPERPAGE = "ROWPERPAGE";
  final static public String NEW_DAY = "NEW_DAY";
  final static public String TITLE_WRT_YN = "TITLE_WRT_YN";
  final static public String TITLE_DATE_YN = "TITLE_DATE_YN";
  final static public String TITLE_HIT_YN = "TITLE_HIT_YN";
  final static public String TITLE_IP_YN = "TITLE_IP_YN";
  final static public String HEADER_HTML = "HEADER_HTML";
  final static public String MAIN_HTML = "MAIN_HTML";
  final static public String BOTTOM_HTML = "BOTTOM_HTML";
  final static public String LIST_LEVEL = "LIST_LEVEL";
  final static public String READ_LEVEL = "READ_LEVEL";
  final static public String WRITE_LEVEL = "WRITE_LEVEL";
  final static public String ATTACH_YN = "ATTACH_YN";
  final static public String FILE_SIZE = "FILE_SIZE";
  final static public String ATT_NUM = "ATT_NUM";
  final static public String REPLY_YN = "REPLY_YN";
  final static public String ONE_LINE_YN = "ONE_LINE_YN";
  final static public String SECRET_YN = "SECRET_YN";
  final static public String USE_YN = "USE_YN";
  final static public String DIV_USE_YN = "DIV_USE_YN";
  final static public String SD_DIV_YN = "SD_DIV_YN";
  final static public String SGG_DIV_YN = "SGG_DIV_YN";
  final static public String VIEW_LIST_YN = "VIEW_LIST_YN";
  final static public String ONE_ONE_YN = "ONE_ONE_YN";
  final static public String FILTER = "FILTER";
  final static public String TABLE_ONE_YN = "TABLE_ONE_YN";
  final static public String SUBJ_1 = "SUBJ_1";
  final static public String SUBJ_2 = "SUBJ_2";
  final static public String SUBJ_3 = "SUBJ_3";
  final static public String SUBJ_4 = "SUBJ_4";
  final static public String SUBJ_5 = "SUBJ_5";
  final static public String SUBJ_6 = "SUBJ_6";
  final static public String SUBJ_7 = "SUBJ_7";
  final static public String SUBJ_8 = "SUBJ_8";
  final static public String SUBJ_9 = "SUBJ_9";
  final static public String SUBJ_10 = "SUBJ_10";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String PUBLIC_DIV_YN = "PUBLIC_DIV_YN";
  


  public static HashMap fieldMap = new HashMap(52);
  static{
  fieldMap.put(CT_ID,new Integer(1) );
  fieldMap.put(BOARD_NAME,new Integer(2) );
  fieldMap.put(BOARD_URL,new Integer(3) );
  fieldMap.put(BOARD_CATEGORY,new Integer(4) );
  fieldMap.put(BOARD_TYPE,new Integer(5) );
  fieldMap.put(BOARD_SKIN,new Integer(6) );
  fieldMap.put(BOARD_WIDTH,new Integer(7) );
  fieldMap.put(BOARD_ALIGN,new Integer(8) );
  fieldMap.put(BBS_OWNER,new Integer(9) );
  fieldMap.put(BBS_GROUP,new Integer(10) );
  fieldMap.put(BBS_DEPTH,new Integer(11) );
  fieldMap.put(CUT_TITLE,new Integer(12) );
  fieldMap.put(ROWPERPAGE,new Integer(13) );
  fieldMap.put(NEW_DAY,new Integer(14) );
  fieldMap.put(TITLE_WRT_YN,new Integer(15) );
  fieldMap.put(TITLE_DATE_YN,new Integer(16) );
  fieldMap.put(TITLE_HIT_YN,new Integer(17) );
  fieldMap.put(TITLE_IP_YN,new Integer(18) );
  fieldMap.put(HEADER_HTML,new Integer(19) );
  fieldMap.put(MAIN_HTML,new Integer(20) );
  fieldMap.put(BOTTOM_HTML,new Integer(21) );
  fieldMap.put(LIST_LEVEL,new Integer(22) );
  fieldMap.put(READ_LEVEL,new Integer(23) );
  fieldMap.put(WRITE_LEVEL,new Integer(24) );
  fieldMap.put(ATTACH_YN,new Integer(25) );
  fieldMap.put(FILE_SIZE,new Integer(26) );
  fieldMap.put(ATT_NUM,new Integer(27) );
  fieldMap.put(REPLY_YN,new Integer(28) );
  fieldMap.put(ONE_LINE_YN,new Integer(29) );
  fieldMap.put(SECRET_YN,new Integer(30) );
  fieldMap.put(USE_YN,new Integer(31) );
  fieldMap.put(DIV_USE_YN,new Integer(32) );
  fieldMap.put(SD_DIV_YN,new Integer(33) );
  fieldMap.put(SGG_DIV_YN,new Integer(34) );
  fieldMap.put(VIEW_LIST_YN,new Integer(35) );
  fieldMap.put(ONE_ONE_YN,new Integer(36) );
  fieldMap.put(FILTER,new Integer(37) );
  fieldMap.put(TABLE_ONE_YN,new Integer(38) );
  fieldMap.put(SUBJ_1,new Integer(39) );
  fieldMap.put(SUBJ_2,new Integer(40) );
  fieldMap.put(SUBJ_3,new Integer(41) );
  fieldMap.put(SUBJ_4,new Integer(42) );
  fieldMap.put(SUBJ_5,new Integer(43) );
  fieldMap.put(SUBJ_6,new Integer(44) );
  fieldMap.put(SUBJ_7,new Integer(45) );
  fieldMap.put(SUBJ_8,new Integer(46) );
  fieldMap.put(SUBJ_9,new Integer(47) );
  fieldMap.put(SUBJ_10,new Integer(48) );
  fieldMap.put(UPD_DT,new Integer(49) );
  fieldMap.put(WRT_ID,new Integer(50) );
  fieldMap.put(INS_DT,new Integer(51) );
  fieldMap.put(PUBLIC_DIV_YN,new Integer(52) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_BBS_COM_CT";
     final public static String PREFIX = "sp.dao.PT_BBS_COM_CT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CT_ID };
     final public static String FIELD_LIST[] = { 
       CT_ID,BOARD_NAME,BOARD_URL,BOARD_CATEGORY,BOARD_TYPE,BOARD_SKIN,BOARD_WIDTH,BOARD_ALIGN,BBS_OWNER,BBS_GROUP,BBS_DEPTH,CUT_TITLE,ROWPERPAGE,NEW_DAY,TITLE_WRT_YN,TITLE_DATE_YN,TITLE_HIT_YN,TITLE_IP_YN,HEADER_HTML,MAIN_HTML,BOTTOM_HTML,LIST_LEVEL,READ_LEVEL,WRITE_LEVEL,ATTACH_YN,FILE_SIZE,ATT_NUM,REPLY_YN,ONE_LINE_YN,SECRET_YN,USE_YN,DIV_USE_YN,SD_DIV_YN,SGG_DIV_YN,VIEW_LIST_YN,ONE_ONE_YN,FILTER,TABLE_ONE_YN,SUBJ_1,SUBJ_2,SUBJ_3,SUBJ_4,SUBJ_5,SUBJ_6,SUBJ_7,SUBJ_8,SUBJ_9,SUBJ_10,UPD_DT,WRT_ID,INS_DT,PUBLIC_DIV_YN };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
             case 28 : 
	                  return  "";
             case 29 : 
	                  return  "";
             case 30 : 
	                  return  "";
             case 31 : 
	                  return  "";
             case 32 : 
	                  return  "";
             case 33 : 
	                  return  "";
             case 34 : 
	                  return  "";
             case 35 : 
	                  return  "";
             case 36 : 
	                  return  "";
             case 37 : 
	                  return  "";
             case 38 : 
	                  return  "";
             case 39 : 
	                  return  "";
             case 40 : 
	                  return  "";
             case 41 : 
	                  return  "";
             case 42 : 
	                  return  "";
             case 43 : 
	                  return  "";
             case 44 : 
	                  return  "";
             case 45 : 
	                  return  "";
             case 46 : 
	                  return  "";
             case 47 : 
	                  return  "";
             case 48 : 
	                  return  "";
             case 49 : 
	                  return  "";
             case 50 : 
	                  return  "";
             case 51 : 
	                  return  "";
             case 52 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_BBS_COM_CTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CT_ID").append("'")
            .append(" value='").append(""+ent.getCT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_NAME").append("'")
            .append(" value='").append(""+ent.getBOARD_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_URL").append("'")
            .append(" value='").append(""+ent.getBOARD_URL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_CATEGORY").append("'")
            .append(" value='").append(""+ent.getBOARD_CATEGORY()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_TYPE").append("'")
            .append(" value='").append(""+ent.getBOARD_TYPE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_SKIN").append("'")
            .append(" value='").append(""+ent.getBOARD_SKIN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_WIDTH").append("'")
            .append(" value='").append(""+ent.getBOARD_WIDTH()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOARD_ALIGN").append("'")
            .append(" value='").append(""+ent.getBOARD_ALIGN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BBS_OWNER").append("'")
            .append(" value='").append(""+ent.getBBS_OWNER()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BBS_GROUP").append("'")
            .append(" value='").append(""+ent.getBBS_GROUP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BBS_DEPTH").append("'")
            .append(" value='").append(""+ent.getBBS_DEPTH()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CUT_TITLE").append("'")
            .append(" value='").append(""+ent.getCUT_TITLE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ROWPERPAGE").append("'")
            .append(" value='").append(""+ent.getROWPERPAGE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NEW_DAY").append("'")
            .append(" value='").append(""+ent.getNEW_DAY()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TITLE_WRT_YN").append("'")
            .append(" value='").append(""+ent.getTITLE_WRT_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TITLE_DATE_YN").append("'")
            .append(" value='").append(""+ent.getTITLE_DATE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TITLE_HIT_YN").append("'")
            .append(" value='").append(""+ent.getTITLE_HIT_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TITLE_IP_YN").append("'")
            .append(" value='").append(""+ent.getTITLE_IP_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("HEADER_HTML").append("'")
            .append(" value='").append(""+ent.getHEADER_HTML()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MAIN_HTML").append("'")
            .append(" value='").append(""+ent.getMAIN_HTML()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BOTTOM_HTML").append("'")
            .append(" value='").append(""+ent.getBOTTOM_HTML()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LIST_LEVEL").append("'")
            .append(" value='").append(""+ent.getLIST_LEVEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("READ_LEVEL").append("'")
            .append(" value='").append(""+ent.getREAD_LEVEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRITE_LEVEL").append("'")
            .append(" value='").append(""+ent.getWRITE_LEVEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ATTACH_YN").append("'")
            .append(" value='").append(""+ent.getATTACH_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("FILE_SIZE").append("'")
            .append(" value='").append(""+ent.getFILE_SIZE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ATT_NUM").append("'")
            .append(" value='").append(""+ent.getATT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REPLY_YN").append("'")
            .append(" value='").append(""+ent.getREPLY_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ONE_LINE_YN").append("'")
            .append(" value='").append(""+ent.getONE_LINE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SECRET_YN").append("'")
            .append(" value='").append(""+ent.getSECRET_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USE_YN").append("'")
            .append(" value='").append(""+ent.getUSE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIV_USE_YN").append("'")
            .append(" value='").append(""+ent.getDIV_USE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SD_DIV_YN").append("'")
            .append(" value='").append(""+ent.getSD_DIV_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SGG_DIV_YN").append("'")
            .append(" value='").append(""+ent.getSGG_DIV_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("VIEW_LIST_YN").append("'")
            .append(" value='").append(""+ent.getVIEW_LIST_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ONE_ONE_YN").append("'")
            .append(" value='").append(""+ent.getONE_ONE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("FILTER").append("'")
            .append(" value='").append(""+ent.getFILTER()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TABLE_ONE_YN").append("'")
            .append(" value='").append(""+ent.getTABLE_ONE_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_1").append("'")
            .append(" value='").append(""+ent.getSUBJ_1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_2").append("'")
            .append(" value='").append(""+ent.getSUBJ_2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_3").append("'")
            .append(" value='").append(""+ent.getSUBJ_3()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_4").append("'")
            .append(" value='").append(""+ent.getSUBJ_4()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_5").append("'")
            .append(" value='").append(""+ent.getSUBJ_5()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_6").append("'")
            .append(" value='").append(""+ent.getSUBJ_6()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_7").append("'")
            .append(" value='").append(""+ent.getSUBJ_7()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_8").append("'")
            .append(" value='").append(""+ent.getSUBJ_8()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_9").append("'")
            .append(" value='").append(""+ent.getSUBJ_9()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUBJ_10").append("'")
            .append(" value='").append(""+ent.getSUBJ_10()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PUBLIC_DIV_YN").append("'")
            .append(" value='").append(""+ent.getPUBLIC_DIV_YN()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
