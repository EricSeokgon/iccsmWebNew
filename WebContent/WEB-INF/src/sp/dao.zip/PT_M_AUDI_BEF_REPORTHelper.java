

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_M_AUDI_BEF_REPORT
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ  
*               TMP_WRT_NUM  
*               WRT_NUM
*  ���̺� �÷� :  
*               SEQ:VARCHAR2(4):  
*               NOTE_CLASS_CODE:VARCHAR2(6):  
*               SEND_DT:VARCHAR2(8):  
*               S_PER:VARCHAR2(16):  
*               RECV_YN:VARCHAR2(6):  
*               REMARK:VARCHAR2(256):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               WRT_NUM:VARCHAR2(12):  
*               NOTE_NAME:VARCHAR2(50):  
*               NOTE_METHOD_CLASS:VARCHAR2(6):  
*               RECV_LOC:VARCHAR2(100):  
*               GUBUN:VARCHAR2(6):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_M_AUDI_BEF_REPORTHelper{

  final static public String SEQ = "SEQ";
  final static public String NOTE_CLASS_CODE = "NOTE_CLASS_CODE";
  final static public String SEND_DT = "SEND_DT";
  final static public String S_PER = "S_PER";
  final static public String RECV_YN = "RECV_YN";
  final static public String REMARK = "REMARK";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String WRT_NUM = "WRT_NUM";
  final static public String NOTE_NAME = "NOTE_NAME";
  final static public String NOTE_METHOD_CLASS = "NOTE_METHOD_CLASS";
  final static public String RECV_LOC = "RECV_LOC";
  final static public String GUBUN = "GUBUN";
  


  public static HashMap fieldMap = new HashMap(15);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(NOTE_CLASS_CODE,new Integer(2) );
  fieldMap.put(SEND_DT,new Integer(3) );
  fieldMap.put(S_PER,new Integer(4) );
  fieldMap.put(RECV_YN,new Integer(5) );
  fieldMap.put(REMARK,new Integer(6) );
  fieldMap.put(INS_DT,new Integer(7) );
  fieldMap.put(UPD_DT,new Integer(8) );
  fieldMap.put(WRT_ID,new Integer(9) );
  fieldMap.put(TMP_WRT_NUM,new Integer(10) );
  fieldMap.put(WRT_NUM,new Integer(11) );
  fieldMap.put(NOTE_NAME,new Integer(12) );
  fieldMap.put(NOTE_METHOD_CLASS,new Integer(13) );
  fieldMap.put(RECV_LOC,new Integer(14) );
  fieldMap.put(GUBUN,new Integer(15) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_M_AUDI_BEF_REPORT";
     final public static String PREFIX = "sp.dao.PT_M_AUDI_BEF_REPORT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ,TMP_WRT_NUM,WRT_NUM };
     final public static String FIELD_LIST[] = { 
       SEQ,NOTE_CLASS_CODE,SEND_DT,S_PER,RECV_YN,REMARK,INS_DT,UPD_DT,WRT_ID,TMP_WRT_NUM,WRT_NUM,NOTE_NAME,NOTE_METHOD_CLASS,RECV_LOC,GUBUN };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_M_AUDI_BEF_REPORTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NOTE_CLASS_CODE").append("'")
            .append(" value='").append(""+ent.getNOTE_CLASS_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEND_DT").append("'")
            .append(" value='").append(""+ent.getSEND_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("S_PER").append("'")
            .append(" value='").append(""+ent.getS_PER()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_YN").append("'")
            .append(" value='").append(""+ent.getRECV_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REMARK").append("'")
            .append(" value='").append(""+ent.getREMARK()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_NUM").append("'")
            .append(" value='").append(""+ent.getWRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NOTE_NAME").append("'")
            .append(" value='").append(""+ent.getNOTE_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NOTE_METHOD_CLASS").append("'")
            .append(" value='").append(""+ent.getNOTE_METHOD_CLASS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_LOC").append("'")
            .append(" value='").append(""+ent.getRECV_LOC()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("GUBUN").append("'")
            .append(" value='").append(""+ent.getGUBUN()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
