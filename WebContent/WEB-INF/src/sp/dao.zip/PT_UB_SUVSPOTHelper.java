

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_SUVSPOT
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE  
*               SIGUNGU_CODE
*  ���̺� �÷� :  
*               RECV_NUM:VARCHAR2(16):  
*               SUV_NAME:VARCHAR2(100):  
*               SUV_STANUM:VARCHAR2(24):  
*               SUV_NM:VARCHAR2(26):  
*               SUV_TELNUM:VARCHAR2(24):  
*               SUV_POSTNUM:VARCHAR2(6):  
*               SUV_ADDR:VARCHAR2(64):  
*               SUV_DETAILADDR:VARCHAR2(128):  
*               SIWORK_NAME:VARCHAR2(100):  
*               SIWORK_REP:VARCHAR2(25):  
*               COI_WRT_NUM:VARCHAR2(26):  
*               SIWORK_POSTNUM:VARCHAR2(6):  
*               SIWORK_ADDR:VARCHAR2(64):  
*               SIWORK_DETAILADDR:VARCHAR2(128):  
*               SPOTNM:VARCHAR2(125):  
*               SPOT_POSTNUM:VARCHAR2(6):  
*               SPOT_ADDR:VARCHAR2(64):  
*               SPOT_DETAILADDR:VARCHAR2(128):  
*               WORK_ITEM:VARCHAR2(128):  
*               USE:VARCHAR2(128):  
*               STRU_AREA:VARCHAR2(12):  
*               AREA:VARCHAR2(12):  
*               SW_DT:VARCHAR2(24):  
*               EW_DT:VARCHAR2(24):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               SIDO_CODE:VARCHAR2(4):  
*               SIGUNGU_CODE:VARCHAR2(5):  
*               SUV_MOBILE:VARCHAR2(24):  
*               SIWORK_TELNUM:VARCHAR2(24):  
*               SIWORK_MOBILE:VARCHAR2(24):  
*               DOC_YN:VARCHAR2(5):  
*               PROC_LIM:VARCHAR2(24):  
*               ORPE_NM:VARCHAR2(50):  
*               WORK_ITEM_ETC:VARCHAR2(200):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_UB_SUVSPOTHelper{

  final static public String RECV_NUM = "RECV_NUM";
  final static public String SUV_NAME = "SUV_NAME";
  final static public String SUV_STANUM = "SUV_STANUM";
  final static public String SUV_NM = "SUV_NM";
  final static public String SUV_TELNUM = "SUV_TELNUM";
  final static public String SUV_POSTNUM = "SUV_POSTNUM";
  final static public String SUV_ADDR = "SUV_ADDR";
  final static public String SUV_DETAILADDR = "SUV_DETAILADDR";
  final static public String SIWORK_NAME = "SIWORK_NAME";
  final static public String SIWORK_REP = "SIWORK_REP";
  final static public String COI_WRT_NUM = "COI_WRT_NUM";
  final static public String SIWORK_POSTNUM = "SIWORK_POSTNUM";
  final static public String SIWORK_ADDR = "SIWORK_ADDR";
  final static public String SIWORK_DETAILADDR = "SIWORK_DETAILADDR";
  final static public String SPOTNM = "SPOTNM";
  final static public String SPOT_POSTNUM = "SPOT_POSTNUM";
  final static public String SPOT_ADDR = "SPOT_ADDR";
  final static public String SPOT_DETAILADDR = "SPOT_DETAILADDR";
  final static public String WORK_ITEM = "WORK_ITEM";
  final static public String USE = "USE";
  final static public String STRU_AREA = "STRU_AREA";
  final static public String AREA = "AREA";
  final static public String SW_DT = "SW_DT";
  final static public String EW_DT = "EW_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String SIGUNGU_CODE = "SIGUNGU_CODE";
  final static public String SUV_MOBILE = "SUV_MOBILE";
  final static public String SIWORK_TELNUM = "SIWORK_TELNUM";
  final static public String SIWORK_MOBILE = "SIWORK_MOBILE";
  final static public String DOC_YN = "DOC_YN";
  final static public String PROC_LIM = "PROC_LIM";
  final static public String ORPE_NM = "ORPE_NM";
  final static public String WORK_ITEM_ETC = "WORK_ITEM_ETC";
  


  public static HashMap fieldMap = new HashMap(36);
  static{
  fieldMap.put(RECV_NUM,new Integer(1) );
  fieldMap.put(SUV_NAME,new Integer(2) );
  fieldMap.put(SUV_STANUM,new Integer(3) );
  fieldMap.put(SUV_NM,new Integer(4) );
  fieldMap.put(SUV_TELNUM,new Integer(5) );
  fieldMap.put(SUV_POSTNUM,new Integer(6) );
  fieldMap.put(SUV_ADDR,new Integer(7) );
  fieldMap.put(SUV_DETAILADDR,new Integer(8) );
  fieldMap.put(SIWORK_NAME,new Integer(9) );
  fieldMap.put(SIWORK_REP,new Integer(10) );
  fieldMap.put(COI_WRT_NUM,new Integer(11) );
  fieldMap.put(SIWORK_POSTNUM,new Integer(12) );
  fieldMap.put(SIWORK_ADDR,new Integer(13) );
  fieldMap.put(SIWORK_DETAILADDR,new Integer(14) );
  fieldMap.put(SPOTNM,new Integer(15) );
  fieldMap.put(SPOT_POSTNUM,new Integer(16) );
  fieldMap.put(SPOT_ADDR,new Integer(17) );
  fieldMap.put(SPOT_DETAILADDR,new Integer(18) );
  fieldMap.put(WORK_ITEM,new Integer(19) );
  fieldMap.put(USE,new Integer(20) );
  fieldMap.put(STRU_AREA,new Integer(21) );
  fieldMap.put(AREA,new Integer(22) );
  fieldMap.put(SW_DT,new Integer(23) );
  fieldMap.put(EW_DT,new Integer(24) );
  fieldMap.put(WRT_ID,new Integer(25) );
  fieldMap.put(INS_DT,new Integer(26) );
  fieldMap.put(UPD_DT,new Integer(27) );
  fieldMap.put(SIDO_CODE,new Integer(28) );
  fieldMap.put(SIGUNGU_CODE,new Integer(29) );
  fieldMap.put(SUV_MOBILE,new Integer(30) );
  fieldMap.put(SIWORK_TELNUM,new Integer(31) );
  fieldMap.put(SIWORK_MOBILE,new Integer(32) );
  fieldMap.put(DOC_YN,new Integer(33) );
  fieldMap.put(PROC_LIM,new Integer(34) );
  fieldMap.put(ORPE_NM,new Integer(35) );
  fieldMap.put(WORK_ITEM_ETC,new Integer(36) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_UB_SUVSPOT";
     final public static String PREFIX = "sp.dao.PT_UB_SUVSPOT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SIDO_CODE,SIGUNGU_CODE };
     final public static String FIELD_LIST[] = { 
       RECV_NUM,SUV_NAME,SUV_STANUM,SUV_NM,SUV_TELNUM,SUV_POSTNUM,SUV_ADDR,SUV_DETAILADDR,SIWORK_NAME,SIWORK_REP,COI_WRT_NUM,SIWORK_POSTNUM,SIWORK_ADDR,SIWORK_DETAILADDR,SPOTNM,SPOT_POSTNUM,SPOT_ADDR,SPOT_DETAILADDR,WORK_ITEM,USE,STRU_AREA,AREA,SW_DT,EW_DT,WRT_ID,INS_DT,UPD_DT,SIDO_CODE,SIGUNGU_CODE,SUV_MOBILE,SIWORK_TELNUM,SIWORK_MOBILE,DOC_YN,PROC_LIM,ORPE_NM,WORK_ITEM_ETC };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
             case 28 : 
	                  return  "";
             case 29 : 
	                  return  "";
             case 30 : 
	                  return  "";
             case 31 : 
	                  return  "";
             case 32 : 
	                  return  "";
             case 33 : 
	                  return  "";
             case 34 : 
	                  return  "";
             case 35 : 
	                  return  "";
             case 36 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_UB_SUVSPOTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_NAME").append("'")
            .append(" value='").append(""+ent.getSUV_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_STANUM").append("'")
            .append(" value='").append(""+ent.getSUV_STANUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_NM").append("'")
            .append(" value='").append(""+ent.getSUV_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_TELNUM").append("'")
            .append(" value='").append(""+ent.getSUV_TELNUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_POSTNUM").append("'")
            .append(" value='").append(""+ent.getSUV_POSTNUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_ADDR").append("'")
            .append(" value='").append(""+ent.getSUV_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_DETAILADDR").append("'")
            .append(" value='").append(""+ent.getSUV_DETAILADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_NAME").append("'")
            .append(" value='").append(""+ent.getSIWORK_NAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_REP").append("'")
            .append(" value='").append(""+ent.getSIWORK_REP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COI_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getCOI_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_POSTNUM").append("'")
            .append(" value='").append(""+ent.getSIWORK_POSTNUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_ADDR").append("'")
            .append(" value='").append(""+ent.getSIWORK_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_DETAILADDR").append("'")
            .append(" value='").append(""+ent.getSIWORK_DETAILADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOTNM").append("'")
            .append(" value='").append(""+ent.getSPOTNM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOT_POSTNUM").append("'")
            .append(" value='").append(""+ent.getSPOT_POSTNUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOT_ADDR").append("'")
            .append(" value='").append(""+ent.getSPOT_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SPOT_DETAILADDR").append("'")
            .append(" value='").append(""+ent.getSPOT_DETAILADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WORK_ITEM").append("'")
            .append(" value='").append(""+ent.getWORK_ITEM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USE").append("'")
            .append(" value='").append(""+ent.getUSE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("STRU_AREA").append("'")
            .append(" value='").append(""+ent.getSTRU_AREA()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("AREA").append("'")
            .append(" value='").append(""+ent.getAREA()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SW_DT").append("'")
            .append(" value='").append(""+ent.getSW_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("EW_DT").append("'")
            .append(" value='").append(""+ent.getEW_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIGUNGU_CODE").append("'")
            .append(" value='").append(""+ent.getSIGUNGU_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SUV_MOBILE").append("'")
            .append(" value='").append(""+ent.getSUV_MOBILE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_TELNUM").append("'")
            .append(" value='").append(""+ent.getSIWORK_TELNUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIWORK_MOBILE").append("'")
            .append(" value='").append(""+ent.getSIWORK_MOBILE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DOC_YN").append("'")
            .append(" value='").append(""+ent.getDOC_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PROC_LIM").append("'")
            .append(" value='").append(""+ent.getPROC_LIM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ORPE_NM").append("'")
            .append(" value='").append(""+ent.getORPE_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WORK_ITEM_ETC").append("'")
            .append(" value='").append(""+ent.getWORK_ITEM_ETC()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
