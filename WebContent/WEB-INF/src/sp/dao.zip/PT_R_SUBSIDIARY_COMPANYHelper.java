

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_SUBSIDIARY_COMPANY
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(4):  
*               OTOB_COM_NUM:VARCHAR2(12):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               RECV_NUM:VARCHAR2(12):  
*               OTOB_COM_CODE:VARCHAR2(6):  
*               SIDO_CODE:VARCHAR2(4):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_SUBSIDIARY_COMPANYHelper{

  final static public String SEQ = "SEQ";
  final static public String OTOB_COM_NUM = "OTOB_COM_NUM";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String RECV_NUM = "RECV_NUM";
  final static public String OTOB_COM_CODE = "OTOB_COM_CODE";
  final static public String SIDO_CODE = "SIDO_CODE";
  


  public static HashMap fieldMap = new HashMap(8);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(OTOB_COM_NUM,new Integer(2) );
  fieldMap.put(WRT_ID,new Integer(3) );
  fieldMap.put(UPD_DT,new Integer(4) );
  fieldMap.put(INS_DT,new Integer(5) );
  fieldMap.put(RECV_NUM,new Integer(6) );
  fieldMap.put(OTOB_COM_CODE,new Integer(7) );
  fieldMap.put(SIDO_CODE,new Integer(8) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_SUBSIDIARY_COMPANY";
     final public static String PREFIX = "sp.dao.PT_R_SUBSIDIARY_COMPANY";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,OTOB_COM_NUM,WRT_ID,UPD_DT,INS_DT,RECV_NUM,OTOB_COM_CODE,SIDO_CODE };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_SUBSIDIARY_COMPANYEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OTOB_COM_NUM").append("'")
            .append(" value='").append(""+ent.getOTOB_COM_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OTOB_COM_CODE").append("'")
            .append(" value='").append(""+ent.getOTOB_COM_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
