

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_CREDIT
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               SEQ:NUMBER(4):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               LICTAX_PAYAOM:VARCHAR2(12):  
*               LICTAX_PAY_CO_DT:VARCHAR2(8):  
*               HOS_CRE_AOM:VARCHAR2(12):  
*               HOS_CRE_PAY_CO_DT:VARCHAR2(8):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_CREDITHelper{

  final static public String SEQ = "SEQ";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String LICTAX_PAYAOM = "LICTAX_PAYAOM";
  final static public String LICTAX_PAY_CO_DT = "LICTAX_PAY_CO_DT";
  final static public String HOS_CRE_AOM = "HOS_CRE_AOM";
  final static public String HOS_CRE_PAY_CO_DT = "HOS_CRE_PAY_CO_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_DT = "WRT_DT";
  


  public static HashMap fieldMap = new HashMap(9);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(TMP_WRT_NUM,new Integer(2) );
  fieldMap.put(LICTAX_PAYAOM,new Integer(3) );
  fieldMap.put(LICTAX_PAY_CO_DT,new Integer(4) );
  fieldMap.put(HOS_CRE_AOM,new Integer(5) );
  fieldMap.put(HOS_CRE_PAY_CO_DT,new Integer(6) );
  fieldMap.put(WRT_ID,new Integer(7) );
  fieldMap.put(UPD_DT,new Integer(8) );
  fieldMap.put(WRT_DT,new Integer(9) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_CREDIT";
     final public static String PREFIX = "sp.dao.PT_R_CREDIT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       SEQ,TMP_WRT_NUM,LICTAX_PAYAOM,LICTAX_PAY_CO_DT,HOS_CRE_AOM,HOS_CRE_PAY_CO_DT,WRT_ID,UPD_DT,WRT_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_CREDITEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LICTAX_PAYAOM").append("'")
            .append(" value='").append(""+ent.getLICTAX_PAYAOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LICTAX_PAY_CO_DT").append("'")
            .append(" value='").append(""+ent.getLICTAX_PAY_CO_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("HOS_CRE_AOM").append("'")
            .append(" value='").append(""+ent.getHOS_CRE_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("HOS_CRE_PAY_CO_DT").append("'")
            .append(" value='").append(""+ent.getHOS_CRE_PAY_CO_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
