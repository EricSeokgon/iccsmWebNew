

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ENGINEER_MASTER
*  ���̺� ���� :
*  ���̺� PK   :  
*               CARE_BOOK_ISSUE_NUM
*  ���̺� �÷� :  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(12):  
*               ENGINEER_SSN1:VARCHAR2(18):  
*               ENGINEER_SSN2:VARCHAR2(21):  
*               WRT_NUM:VARCHAR2(12):  
*               ENGINEER_GRADE:VARCHAR2(10):  
*               ENGINEER_CLASS:VARCHAR2(10):  
*               QUAL_ITEM:VARCHAR2(15):  
*               NM_KOR:VARCHAR2(20):  
*               NM_HAN:VARCHAR2(20):  
*               CARE_BOOK_VAL_START_DT:VARCHAR2(24):  
*               CARE_BOOK_VAL_END_DT:VARCHAR2(24):  
*               EDU_COMP_DT:VARCHAR2(24):  
*               POST_NUM:VARCHAR2(7):  
*               ADDR:VARCHAR2(20):  
*               DETAIL_ADDR:VARCHAR2(20):  
*               GROUP_CODE:VARCHAR2(10):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_ENGINEER_MASTERHelper{

  final static public String CARE_BOOK_ISSUE_NUM = "CARE_BOOK_ISSUE_NUM";
  final static public String ENGINEER_SSN1 = "ENGINEER_SSN1";
  final static public String ENGINEER_SSN2 = "ENGINEER_SSN2";
  final static public String WRT_NUM = "WRT_NUM";
  final static public String ENGINEER_GRADE = "ENGINEER_GRADE";
  final static public String ENGINEER_CLASS = "ENGINEER_CLASS";
  final static public String QUAL_ITEM = "QUAL_ITEM";
  final static public String NM_KOR = "NM_KOR";
  final static public String NM_HAN = "NM_HAN";
  final static public String CARE_BOOK_VAL_START_DT = "CARE_BOOK_VAL_START_DT";
  final static public String CARE_BOOK_VAL_END_DT = "CARE_BOOK_VAL_END_DT";
  final static public String EDU_COMP_DT = "EDU_COMP_DT";
  final static public String POST_NUM = "POST_NUM";
  final static public String ADDR = "ADDR";
  final static public String DETAIL_ADDR = "DETAIL_ADDR";
  final static public String GROUP_CODE = "GROUP_CODE";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String WRT_DT = "WRT_DT";
  


  public static HashMap fieldMap = new HashMap(19);
  static{
  fieldMap.put(CARE_BOOK_ISSUE_NUM,new Integer(1) );
  fieldMap.put(ENGINEER_SSN1,new Integer(2) );
  fieldMap.put(ENGINEER_SSN2,new Integer(3) );
  fieldMap.put(WRT_NUM,new Integer(4) );
  fieldMap.put(ENGINEER_GRADE,new Integer(5) );
  fieldMap.put(ENGINEER_CLASS,new Integer(6) );
  fieldMap.put(QUAL_ITEM,new Integer(7) );
  fieldMap.put(NM_KOR,new Integer(8) );
  fieldMap.put(NM_HAN,new Integer(9) );
  fieldMap.put(CARE_BOOK_VAL_START_DT,new Integer(10) );
  fieldMap.put(CARE_BOOK_VAL_END_DT,new Integer(11) );
  fieldMap.put(EDU_COMP_DT,new Integer(12) );
  fieldMap.put(POST_NUM,new Integer(13) );
  fieldMap.put(ADDR,new Integer(14) );
  fieldMap.put(DETAIL_ADDR,new Integer(15) );
  fieldMap.put(GROUP_CODE,new Integer(16) );
  fieldMap.put(WRT_ID,new Integer(17) );
  fieldMap.put(UPD_DT,new Integer(18) );
  fieldMap.put(WRT_DT,new Integer(19) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_ENGINEER_MASTER";
     final public static String PREFIX = "sp.dao.PT_R_ENGINEER_MASTER";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       CARE_BOOK_ISSUE_NUM };
     final public static String FIELD_LIST[] = { 
       CARE_BOOK_ISSUE_NUM,ENGINEER_SSN1,ENGINEER_SSN2,WRT_NUM,ENGINEER_GRADE,ENGINEER_CLASS,QUAL_ITEM,NM_KOR,NM_HAN,CARE_BOOK_VAL_START_DT,CARE_BOOK_VAL_END_DT,EDU_COMP_DT,POST_NUM,ADDR,DETAIL_ADDR,GROUP_CODE,WRT_ID,UPD_DT,WRT_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_ENGINEER_MASTEREntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_ISSUE_NUM").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_ISSUE_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_SSN1").append("'")
            .append(" value='").append(""+ent.getENGINEER_SSN1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_SSN2").append("'")
            .append(" value='").append(""+ent.getENGINEER_SSN2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_NUM").append("'")
            .append(" value='").append(""+ent.getWRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_GRADE").append("'")
            .append(" value='").append(""+ent.getENGINEER_GRADE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ENGINEER_CLASS").append("'")
            .append(" value='").append(""+ent.getENGINEER_CLASS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("QUAL_ITEM").append("'")
            .append(" value='").append(""+ent.getQUAL_ITEM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NM_KOR").append("'")
            .append(" value='").append(""+ent.getNM_KOR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NM_HAN").append("'")
            .append(" value='").append(""+ent.getNM_HAN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_START_DT").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_START_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CARE_BOOK_VAL_END_DT").append("'")
            .append(" value='").append(""+ent.getCARE_BOOK_VAL_END_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("EDU_COMP_DT").append("'")
            .append(" value='").append(""+ent.getEDU_COMP_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("POST_NUM").append("'")
            .append(" value='").append(""+ent.getPOST_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR").append("'")
            .append(" value='").append(""+ent.getADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DETAIL_ADDR").append("'")
            .append(" value='").append(""+ent.getDETAIL_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("GROUP_CODE").append("'")
            .append(" value='").append(""+ent.getGROUP_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
