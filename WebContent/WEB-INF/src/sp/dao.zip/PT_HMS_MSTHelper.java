

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_HMS_MST
*  ���̺� ���� :
*  ���̺� PK   :  
*               MENU_ID
*  ���̺� �÷� :  
*               MENU_ID:VARCHAR2(32):  
*               L_MENU_CD:VARCHAR2(64):  
*               M_MENU_CD:VARCHAR2(64):  
*               S_MENU_CD:VARCHAR2(64):  
*               TITLE:VARCHAR2(32):  
*               URL:VARCHAR2(64):  
*               WRT_ID:VARCHAR2(16):  
*               WRT_NM:VARCHAR2(16):  
*               UDP_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_HMS_MSTHelper{

  final static public String MENU_ID = "MENU_ID";
  final static public String L_MENU_CD = "L_MENU_CD";
  final static public String M_MENU_CD = "M_MENU_CD";
  final static public String S_MENU_CD = "S_MENU_CD";
  final static public String TITLE = "TITLE";
  final static public String URL = "URL";
  final static public String WRT_ID = "WRT_ID";
  final static public String WRT_NM = "WRT_NM";
  final static public String UDP_DT = "UDP_DT";
  final static public String INS_DT = "INS_DT";
  


  public static HashMap fieldMap = new HashMap(10);
  static{
  fieldMap.put(MENU_ID,new Integer(1) );
  fieldMap.put(L_MENU_CD,new Integer(2) );
  fieldMap.put(M_MENU_CD,new Integer(3) );
  fieldMap.put(S_MENU_CD,new Integer(4) );
  fieldMap.put(TITLE,new Integer(5) );
  fieldMap.put(URL,new Integer(6) );
  fieldMap.put(WRT_ID,new Integer(7) );
  fieldMap.put(WRT_NM,new Integer(8) );
  fieldMap.put(UDP_DT,new Integer(9) );
  fieldMap.put(INS_DT,new Integer(10) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_HMS_MST";
     final public static String PREFIX = "sp.dao.PT_HMS_MST";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       MENU_ID };
     final public static String FIELD_LIST[] = { 
       MENU_ID,L_MENU_CD,M_MENU_CD,S_MENU_CD,TITLE,URL,WRT_ID,WRT_NM,UDP_DT,INS_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_HMS_MSTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MENU_ID").append("'")
            .append(" value='").append(""+ent.getMENU_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("L_MENU_CD").append("'")
            .append(" value='").append(""+ent.getL_MENU_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("M_MENU_CD").append("'")
            .append(" value='").append(""+ent.getM_MENU_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("S_MENU_CD").append("'")
            .append(" value='").append(""+ent.getS_MENU_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TITLE").append("'")
            .append(" value='").append(""+ent.getTITLE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("URL").append("'")
            .append(" value='").append(""+ent.getURL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_NM").append("'")
            .append(" value='").append(""+ent.getWRT_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UDP_DT").append("'")
            .append(" value='").append(""+ent.getUDP_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
