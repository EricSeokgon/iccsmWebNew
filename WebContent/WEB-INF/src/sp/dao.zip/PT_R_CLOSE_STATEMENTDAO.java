


/*
*  Automatic generated  source
*  ��  ��  �� : ����
*
*  ���̺� ��   :PT_R_CLOSE_STATEMENT
*  ���̺� ���� :
*  ���̺� PK   :
*               RECV_NUM
*  ���̺� �÷� :
*               RECV_NUM:VARCHAR2(12):
*               SIDO_CODE:VARCHAR2(4):
*               COI_WRT_NUM:VARCHAR2(12):
*               RECV_DT:VARCHAR2(8):
*               PROC_LIM:VARCHAR2(8):
*               OFFI_PART:VARCHAR2(50):
*               OFFI_PART_REBO_WRT_NUM:VARCHAR2(12):
*               NAME:VARCHAR2(50):
*               WRT_NUM:VARCHAR2(12):
*               REP_NM_KOR:VARCHAR2(20):
*               REP_NM_HAN:VARCHAR2(20):
*               OFF_ADDR:VARCHAR2(200):
*               TEL_NUM:VARCHAR2(17):
*               C_COM_YMD:VARCHAR2(8):
*               WRT_ID:VARCHAR2(16):
*               UPD_DT:VARCHAR2(24):
*               INS_DT:VARCHAR2(24):
*               C_COM_CAUSE:VARCHAR2(256):
*               ADDR_POST_NUM:VARCHAR2(6):
*               ADDR_ADDR:VARCHAR2(100):
*               ADDR_DETAIL_ADDR:VARCHAR2(100):
*               DEFI_STE:VARCHAR2(1):
*/
package sp.dao;

import kjf.util.*;
import kjf.ops.*;

import java.io.*;
import java.text.*;
import java.util.*;
import java.sql.*;


public class PT_R_CLOSE_STATEMENTDAO  extends SuperToDB{

  private String default_fields[]={ "RECV_NUM" , "SIDO_CODE" , "COI_WRT_NUM" , "RECV_DT" , "PROC_LIM" , "OFFI_PART" , "OFFI_PART_REBO_WRT_NUM" , "NAME" , "WRT_NUM" , "REP_NM_KOR" , "REP_NM_HAN" , "OFF_ADDR" , "TEL_NUM" , "C_COM_YMD" , "WRT_ID" , "UPD_DT" , "INS_DT" , "C_COM_CAUSE" , "ADDR_POST_NUM" , "ADDR_ADDR" , "ADDR_DETAIL_ADDR" , "DEFI_STE" };	

  public int insert( ValueObject  obj) throws SQLException{

    if((obj instanceof PT_R_CLOSE_STATEMENTEntity) == false){
        throw new  SQLException("DAO ����(1): PT_R_CLOSE_STATEMENT : insert() ");
    }
    PT_R_CLOSE_STATEMENTEntity entity = (PT_R_CLOSE_STATEMENTEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

  StringBuffer sb = new StringBuffer();
  sb.append("insert into PT_R_CLOSE_STATEMENT ")
    .append(" ( RECV_NUM,SIDO_CODE,COI_WRT_NUM,RECV_DT,PROC_LIM,OFFI_PART,OFFI_PART_REBO_WRT_NUM,NAME,WRT_NUM,REP_NM_KOR,REP_NM_HAN,OFF_ADDR,TEL_NUM,C_COM_YMD,WRT_ID,UPD_DT,INS_DT,C_COM_CAUSE,ADDR_POST_NUM,ADDR_ADDR,ADDR_DETAIL_ADDR,DEFI_STE ) ")
    .append(" values ( ")
      
           .append(toDB(entity.getRECV_NUM()))
			.append(",")
           .append(toDB(entity.getSIDO_CODE()))
			.append(",")
           .append(toDB(entity.getCOI_WRT_NUM()))
			.append(",")
           .append(toDB(entity.getRECV_DT()))
			.append(",")
           .append(toDB(entity.getPROC_LIM()))
			.append(",")
           .append(toDB(entity.getOFFI_PART()))
			.append(",")
           .append(toDB(entity.getOFFI_PART_REBO_WRT_NUM()))
			.append(",")
           .append(toDB(entity.getNAME()))
			.append(",")
           .append(toDB(entity.getWRT_NUM()))
			.append(",")
           .append(toDB(entity.getREP_NM_KOR()))
			.append(",")
           .append(toDB(entity.getREP_NM_HAN()))
			.append(",")
           .append(toDB(entity.getOFF_ADDR()))
			.append(",")
           .append(toDB(entity.getTEL_NUM()))
			.append(",")
           .append(toDB(entity.getC_COM_YMD()))
			.append(",")
           .append(toDB(entity.getWRT_ID()))
			.append(",")
           .append(toDB(entity.getUPD_DT()))
			.append(",")
           .append(toDB(entity.getINS_DT()))
			.append(",")
           .append(toDB(entity.getC_COM_CAUSE()))
			.append(",")
           .append(toDB(entity.getADDR_POST_NUM()))
			.append(",")
           .append(toDB(entity.getADDR_ADDR()))
			.append(",")
           .append(toDB(entity.getADDR_DETAIL_ADDR()))
			.append(",")
           .append(toDB(entity.getDEFI_STE()))
			
    .append(" ) ");

   KJFLog.sql(sb.toString());


   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

    int i=1;
	
    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;

   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }
    return result ;
  }

  public int  update( ValueObject obj) throws SQLException{


    if((obj instanceof PT_R_CLOSE_STATEMENTEntity) == false){
        throw new  SQLException("DAO ����(1): PT_R_CLOSE_STATEMENT : update() ");
    }
    PT_R_CLOSE_STATEMENTEntity entity = (PT_R_CLOSE_STATEMENTEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_R_CLOSE_STATEMENT  set ")
       
        .append("SIDO_CODE = ")
        .append(toDB(entity.getSIDO_CODE())).append(",")
        .append("COI_WRT_NUM = ")
        .append(toDB(entity.getCOI_WRT_NUM())).append(",")
        .append("RECV_DT = ")
        .append(toDB(entity.getRECV_DT())).append(",")
        .append("PROC_LIM = ")
        .append(toDB(entity.getPROC_LIM())).append(",")
        .append("OFFI_PART = ")
        .append(toDB(entity.getOFFI_PART())).append(",")
        .append("OFFI_PART_REBO_WRT_NUM = ")
        .append(toDB(entity.getOFFI_PART_REBO_WRT_NUM())).append(",")
        .append("NAME = ")
        .append(toDB(entity.getNAME())).append(",")
        .append("WRT_NUM = ")
        .append(toDB(entity.getWRT_NUM())).append(",")
        .append("REP_NM_KOR = ")
        .append(toDB(entity.getREP_NM_KOR())).append(",")
        .append("REP_NM_HAN = ")
        .append(toDB(entity.getREP_NM_HAN())).append(",")
        .append("OFF_ADDR = ")
        .append(toDB(entity.getOFF_ADDR())).append(",")
        .append("TEL_NUM = ")
        .append(toDB(entity.getTEL_NUM())).append(",")
        .append("C_COM_YMD = ")
        .append(toDB(entity.getC_COM_YMD())).append(",")
        .append("WRT_ID = ")
        .append(toDB(entity.getWRT_ID())).append(",")
        .append("UPD_DT = ")
        .append(toDB(entity.getUPD_DT())).append(",")
        .append("INS_DT = ")
        .append(toDB(entity.getINS_DT())).append(",")
        .append("C_COM_CAUSE = ")
        .append(toDB(entity.getC_COM_CAUSE())).append(",")
        .append("ADDR_POST_NUM = ")
        .append(toDB(entity.getADDR_POST_NUM())).append(",")
        .append("ADDR_ADDR = ")
        .append(toDB(entity.getADDR_ADDR())).append(",")
        .append("ADDR_DETAIL_ADDR = ")
        .append(toDB(entity.getADDR_DETAIL_ADDR())).append(",")
        .append("DEFI_STE = ")
        .append(toDB(entity.getDEFI_STE()))
        .append(" where  1=1 ");
       
         sb.append(" and RECV_NUM = ").append( toDB(entity.getRECV_NUM()));
         

   KJFLog.sql(sb.toString());

   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int i=1;
	
    result =ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

    return result ;
  }

  public static HashMap default_update_field= new HashMap(0);
  static{
     
  }

  ///////////////////////////////////////////////////////////////////////////////////
  //������ �ʵ常�� �����Ѵ�.
  public int updateModifiedOnly(ValueObject obj, String[] fields) throws SQLException{



    if((obj instanceof PT_R_CLOSE_STATEMENTEntity) == false){
        throw new  SQLException("DAO ����(1): PT_R_CLOSE_STATEMENT : updateModifiedOnly() ");
    }
    PT_R_CLOSE_STATEMENTEntity entity = (PT_R_CLOSE_STATEMENTEntity)obj;

	HashMap clobs = new HashMap();
	

	Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_R_CLOSE_STATEMENT  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     

   KJFLog.sql( sb.toString());

    try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int k=1;
    for(int i=0 ; i < fields.length ; i++){
       if(clobs.containsKey(fields[i])){
    	   
    	   ps.setString(k++,(entity.getByName(fields[i])).toString() );
       }
    }

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

	return result ;
  }


  ///////////////////////////////////////////////////////////////////////////////////
  //Ư���ʵ带 ������ ��ü �ʵ带 �����Ѵ�.
  public int updateExcludeOnly(ValueObject obj, String[] fields) throws SQLException{

	fields= KJFUtil.getDifferenceOfSets(default_fields, fields);

    if((obj instanceof PT_R_CLOSE_STATEMENTEntity) == false){
        throw new  SQLException("DAO ����(1): PT_R_CLOSE_STATEMENT : updateModifiedOnly() ");
    }
    PT_R_CLOSE_STATEMENTEntity entity = (PT_R_CLOSE_STATEMENTEntity)obj;

	HashMap clobs = new HashMap();
	

	Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    if(fields==null)
	         throw new  SQLException("Field Name can not be Null");

    StringBuffer setString = new StringBuffer();
    boolean flag = false;
    for(int i=0 ; i < fields.length ; i++){
        if(fields[i] == null) throw new  SQLException("Field Name can not be Null");
        if(default_update_field.containsKey(fields[i]) == false){
           if(flag)
               setString.append(",");
           flag = true;
           if(clobs.containsKey(fields[i])){
        	   setString.append(fields[i]).append("=?") ;
           }else{
        	   setString.append(fields[i]).append("=").append(toDB(entity.getByName(fields[i]))) ;
           }
        }
    }
    if(flag = false)
       throw new  SQLException("Nothing to update");

    

    StringBuffer sb = new StringBuffer();
    sb.append("update PT_R_CLOSE_STATEMENT  set " )
      .append( setString.toString() ).append( " where  1=1 ");
     
	  sb.append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()));
     

   KJFLog.sql( sb.toString());

    try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

	int k=1;
    for(int i=0 ; i < fields.length ; i++){
       if(clobs.containsKey(fields[i])){
    	   
    	   ps.setString(k++,(entity.getByName(fields[i])).toString() );
       }
    }

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

	return result ;
  }
  public int delete(ValueObject obj) throws SQLException{

    if((obj instanceof PT_R_CLOSE_STATEMENTEntity) == false){
        throw new  SQLException("DAO ����(1): PT_R_CLOSE_STATEMENT : delete() ");
    }
    PT_R_CLOSE_STATEMENTEntity entity = (PT_R_CLOSE_STATEMENTEntity)obj;

    Connection conn = null;
    PreparedStatement  ps  =null;
    int result = 0;

    StringBuffer sb = new StringBuffer();
    sb.append("delete from PT_R_CLOSE_STATEMENT  where  1=1")
      
	  .append(" and RECV_NUM = ").append(toDB(entity.getRECV_NUM()))
       ;

   KJFLog.sql(sb.toString());


   try {

    conn = this.getConnection();
    ps = conn.prepareStatement(sb.toString());

    result = ps.executeUpdate();

   } catch (SQLException e) {
           throw e;
   } finally {
     if(ps!=null)
        ps.close();
     this.release(conn);
   }

   return result;
  }



}//Class End
