

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_CHANGE_STATEMENT
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE
*  ���̺� �÷� :  
*               RECV_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               RECV_DT:VARCHAR2(8):  
*               RECV_TIME:VARCHAR2(4):  
*               PROC_LIM:VARCHAR2(8):  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               COV_DT:VARCHAR2(8):  
*               COM_NUM:VARCHAR2(13):  
*               DEFI_STE:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_CHANGE_STATEMENTHelper{

  final static public String RECV_NUM = "RECV_NUM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String RECV_DT = "RECV_DT";
  final static public String RECV_TIME = "RECV_TIME";
  final static public String PROC_LIM = "PROC_LIM";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String COV_DT = "COV_DT";
  final static public String COM_NUM = "COM_NUM";
  final static public String DEFI_STE = "DEFI_STE";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  


  public static HashMap fieldMap = new HashMap(12);
  static{
  fieldMap.put(RECV_NUM,new Integer(1) );
  fieldMap.put(SIDO_CODE,new Integer(2) );
  fieldMap.put(RECV_DT,new Integer(3) );
  fieldMap.put(RECV_TIME,new Integer(4) );
  fieldMap.put(PROC_LIM,new Integer(5) );
  fieldMap.put(TMP_WRT_NUM,new Integer(6) );
  fieldMap.put(COV_DT,new Integer(7) );
  fieldMap.put(COM_NUM,new Integer(8) );
  fieldMap.put(DEFI_STE,new Integer(9) );
  fieldMap.put(WRT_ID,new Integer(10) );
  fieldMap.put(INS_DT,new Integer(11) );
  fieldMap.put(UPD_DT,new Integer(12) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_CHANGE_STATEMENT";
     final public static String PREFIX = "sp.dao.PT_R_CHANGE_STATEMENT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SIDO_CODE };
     final public static String FIELD_LIST[] = { 
       RECV_NUM,SIDO_CODE,RECV_DT,RECV_TIME,PROC_LIM,TMP_WRT_NUM,COV_DT,COM_NUM,DEFI_STE,WRT_ID,INS_DT,UPD_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_CHANGE_STATEMENTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_DT").append("'")
            .append(" value='").append(""+ent.getRECV_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_TIME").append("'")
            .append(" value='").append(""+ent.getRECV_TIME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PROC_LIM").append("'")
            .append(" value='").append(""+ent.getPROC_LIM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COV_DT").append("'")
            .append(" value='").append(""+ent.getCOV_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COM_NUM").append("'")
            .append(" value='").append(""+ent.getCOM_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DEFI_STE").append("'")
            .append(" value='").append(""+ent.getDEFI_STE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
