

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ENGINEER_M_CAREER
*  ���̺� ���� :
*  ���̺� PK   :  
*               CARE_BOOK_ISSUE_NUM  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:VARCHAR2(12):  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(12):  
*               POW:VARCHAR2(10):  
*               CARETERM_START_DT:VARCHAR2(8):  
*               CARETERM_END_DT:VARCHAR2(8):  
*               OFF_WORK:VARCHAR2(20):  
*               EXCH_CARE:VARCHAR2(6):  
*               CARE_TOT:VARCHAR2(6):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               ETC1:VARCHAR2(30):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_R_ENGINEER_M_CAREEREntity extends ValueObject{

  
     private String SEQ;
  
     private String CARE_BOOK_ISSUE_NUM;
  
     private String POW;
  
     private String CARETERM_START_DT;
  
     private String CARETERM_END_DT;
  
     private String OFF_WORK;
  
     private String EXCH_CARE;
  
     private String CARE_TOT;
  
     private String WRT_ID;
  
     private String UPD_DT;
  
     private String INS_DT;
  
     private String ETC1;
  

//�����ڸ� �����
    public PT_R_ENGINEER_M_CAREEREntity(){
    }
    
    
    public PT_R_ENGINEER_M_CAREEREntity(String CARE_BOOK_ISSUE_NUM,String SEQ ){
       this.setCARE_BOOK_ISSUE_NUM(CARE_BOOK_ISSUE_NUM);
       this.setSEQ(SEQ);
       
    }
      
    public PT_R_ENGINEER_M_CAREEREntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("CARE_BOOK_ISSUE_NUM");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("CARE_BOOK_ISSUE_NUM",value);
       
       value = ent.getByName("SEQ");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SEQ",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.SEQ =request.getParameter("SEQ");
		this.CARE_BOOK_ISSUE_NUM =request.getParameter("CARE_BOOK_ISSUE_NUM");
		this.POW =request.getParameter("POW");
		this.CARETERM_START_DT =request.getParameter("CARETERM_START_DT");
		this.CARETERM_END_DT =request.getParameter("CARETERM_END_DT");
		this.OFF_WORK =request.getParameter("OFF_WORK");
		this.EXCH_CARE =request.getParameter("EXCH_CARE");
		this.CARE_TOT =request.getParameter("CARE_TOT");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.INS_DT =request.getParameter("INS_DT");
		this.ETC1 =request.getParameter("ETC1");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.SEQ =KJFMi.dsGet(ds, arg_row, "SEQ");
		this.CARE_BOOK_ISSUE_NUM =KJFMi.dsGet(ds, arg_row, "CARE_BOOK_ISSUE_NUM");
		this.POW =KJFMi.dsGet(ds, arg_row, "POW");
		this.CARETERM_START_DT =KJFMi.dsGet(ds, arg_row, "CARETERM_START_DT");
		this.CARETERM_END_DT =KJFMi.dsGet(ds, arg_row, "CARETERM_END_DT");
		this.OFF_WORK =KJFMi.dsGet(ds, arg_row, "OFF_WORK");
		this.EXCH_CARE =KJFMi.dsGet(ds, arg_row, "EXCH_CARE");
		this.CARE_TOT =KJFMi.dsGet(ds, arg_row, "CARE_TOT");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.ETC1 =KJFMi.dsGet(ds, arg_row, "ETC1");
				
    }    
    
//Getter �Լ��� �����
  
     public String getSEQ(){
             return SEQ;
     };
  
     public String getCARE_BOOK_ISSUE_NUM(){
             return CARE_BOOK_ISSUE_NUM;
     };
  
     public String getPOW(){
             return POW;
     };
  
     public String getCARETERM_START_DT(){
             return CARETERM_START_DT;
     };
  
     public String getCARETERM_END_DT(){
             return CARETERM_END_DT;
     };
  
     public String getOFF_WORK(){
             return OFF_WORK;
     };
  
     public String getEXCH_CARE(){
             return EXCH_CARE;
     };
  
     public String getCARE_TOT(){
             return CARE_TOT;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getETC1(){
             return ETC1;
     };
  

//Setter �Լ��� �����
  
     public void setSEQ(String SEQ){
            this.SEQ=SEQ;
     };
  
     public void setCARE_BOOK_ISSUE_NUM(String CARE_BOOK_ISSUE_NUM){
            this.CARE_BOOK_ISSUE_NUM=CARE_BOOK_ISSUE_NUM;
     };
  
     public void setPOW(String POW){
            this.POW=POW;
     };
  
     public void setCARETERM_START_DT(String CARETERM_START_DT){
            this.CARETERM_START_DT=CARETERM_START_DT;
     };
  
     public void setCARETERM_END_DT(String CARETERM_END_DT){
            this.CARETERM_END_DT=CARETERM_END_DT;
     };
  
     public void setOFF_WORK(String OFF_WORK){
            this.OFF_WORK=OFF_WORK;
     };
  
     public void setEXCH_CARE(String EXCH_CARE){
            this.EXCH_CARE=EXCH_CARE;
     };
  
     public void setCARE_TOT(String CARE_TOT){
            this.CARE_TOT=CARE_TOT;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setETC1(String ETC1){
            this.ETC1=ETC1;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("SEQ:"+ this.getSEQ()+"\n");
      
      strB.append("CARE_BOOK_ISSUE_NUM:"+ this.getCARE_BOOK_ISSUE_NUM()+"\n");
      
      strB.append("POW:"+ this.getPOW()+"\n");
      
      strB.append("CARETERM_START_DT:"+ this.getCARETERM_START_DT()+"\n");
      
      strB.append("CARETERM_END_DT:"+ this.getCARETERM_END_DT()+"\n");
      
      strB.append("OFF_WORK:"+ this.getOFF_WORK()+"\n");
      
      strB.append("EXCH_CARE:"+ this.getEXCH_CARE()+"\n");
      
      strB.append("CARE_TOT:"+ this.getCARE_TOT()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("ETC1:"+ this.getETC1()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_R_ENGINEER_M_CAREERHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_R_ENGINEER_M_CAREERHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_R_ENGINEER_M_CAREERHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_R_ENGINEER_M_CAREERHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_R_ENGINEER_M_CAREERHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[2];
       values[0]= this.getCARE_BOOK_ISSUE_NUM();
       values[1]= this.getSEQ();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_R_ENGINEER_M_CAREEREntity();
  }

  public ValueObject getClone(){
         PT_R_ENGINEER_M_CAREEREntity newEnt = new PT_R_ENGINEER_M_CAREEREntity();
	 
          newEnt.setSEQ(this.getSEQ());
         
          newEnt.setCARE_BOOK_ISSUE_NUM(this.getCARE_BOOK_ISSUE_NUM());
         
          newEnt.setPOW(this.getPOW());
         
          newEnt.setCARETERM_START_DT(this.getCARETERM_START_DT());
         
          newEnt.setCARETERM_END_DT(this.getCARETERM_END_DT());
         
          newEnt.setOFF_WORK(this.getOFF_WORK());
         
          newEnt.setEXCH_CARE(this.getEXCH_CARE());
         
          newEnt.setCARE_TOT(this.getCARE_TOT());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setETC1(this.getETC1());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_R_ENGINEER_M_CAREERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getSEQ();
        
             case 2 :
                 return  this.getCARE_BOOK_ISSUE_NUM();
        
             case 3 :
                 return  this.getPOW();
        
             case 4 :
                 return  this.getCARETERM_START_DT();
        
             case 5 :
                 return  this.getCARETERM_END_DT();
        
             case 6 :
                 return  this.getOFF_WORK();
        
             case 7 :
                 return  this.getEXCH_CARE();
        
             case 8 :
                 return  this.getCARE_TOT();
        
             case 9 :
                 return  this.getWRT_ID();
        
             case 10 :
                 return  this.getUPD_DT();
        
             case 11 :
                 return  this.getINS_DT();
        
             case 12 :
                 return  this.getETC1();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_R_ENGINEER_M_CAREERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setSEQ((String)value);
	            return;  
        
             case 2 :
                    this.setCARE_BOOK_ISSUE_NUM((String)value);
	            return;  
        
             case 3 :
                    this.setPOW((String)value);
	            return;  
        
             case 4 :
                    this.setCARETERM_START_DT((String)value);
	            return;  
        
             case 5 :
                    this.setCARETERM_END_DT((String)value);
	            return;  
        
             case 6 :
                    this.setOFF_WORK((String)value);
	            return;  
        
             case 7 :
                    this.setEXCH_CARE((String)value);
	            return;  
        
             case 8 :
                    this.setCARE_TOT((String)value);
	            return;  
        
             case 9 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 10 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 11 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 12 :
                    this.setETC1((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_R_ENGINEER_M_CAREERHelper.toXML(this);
  }
  
}
