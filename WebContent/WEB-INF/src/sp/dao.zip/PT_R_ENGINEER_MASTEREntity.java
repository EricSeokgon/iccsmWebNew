

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_ENGINEER_MASTER
*  ���̺� ���� :
*  ���̺� PK   :  
*               CARE_BOOK_ISSUE_NUM
*  ���̺� �÷� :  
*               CARE_BOOK_ISSUE_NUM:VARCHAR2(12):  
*               ENGINEER_SSN1:VARCHAR2(18):  
*               ENGINEER_SSN2:VARCHAR2(21):  
*               WRT_NUM:VARCHAR2(12):  
*               ENGINEER_GRADE:VARCHAR2(10):  
*               ENGINEER_CLASS:VARCHAR2(10):  
*               QUAL_ITEM:VARCHAR2(15):  
*               NM_KOR:VARCHAR2(20):  
*               NM_HAN:VARCHAR2(20):  
*               CARE_BOOK_VAL_START_DT:VARCHAR2(24):  
*               CARE_BOOK_VAL_END_DT:VARCHAR2(24):  
*               EDU_COMP_DT:VARCHAR2(24):  
*               POST_NUM:VARCHAR2(7):  
*               ADDR:VARCHAR2(20):  
*               DETAIL_ADDR:VARCHAR2(20):  
*               GROUP_CODE:VARCHAR2(10):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(24):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_R_ENGINEER_MASTEREntity extends ValueObject{

  
     private String CARE_BOOK_ISSUE_NUM;
  
     private String ENGINEER_SSN1;
  
     private String ENGINEER_SSN2;
  
     private String WRT_NUM;
  
     private String ENGINEER_GRADE;
  
     private String ENGINEER_CLASS;
  
     private String QUAL_ITEM;
  
     private String NM_KOR;
  
     private String NM_HAN;
  
     private String CARE_BOOK_VAL_START_DT;
  
     private String CARE_BOOK_VAL_END_DT;
  
     private String EDU_COMP_DT;
  
     private String POST_NUM;
  
     private String ADDR;
  
     private String DETAIL_ADDR;
  
     private String GROUP_CODE;
  
     private String WRT_ID;
  
     private String UPD_DT;
  
     private String WRT_DT;
  

//�����ڸ� �����
    public PT_R_ENGINEER_MASTEREntity(){
    }
    
    
    public PT_R_ENGINEER_MASTEREntity(String CARE_BOOK_ISSUE_NUM ){
       this.setCARE_BOOK_ISSUE_NUM(CARE_BOOK_ISSUE_NUM);
       
    }
      
    public PT_R_ENGINEER_MASTEREntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("CARE_BOOK_ISSUE_NUM");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("CARE_BOOK_ISSUE_NUM",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.CARE_BOOK_ISSUE_NUM =request.getParameter("CARE_BOOK_ISSUE_NUM");
		this.ENGINEER_SSN1 =request.getParameter("ENGINEER_SSN1");
		this.ENGINEER_SSN2 =request.getParameter("ENGINEER_SSN2");
		this.WRT_NUM =request.getParameter("WRT_NUM");
		this.ENGINEER_GRADE =request.getParameter("ENGINEER_GRADE");
		this.ENGINEER_CLASS =request.getParameter("ENGINEER_CLASS");
		this.QUAL_ITEM =request.getParameter("QUAL_ITEM");
		this.NM_KOR =request.getParameter("NM_KOR");
		this.NM_HAN =request.getParameter("NM_HAN");
		this.CARE_BOOK_VAL_START_DT =request.getParameter("CARE_BOOK_VAL_START_DT");
		this.CARE_BOOK_VAL_END_DT =request.getParameter("CARE_BOOK_VAL_END_DT");
		this.EDU_COMP_DT =request.getParameter("EDU_COMP_DT");
		this.POST_NUM =request.getParameter("POST_NUM");
		this.ADDR =request.getParameter("ADDR");
		this.DETAIL_ADDR =request.getParameter("DETAIL_ADDR");
		this.GROUP_CODE =request.getParameter("GROUP_CODE");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.WRT_DT =request.getParameter("WRT_DT");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.CARE_BOOK_ISSUE_NUM =KJFMi.dsGet(ds, arg_row, "CARE_BOOK_ISSUE_NUM");
		this.ENGINEER_SSN1 =KJFMi.dsGet(ds, arg_row, "ENGINEER_SSN1");
		this.ENGINEER_SSN2 =KJFMi.dsGet(ds, arg_row, "ENGINEER_SSN2");
		this.WRT_NUM =KJFMi.dsGet(ds, arg_row, "WRT_NUM");
		this.ENGINEER_GRADE =KJFMi.dsGet(ds, arg_row, "ENGINEER_GRADE");
		this.ENGINEER_CLASS =KJFMi.dsGet(ds, arg_row, "ENGINEER_CLASS");
		this.QUAL_ITEM =KJFMi.dsGet(ds, arg_row, "QUAL_ITEM");
		this.NM_KOR =KJFMi.dsGet(ds, arg_row, "NM_KOR");
		this.NM_HAN =KJFMi.dsGet(ds, arg_row, "NM_HAN");
		this.CARE_BOOK_VAL_START_DT =KJFMi.dsGet(ds, arg_row, "CARE_BOOK_VAL_START_DT");
		this.CARE_BOOK_VAL_END_DT =KJFMi.dsGet(ds, arg_row, "CARE_BOOK_VAL_END_DT");
		this.EDU_COMP_DT =KJFMi.dsGet(ds, arg_row, "EDU_COMP_DT");
		this.POST_NUM =KJFMi.dsGet(ds, arg_row, "POST_NUM");
		this.ADDR =KJFMi.dsGet(ds, arg_row, "ADDR");
		this.DETAIL_ADDR =KJFMi.dsGet(ds, arg_row, "DETAIL_ADDR");
		this.GROUP_CODE =KJFMi.dsGet(ds, arg_row, "GROUP_CODE");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.WRT_DT =KJFMi.dsGet(ds, arg_row, "WRT_DT");
				
    }    
    
//Getter �Լ��� �����
  
     public String getCARE_BOOK_ISSUE_NUM(){
             return CARE_BOOK_ISSUE_NUM;
     };
  
     public String getENGINEER_SSN1(){
             return ENGINEER_SSN1;
     };
  
     public String getENGINEER_SSN2(){
             return ENGINEER_SSN2;
     };
  
     public String getWRT_NUM(){
             return WRT_NUM;
     };
  
     public String getENGINEER_GRADE(){
             return ENGINEER_GRADE;
     };
  
     public String getENGINEER_CLASS(){
             return ENGINEER_CLASS;
     };
  
     public String getQUAL_ITEM(){
             return QUAL_ITEM;
     };
  
     public String getNM_KOR(){
             return NM_KOR;
     };
  
     public String getNM_HAN(){
             return NM_HAN;
     };
  
     public String getCARE_BOOK_VAL_START_DT(){
             return CARE_BOOK_VAL_START_DT;
     };
  
     public String getCARE_BOOK_VAL_END_DT(){
             return CARE_BOOK_VAL_END_DT;
     };
  
     public String getEDU_COMP_DT(){
             return EDU_COMP_DT;
     };
  
     public String getPOST_NUM(){
             return POST_NUM;
     };
  
     public String getADDR(){
             return ADDR;
     };
  
     public String getDETAIL_ADDR(){
             return DETAIL_ADDR;
     };
  
     public String getGROUP_CODE(){
             return GROUP_CODE;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getWRT_DT(){
             return WRT_DT;
     };
  

//Setter �Լ��� �����
  
     public void setCARE_BOOK_ISSUE_NUM(String CARE_BOOK_ISSUE_NUM){
            this.CARE_BOOK_ISSUE_NUM=CARE_BOOK_ISSUE_NUM;
     };
  
     public void setENGINEER_SSN1(String ENGINEER_SSN1){
            this.ENGINEER_SSN1=ENGINEER_SSN1;
     };
  
     public void setENGINEER_SSN2(String ENGINEER_SSN2){
            this.ENGINEER_SSN2=ENGINEER_SSN2;
     };
  
     public void setWRT_NUM(String WRT_NUM){
            this.WRT_NUM=WRT_NUM;
     };
  
     public void setENGINEER_GRADE(String ENGINEER_GRADE){
            this.ENGINEER_GRADE=ENGINEER_GRADE;
     };
  
     public void setENGINEER_CLASS(String ENGINEER_CLASS){
            this.ENGINEER_CLASS=ENGINEER_CLASS;
     };
  
     public void setQUAL_ITEM(String QUAL_ITEM){
            this.QUAL_ITEM=QUAL_ITEM;
     };
  
     public void setNM_KOR(String NM_KOR){
            this.NM_KOR=NM_KOR;
     };
  
     public void setNM_HAN(String NM_HAN){
            this.NM_HAN=NM_HAN;
     };
  
     public void setCARE_BOOK_VAL_START_DT(String CARE_BOOK_VAL_START_DT){
            this.CARE_BOOK_VAL_START_DT=CARE_BOOK_VAL_START_DT;
     };
  
     public void setCARE_BOOK_VAL_END_DT(String CARE_BOOK_VAL_END_DT){
            this.CARE_BOOK_VAL_END_DT=CARE_BOOK_VAL_END_DT;
     };
  
     public void setEDU_COMP_DT(String EDU_COMP_DT){
            this.EDU_COMP_DT=EDU_COMP_DT;
     };
  
     public void setPOST_NUM(String POST_NUM){
            this.POST_NUM=POST_NUM;
     };
  
     public void setADDR(String ADDR){
            this.ADDR=ADDR;
     };
  
     public void setDETAIL_ADDR(String DETAIL_ADDR){
            this.DETAIL_ADDR=DETAIL_ADDR;
     };
  
     public void setGROUP_CODE(String GROUP_CODE){
            this.GROUP_CODE=GROUP_CODE;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setWRT_DT(String WRT_DT){
            this.WRT_DT=WRT_DT;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("CARE_BOOK_ISSUE_NUM:"+ this.getCARE_BOOK_ISSUE_NUM()+"\n");
      
      strB.append("ENGINEER_SSN1:"+ this.getENGINEER_SSN1()+"\n");
      
      strB.append("ENGINEER_SSN2:"+ this.getENGINEER_SSN2()+"\n");
      
      strB.append("WRT_NUM:"+ this.getWRT_NUM()+"\n");
      
      strB.append("ENGINEER_GRADE:"+ this.getENGINEER_GRADE()+"\n");
      
      strB.append("ENGINEER_CLASS:"+ this.getENGINEER_CLASS()+"\n");
      
      strB.append("QUAL_ITEM:"+ this.getQUAL_ITEM()+"\n");
      
      strB.append("NM_KOR:"+ this.getNM_KOR()+"\n");
      
      strB.append("NM_HAN:"+ this.getNM_HAN()+"\n");
      
      strB.append("CARE_BOOK_VAL_START_DT:"+ this.getCARE_BOOK_VAL_START_DT()+"\n");
      
      strB.append("CARE_BOOK_VAL_END_DT:"+ this.getCARE_BOOK_VAL_END_DT()+"\n");
      
      strB.append("EDU_COMP_DT:"+ this.getEDU_COMP_DT()+"\n");
      
      strB.append("POST_NUM:"+ this.getPOST_NUM()+"\n");
      
      strB.append("ADDR:"+ this.getADDR()+"\n");
      
      strB.append("DETAIL_ADDR:"+ this.getDETAIL_ADDR()+"\n");
      
      strB.append("GROUP_CODE:"+ this.getGROUP_CODE()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("WRT_DT:"+ this.getWRT_DT()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_R_ENGINEER_MASTERHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_R_ENGINEER_MASTERHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_R_ENGINEER_MASTERHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_R_ENGINEER_MASTERHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_R_ENGINEER_MASTERHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[1];
       values[0]= this.getCARE_BOOK_ISSUE_NUM();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_R_ENGINEER_MASTEREntity();
  }

  public ValueObject getClone(){
         PT_R_ENGINEER_MASTEREntity newEnt = new PT_R_ENGINEER_MASTEREntity();
	 
          newEnt.setCARE_BOOK_ISSUE_NUM(this.getCARE_BOOK_ISSUE_NUM());
         
          newEnt.setENGINEER_SSN1(this.getENGINEER_SSN1());
         
          newEnt.setENGINEER_SSN2(this.getENGINEER_SSN2());
         
          newEnt.setWRT_NUM(this.getWRT_NUM());
         
          newEnt.setENGINEER_GRADE(this.getENGINEER_GRADE());
         
          newEnt.setENGINEER_CLASS(this.getENGINEER_CLASS());
         
          newEnt.setQUAL_ITEM(this.getQUAL_ITEM());
         
          newEnt.setNM_KOR(this.getNM_KOR());
         
          newEnt.setNM_HAN(this.getNM_HAN());
         
          newEnt.setCARE_BOOK_VAL_START_DT(this.getCARE_BOOK_VAL_START_DT());
         
          newEnt.setCARE_BOOK_VAL_END_DT(this.getCARE_BOOK_VAL_END_DT());
         
          newEnt.setEDU_COMP_DT(this.getEDU_COMP_DT());
         
          newEnt.setPOST_NUM(this.getPOST_NUM());
         
          newEnt.setADDR(this.getADDR());
         
          newEnt.setDETAIL_ADDR(this.getDETAIL_ADDR());
         
          newEnt.setGROUP_CODE(this.getGROUP_CODE());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setWRT_DT(this.getWRT_DT());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_R_ENGINEER_MASTERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getCARE_BOOK_ISSUE_NUM();
        
             case 2 :
                 return  this.getENGINEER_SSN1();
        
             case 3 :
                 return  this.getENGINEER_SSN2();
        
             case 4 :
                 return  this.getWRT_NUM();
        
             case 5 :
                 return  this.getENGINEER_GRADE();
        
             case 6 :
                 return  this.getENGINEER_CLASS();
        
             case 7 :
                 return  this.getQUAL_ITEM();
        
             case 8 :
                 return  this.getNM_KOR();
        
             case 9 :
                 return  this.getNM_HAN();
        
             case 10 :
                 return  this.getCARE_BOOK_VAL_START_DT();
        
             case 11 :
                 return  this.getCARE_BOOK_VAL_END_DT();
        
             case 12 :
                 return  this.getEDU_COMP_DT();
        
             case 13 :
                 return  this.getPOST_NUM();
        
             case 14 :
                 return  this.getADDR();
        
             case 15 :
                 return  this.getDETAIL_ADDR();
        
             case 16 :
                 return  this.getGROUP_CODE();
        
             case 17 :
                 return  this.getWRT_ID();
        
             case 18 :
                 return  this.getUPD_DT();
        
             case 19 :
                 return  this.getWRT_DT();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_R_ENGINEER_MASTERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setCARE_BOOK_ISSUE_NUM((String)value);
	            return;  
        
             case 2 :
                    this.setENGINEER_SSN1((String)value);
	            return;  
        
             case 3 :
                    this.setENGINEER_SSN2((String)value);
	            return;  
        
             case 4 :
                    this.setWRT_NUM((String)value);
	            return;  
        
             case 5 :
                    this.setENGINEER_GRADE((String)value);
	            return;  
        
             case 6 :
                    this.setENGINEER_CLASS((String)value);
	            return;  
        
             case 7 :
                    this.setQUAL_ITEM((String)value);
	            return;  
        
             case 8 :
                    this.setNM_KOR((String)value);
	            return;  
        
             case 9 :
                    this.setNM_HAN((String)value);
	            return;  
        
             case 10 :
                    this.setCARE_BOOK_VAL_START_DT((String)value);
	            return;  
        
             case 11 :
                    this.setCARE_BOOK_VAL_END_DT((String)value);
	            return;  
        
             case 12 :
                    this.setEDU_COMP_DT((String)value);
	            return;  
        
             case 13 :
                    this.setPOST_NUM((String)value);
	            return;  
        
             case 14 :
                    this.setADDR((String)value);
	            return;  
        
             case 15 :
                    this.setDETAIL_ADDR((String)value);
	            return;  
        
             case 16 :
                    this.setGROUP_CODE((String)value);
	            return;  
        
             case 17 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 18 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 19 :
                    this.setWRT_DT((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_R_ENGINEER_MASTERHelper.toXML(this);
  }
  
}
