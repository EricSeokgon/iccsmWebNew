

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_SMS_LOG
*  ���̺� ���� :
*  ���̺� PK   :
*  ���̺� �÷� :  
*               USER_ID:VARCHAR2(12):  
*               LOCAL_CD:VARCHAR2(4):  
*               AREA_CD:VARCHAR2(5):  
*               FROM_TEL:VARCHAR2(14):  
*               TO_TEL:VARCHAR2(14):  
*               MSG:VARCHAR2(82):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               RESULT:CHAR(1):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_SMS_LOGHelper{

  final static public String USER_ID = "USER_ID";
  final static public String LOCAL_CD = "LOCAL_CD";
  final static public String AREA_CD = "AREA_CD";
  final static public String FROM_TEL = "FROM_TEL";
  final static public String TO_TEL = "TO_TEL";
  final static public String MSG = "MSG";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String RESULT = "RESULT";
  


  public static HashMap fieldMap = new HashMap(9);
  static{
  fieldMap.put(USER_ID,new Integer(1) );
  fieldMap.put(LOCAL_CD,new Integer(2) );
  fieldMap.put(AREA_CD,new Integer(3) );
  fieldMap.put(FROM_TEL,new Integer(4) );
  fieldMap.put(TO_TEL,new Integer(5) );
  fieldMap.put(MSG,new Integer(6) );
  fieldMap.put(INS_DT,new Integer(7) );
  fieldMap.put(UPD_DT,new Integer(8) );
  fieldMap.put(RESULT,new Integer(9) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_SMS_LOG";
     final public static String PREFIX = "sp.dao.PT_SMS_LOG";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
        };
     final public static String FIELD_LIST[] = { 
       USER_ID,LOCAL_CD,AREA_CD,FROM_TEL,TO_TEL,MSG,INS_DT,UPD_DT,RESULT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_SMS_LOGEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("USER_ID").append("'")
            .append(" value='").append(""+ent.getUSER_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LOCAL_CD").append("'")
            .append(" value='").append(""+ent.getLOCAL_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("AREA_CD").append("'")
            .append(" value='").append(""+ent.getAREA_CD()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("FROM_TEL").append("'")
            .append(" value='").append(""+ent.getFROM_TEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TO_TEL").append("'")
            .append(" value='").append(""+ent.getTO_TEL()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MSG").append("'")
            .append(" value='").append(""+ent.getMSG()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RESULT").append("'")
            .append(" value='").append(""+ent.getRESULT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
