

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_HOM_VIEW_DAY_COUNT
*  ���̺� ���� :
*  ���̺� PK   :  
*               PAGE_ID
*  ���̺� �÷� :  
*               PAGE_ID:VARCHAR2(50):  
*               REG_DATE:VARCHAR2(12):  
*               D_01:NUMBER(22):  
*               D_02:NUMBER(22):  
*               D_03:NUMBER(22):  
*               D_04:NUMBER(22):  
*               D_05:NUMBER(22):  
*               D_06:NUMBER(22):  
*               D_07:NUMBER(22):  
*               D_08:NUMBER(22):  
*               D_09:NUMBER(22):  
*               D_10:NUMBER(22):  
*               D_11:NUMBER(22):  
*               D_12:NUMBER(22):  
*               D_13:NUMBER(22):  
*               D_14:NUMBER(22):  
*               D_15:NUMBER(22):  
*               D_16:NUMBER(22):  
*               D_17:NUMBER(22):  
*               D_18:NUMBER(22):  
*               D_19:NUMBER(22):  
*               D_20:NUMBER(22):  
*               D_21:NUMBER(22):  
*               D_22:NUMBER(22):  
*               D_23:NUMBER(22):  
*               D_24:NUMBER(22):  
*               D_25:NUMBER(22):  
*               D_26:NUMBER(22):  
*               D_27:NUMBER(22):  
*               D_28:NUMBER(22):  
*               D_29:NUMBER(22):  
*               D_30:NUMBER(22):  
*               D_31:NUMBER(22):  
*               MONTH_TOTAL:NUMBER(22):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_HOM_VIEW_DAY_COUNTEntity extends ValueObject{

  
     private String PAGE_ID;
  
     private String REG_DATE;
  
     private String D_01;
  
     private String D_02;
  
     private String D_03;
  
     private String D_04;
  
     private String D_05;
  
     private String D_06;
  
     private String D_07;
  
     private String D_08;
  
     private String D_09;
  
     private String D_10;
  
     private String D_11;
  
     private String D_12;
  
     private String D_13;
  
     private String D_14;
  
     private String D_15;
  
     private String D_16;
  
     private String D_17;
  
     private String D_18;
  
     private String D_19;
  
     private String D_20;
  
     private String D_21;
  
     private String D_22;
  
     private String D_23;
  
     private String D_24;
  
     private String D_25;
  
     private String D_26;
  
     private String D_27;
  
     private String D_28;
  
     private String D_29;
  
     private String D_30;
  
     private String D_31;
  
     private String MONTH_TOTAL;
  

//�����ڸ� �����
    public PT_HOM_VIEW_DAY_COUNTEntity(){
    }
    
    
    public PT_HOM_VIEW_DAY_COUNTEntity(String PAGE_ID ){
       this.setPAGE_ID(PAGE_ID);
       
    }
      
    public PT_HOM_VIEW_DAY_COUNTEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("PAGE_ID");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("PAGE_ID",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.PAGE_ID =request.getParameter("PAGE_ID");
		this.REG_DATE =request.getParameter("REG_DATE");
		this.D_01 =request.getParameter("D_01");
		this.D_02 =request.getParameter("D_02");
		this.D_03 =request.getParameter("D_03");
		this.D_04 =request.getParameter("D_04");
		this.D_05 =request.getParameter("D_05");
		this.D_06 =request.getParameter("D_06");
		this.D_07 =request.getParameter("D_07");
		this.D_08 =request.getParameter("D_08");
		this.D_09 =request.getParameter("D_09");
		this.D_10 =request.getParameter("D_10");
		this.D_11 =request.getParameter("D_11");
		this.D_12 =request.getParameter("D_12");
		this.D_13 =request.getParameter("D_13");
		this.D_14 =request.getParameter("D_14");
		this.D_15 =request.getParameter("D_15");
		this.D_16 =request.getParameter("D_16");
		this.D_17 =request.getParameter("D_17");
		this.D_18 =request.getParameter("D_18");
		this.D_19 =request.getParameter("D_19");
		this.D_20 =request.getParameter("D_20");
		this.D_21 =request.getParameter("D_21");
		this.D_22 =request.getParameter("D_22");
		this.D_23 =request.getParameter("D_23");
		this.D_24 =request.getParameter("D_24");
		this.D_25 =request.getParameter("D_25");
		this.D_26 =request.getParameter("D_26");
		this.D_27 =request.getParameter("D_27");
		this.D_28 =request.getParameter("D_28");
		this.D_29 =request.getParameter("D_29");
		this.D_30 =request.getParameter("D_30");
		this.D_31 =request.getParameter("D_31");
		this.MONTH_TOTAL =request.getParameter("MONTH_TOTAL");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.PAGE_ID =KJFMi.dsGet(ds, arg_row, "PAGE_ID");
		this.REG_DATE =KJFMi.dsGet(ds, arg_row, "REG_DATE");
		this.D_01 =KJFMi.dsGet(ds, arg_row, "D_01");
		this.D_02 =KJFMi.dsGet(ds, arg_row, "D_02");
		this.D_03 =KJFMi.dsGet(ds, arg_row, "D_03");
		this.D_04 =KJFMi.dsGet(ds, arg_row, "D_04");
		this.D_05 =KJFMi.dsGet(ds, arg_row, "D_05");
		this.D_06 =KJFMi.dsGet(ds, arg_row, "D_06");
		this.D_07 =KJFMi.dsGet(ds, arg_row, "D_07");
		this.D_08 =KJFMi.dsGet(ds, arg_row, "D_08");
		this.D_09 =KJFMi.dsGet(ds, arg_row, "D_09");
		this.D_10 =KJFMi.dsGet(ds, arg_row, "D_10");
		this.D_11 =KJFMi.dsGet(ds, arg_row, "D_11");
		this.D_12 =KJFMi.dsGet(ds, arg_row, "D_12");
		this.D_13 =KJFMi.dsGet(ds, arg_row, "D_13");
		this.D_14 =KJFMi.dsGet(ds, arg_row, "D_14");
		this.D_15 =KJFMi.dsGet(ds, arg_row, "D_15");
		this.D_16 =KJFMi.dsGet(ds, arg_row, "D_16");
		this.D_17 =KJFMi.dsGet(ds, arg_row, "D_17");
		this.D_18 =KJFMi.dsGet(ds, arg_row, "D_18");
		this.D_19 =KJFMi.dsGet(ds, arg_row, "D_19");
		this.D_20 =KJFMi.dsGet(ds, arg_row, "D_20");
		this.D_21 =KJFMi.dsGet(ds, arg_row, "D_21");
		this.D_22 =KJFMi.dsGet(ds, arg_row, "D_22");
		this.D_23 =KJFMi.dsGet(ds, arg_row, "D_23");
		this.D_24 =KJFMi.dsGet(ds, arg_row, "D_24");
		this.D_25 =KJFMi.dsGet(ds, arg_row, "D_25");
		this.D_26 =KJFMi.dsGet(ds, arg_row, "D_26");
		this.D_27 =KJFMi.dsGet(ds, arg_row, "D_27");
		this.D_28 =KJFMi.dsGet(ds, arg_row, "D_28");
		this.D_29 =KJFMi.dsGet(ds, arg_row, "D_29");
		this.D_30 =KJFMi.dsGet(ds, arg_row, "D_30");
		this.D_31 =KJFMi.dsGet(ds, arg_row, "D_31");
		this.MONTH_TOTAL =KJFMi.dsGet(ds, arg_row, "MONTH_TOTAL");
				
    }    
    
//Getter �Լ��� �����
  
     public String getPAGE_ID(){
             return PAGE_ID;
     };
  
     public String getREG_DATE(){
             return REG_DATE;
     };
  
     public String getD_01(){
             return D_01;
     };
  
     public String getD_02(){
             return D_02;
     };
  
     public String getD_03(){
             return D_03;
     };
  
     public String getD_04(){
             return D_04;
     };
  
     public String getD_05(){
             return D_05;
     };
  
     public String getD_06(){
             return D_06;
     };
  
     public String getD_07(){
             return D_07;
     };
  
     public String getD_08(){
             return D_08;
     };
  
     public String getD_09(){
             return D_09;
     };
  
     public String getD_10(){
             return D_10;
     };
  
     public String getD_11(){
             return D_11;
     };
  
     public String getD_12(){
             return D_12;
     };
  
     public String getD_13(){
             return D_13;
     };
  
     public String getD_14(){
             return D_14;
     };
  
     public String getD_15(){
             return D_15;
     };
  
     public String getD_16(){
             return D_16;
     };
  
     public String getD_17(){
             return D_17;
     };
  
     public String getD_18(){
             return D_18;
     };
  
     public String getD_19(){
             return D_19;
     };
  
     public String getD_20(){
             return D_20;
     };
  
     public String getD_21(){
             return D_21;
     };
  
     public String getD_22(){
             return D_22;
     };
  
     public String getD_23(){
             return D_23;
     };
  
     public String getD_24(){
             return D_24;
     };
  
     public String getD_25(){
             return D_25;
     };
  
     public String getD_26(){
             return D_26;
     };
  
     public String getD_27(){
             return D_27;
     };
  
     public String getD_28(){
             return D_28;
     };
  
     public String getD_29(){
             return D_29;
     };
  
     public String getD_30(){
             return D_30;
     };
  
     public String getD_31(){
             return D_31;
     };
  
     public String getMONTH_TOTAL(){
             return MONTH_TOTAL;
     };
  

//Setter �Լ��� �����
  
     public void setPAGE_ID(String PAGE_ID){
            this.PAGE_ID=PAGE_ID;
     };
  
     public void setREG_DATE(String REG_DATE){
            this.REG_DATE=REG_DATE;
     };
  
     public void setD_01(String D_01){
            this.D_01=D_01;
     };
  
     public void setD_02(String D_02){
            this.D_02=D_02;
     };
  
     public void setD_03(String D_03){
            this.D_03=D_03;
     };
  
     public void setD_04(String D_04){
            this.D_04=D_04;
     };
  
     public void setD_05(String D_05){
            this.D_05=D_05;
     };
  
     public void setD_06(String D_06){
            this.D_06=D_06;
     };
  
     public void setD_07(String D_07){
            this.D_07=D_07;
     };
  
     public void setD_08(String D_08){
            this.D_08=D_08;
     };
  
     public void setD_09(String D_09){
            this.D_09=D_09;
     };
  
     public void setD_10(String D_10){
            this.D_10=D_10;
     };
  
     public void setD_11(String D_11){
            this.D_11=D_11;
     };
  
     public void setD_12(String D_12){
            this.D_12=D_12;
     };
  
     public void setD_13(String D_13){
            this.D_13=D_13;
     };
  
     public void setD_14(String D_14){
            this.D_14=D_14;
     };
  
     public void setD_15(String D_15){
            this.D_15=D_15;
     };
  
     public void setD_16(String D_16){
            this.D_16=D_16;
     };
  
     public void setD_17(String D_17){
            this.D_17=D_17;
     };
  
     public void setD_18(String D_18){
            this.D_18=D_18;
     };
  
     public void setD_19(String D_19){
            this.D_19=D_19;
     };
  
     public void setD_20(String D_20){
            this.D_20=D_20;
     };
  
     public void setD_21(String D_21){
            this.D_21=D_21;
     };
  
     public void setD_22(String D_22){
            this.D_22=D_22;
     };
  
     public void setD_23(String D_23){
            this.D_23=D_23;
     };
  
     public void setD_24(String D_24){
            this.D_24=D_24;
     };
  
     public void setD_25(String D_25){
            this.D_25=D_25;
     };
  
     public void setD_26(String D_26){
            this.D_26=D_26;
     };
  
     public void setD_27(String D_27){
            this.D_27=D_27;
     };
  
     public void setD_28(String D_28){
            this.D_28=D_28;
     };
  
     public void setD_29(String D_29){
            this.D_29=D_29;
     };
  
     public void setD_30(String D_30){
            this.D_30=D_30;
     };
  
     public void setD_31(String D_31){
            this.D_31=D_31;
     };
  
     public void setMONTH_TOTAL(String MONTH_TOTAL){
            this.MONTH_TOTAL=MONTH_TOTAL;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("PAGE_ID:"+ this.getPAGE_ID()+"\n");
      
      strB.append("REG_DATE:"+ this.getREG_DATE()+"\n");
      
      strB.append("D_01:"+ this.getD_01()+"\n");
      
      strB.append("D_02:"+ this.getD_02()+"\n");
      
      strB.append("D_03:"+ this.getD_03()+"\n");
      
      strB.append("D_04:"+ this.getD_04()+"\n");
      
      strB.append("D_05:"+ this.getD_05()+"\n");
      
      strB.append("D_06:"+ this.getD_06()+"\n");
      
      strB.append("D_07:"+ this.getD_07()+"\n");
      
      strB.append("D_08:"+ this.getD_08()+"\n");
      
      strB.append("D_09:"+ this.getD_09()+"\n");
      
      strB.append("D_10:"+ this.getD_10()+"\n");
      
      strB.append("D_11:"+ this.getD_11()+"\n");
      
      strB.append("D_12:"+ this.getD_12()+"\n");
      
      strB.append("D_13:"+ this.getD_13()+"\n");
      
      strB.append("D_14:"+ this.getD_14()+"\n");
      
      strB.append("D_15:"+ this.getD_15()+"\n");
      
      strB.append("D_16:"+ this.getD_16()+"\n");
      
      strB.append("D_17:"+ this.getD_17()+"\n");
      
      strB.append("D_18:"+ this.getD_18()+"\n");
      
      strB.append("D_19:"+ this.getD_19()+"\n");
      
      strB.append("D_20:"+ this.getD_20()+"\n");
      
      strB.append("D_21:"+ this.getD_21()+"\n");
      
      strB.append("D_22:"+ this.getD_22()+"\n");
      
      strB.append("D_23:"+ this.getD_23()+"\n");
      
      strB.append("D_24:"+ this.getD_24()+"\n");
      
      strB.append("D_25:"+ this.getD_25()+"\n");
      
      strB.append("D_26:"+ this.getD_26()+"\n");
      
      strB.append("D_27:"+ this.getD_27()+"\n");
      
      strB.append("D_28:"+ this.getD_28()+"\n");
      
      strB.append("D_29:"+ this.getD_29()+"\n");
      
      strB.append("D_30:"+ this.getD_30()+"\n");
      
      strB.append("D_31:"+ this.getD_31()+"\n");
      
      strB.append("MONTH_TOTAL:"+ this.getMONTH_TOTAL()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_HOM_VIEW_DAY_COUNTHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_HOM_VIEW_DAY_COUNTHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_HOM_VIEW_DAY_COUNTHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_HOM_VIEW_DAY_COUNTHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_HOM_VIEW_DAY_COUNTHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[1];
       values[0]= this.getPAGE_ID();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_HOM_VIEW_DAY_COUNTEntity();
  }

  public ValueObject getClone(){
         PT_HOM_VIEW_DAY_COUNTEntity newEnt = new PT_HOM_VIEW_DAY_COUNTEntity();
	 
          newEnt.setPAGE_ID(this.getPAGE_ID());
         
          newEnt.setREG_DATE(this.getREG_DATE());
         
          newEnt.setD_01(this.getD_01());
         
          newEnt.setD_02(this.getD_02());
         
          newEnt.setD_03(this.getD_03());
         
          newEnt.setD_04(this.getD_04());
         
          newEnt.setD_05(this.getD_05());
         
          newEnt.setD_06(this.getD_06());
         
          newEnt.setD_07(this.getD_07());
         
          newEnt.setD_08(this.getD_08());
         
          newEnt.setD_09(this.getD_09());
         
          newEnt.setD_10(this.getD_10());
         
          newEnt.setD_11(this.getD_11());
         
          newEnt.setD_12(this.getD_12());
         
          newEnt.setD_13(this.getD_13());
         
          newEnt.setD_14(this.getD_14());
         
          newEnt.setD_15(this.getD_15());
         
          newEnt.setD_16(this.getD_16());
         
          newEnt.setD_17(this.getD_17());
         
          newEnt.setD_18(this.getD_18());
         
          newEnt.setD_19(this.getD_19());
         
          newEnt.setD_20(this.getD_20());
         
          newEnt.setD_21(this.getD_21());
         
          newEnt.setD_22(this.getD_22());
         
          newEnt.setD_23(this.getD_23());
         
          newEnt.setD_24(this.getD_24());
         
          newEnt.setD_25(this.getD_25());
         
          newEnt.setD_26(this.getD_26());
         
          newEnt.setD_27(this.getD_27());
         
          newEnt.setD_28(this.getD_28());
         
          newEnt.setD_29(this.getD_29());
         
          newEnt.setD_30(this.getD_30());
         
          newEnt.setD_31(this.getD_31());
         
          newEnt.setMONTH_TOTAL(this.getMONTH_TOTAL());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_HOM_VIEW_DAY_COUNTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getPAGE_ID();
        
             case 2 :
                 return  this.getREG_DATE();
        
             case 3 :
                 return  this.getD_01();
        
             case 4 :
                 return  this.getD_02();
        
             case 5 :
                 return  this.getD_03();
        
             case 6 :
                 return  this.getD_04();
        
             case 7 :
                 return  this.getD_05();
        
             case 8 :
                 return  this.getD_06();
        
             case 9 :
                 return  this.getD_07();
        
             case 10 :
                 return  this.getD_08();
        
             case 11 :
                 return  this.getD_09();
        
             case 12 :
                 return  this.getD_10();
        
             case 13 :
                 return  this.getD_11();
        
             case 14 :
                 return  this.getD_12();
        
             case 15 :
                 return  this.getD_13();
        
             case 16 :
                 return  this.getD_14();
        
             case 17 :
                 return  this.getD_15();
        
             case 18 :
                 return  this.getD_16();
        
             case 19 :
                 return  this.getD_17();
        
             case 20 :
                 return  this.getD_18();
        
             case 21 :
                 return  this.getD_19();
        
             case 22 :
                 return  this.getD_20();
        
             case 23 :
                 return  this.getD_21();
        
             case 24 :
                 return  this.getD_22();
        
             case 25 :
                 return  this.getD_23();
        
             case 26 :
                 return  this.getD_24();
        
             case 27 :
                 return  this.getD_25();
        
             case 28 :
                 return  this.getD_26();
        
             case 29 :
                 return  this.getD_27();
        
             case 30 :
                 return  this.getD_28();
        
             case 31 :
                 return  this.getD_29();
        
             case 32 :
                 return  this.getD_30();
        
             case 33 :
                 return  this.getD_31();
        
             case 34 :
                 return  this.getMONTH_TOTAL();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_HOM_VIEW_DAY_COUNTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setPAGE_ID((String)value);
	            return;  
        
             case 2 :
                    this.setREG_DATE((String)value);
	            return;  
        
             case 3 :
                    this.setD_01((String)value);
	            return;  
        
             case 4 :
                    this.setD_02((String)value);
	            return;  
        
             case 5 :
                    this.setD_03((String)value);
	            return;  
        
             case 6 :
                    this.setD_04((String)value);
	            return;  
        
             case 7 :
                    this.setD_05((String)value);
	            return;  
        
             case 8 :
                    this.setD_06((String)value);
	            return;  
        
             case 9 :
                    this.setD_07((String)value);
	            return;  
        
             case 10 :
                    this.setD_08((String)value);
	            return;  
        
             case 11 :
                    this.setD_09((String)value);
	            return;  
        
             case 12 :
                    this.setD_10((String)value);
	            return;  
        
             case 13 :
                    this.setD_11((String)value);
	            return;  
        
             case 14 :
                    this.setD_12((String)value);
	            return;  
        
             case 15 :
                    this.setD_13((String)value);
	            return;  
        
             case 16 :
                    this.setD_14((String)value);
	            return;  
        
             case 17 :
                    this.setD_15((String)value);
	            return;  
        
             case 18 :
                    this.setD_16((String)value);
	            return;  
        
             case 19 :
                    this.setD_17((String)value);
	            return;  
        
             case 20 :
                    this.setD_18((String)value);
	            return;  
        
             case 21 :
                    this.setD_19((String)value);
	            return;  
        
             case 22 :
                    this.setD_20((String)value);
	            return;  
        
             case 23 :
                    this.setD_21((String)value);
	            return;  
        
             case 24 :
                    this.setD_22((String)value);
	            return;  
        
             case 25 :
                    this.setD_23((String)value);
	            return;  
        
             case 26 :
                    this.setD_24((String)value);
	            return;  
        
             case 27 :
                    this.setD_25((String)value);
	            return;  
        
             case 28 :
                    this.setD_26((String)value);
	            return;  
        
             case 29 :
                    this.setD_27((String)value);
	            return;  
        
             case 30 :
                    this.setD_28((String)value);
	            return;  
        
             case 31 :
                    this.setD_29((String)value);
	            return;  
        
             case 32 :
                    this.setD_30((String)value);
	            return;  
        
             case 33 :
                    this.setD_31((String)value);
	            return;  
        
             case 34 :
                    this.setMONTH_TOTAL((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_HOM_VIEW_DAY_COUNTHelper.toXML(this);
  }
  
}
