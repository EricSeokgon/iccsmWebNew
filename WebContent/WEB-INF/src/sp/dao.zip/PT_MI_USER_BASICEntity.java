

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_MI_USER_BASIC
*  ���̺� ���� :
*  ���̺� PK   :  
*               OFFI_ID
*  ���̺� �÷� :  
*               OFFI_ID:VARCHAR2(16):  
*               NM:VARCHAR2(40):  
*               TEL:VARCHAR2(16):  
*               SIDO_CODE:VARCHAR2(10):  
*               SIGUNGU_CODE:VARCHAR2(10):  
*               PART:VARCHAR2(50):  
*               POS:VARCHAR2(20):  
*               GROUP_CODE:VARCHAR2(5):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               PASS:VARCHAR2(16):  
*               HOME_GROUP:VARCHAR2(5):  
*               MOBILE:VARCHAR2(16):  
*               E_MAIL:VARCHAR2(128):  
*               OFFSEAL:VARCHAR2(26):  
*               TEL1:VARCHAR2(20):  
*               TEL2:VARCHAR2(20):  
*               TEL3:VARCHAR2(20):  
*               MOBILE1:VARCHAR2(20):  
*               MOBILE2:VARCHAR2(20):  
*               MOBILE3:VARCHAR2(20):  
*               PHOTO:VARCHAR2(26):  
*               FAX1:VARCHAR2(20):  
*               FAX2:VARCHAR2(20):  
*               FAX3:VARCHAR2(20):  
*               FAX:VARCHAR2(20):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_MI_USER_BASICEntity extends ValueObject{

  
     private String OFFI_ID;
  
     private String NM;
  
     private String TEL;
  
     private String SIDO_CODE;
  
     private String SIGUNGU_CODE;
  
     private String PART;
  
     private String POS;
  
     private String GROUP_CODE;
  
     private String WRT_ID;
  
     private String INS_DT;
  
     private String UPD_DT;
  
     private String PASS;
  
     private String HOME_GROUP;
  
     private String MOBILE;
  
     private String E_MAIL;
  
     private String OFFSEAL;
  
     private String TEL1;
  
     private String TEL2;
  
     private String TEL3;
  
     private String MOBILE1;
  
     private String MOBILE2;
  
     private String MOBILE3;
  
     private String PHOTO;
  
     private String FAX1;
  
     private String FAX2;
  
     private String FAX3;
  
     private String FAX;
  

//�����ڸ� �����
    public PT_MI_USER_BASICEntity(){
    }
    
    
    public PT_MI_USER_BASICEntity(String OFFI_ID ){
       this.setOFFI_ID(OFFI_ID);
       
    }
      
    public PT_MI_USER_BASICEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("OFFI_ID");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("OFFI_ID",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.OFFI_ID =request.getParameter("OFFI_ID");
		this.NM =request.getParameter("NM");
		this.TEL =request.getParameter("TEL");
		this.SIDO_CODE =request.getParameter("SIDO_CODE");
		this.SIGUNGU_CODE =request.getParameter("SIGUNGU_CODE");
		this.PART =request.getParameter("PART");
		this.POS =request.getParameter("POS");
		this.GROUP_CODE =request.getParameter("GROUP_CODE");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.INS_DT =request.getParameter("INS_DT");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.PASS =request.getParameter("PASS");
		this.HOME_GROUP =request.getParameter("HOME_GROUP");
		this.MOBILE =request.getParameter("MOBILE");
		this.E_MAIL =request.getParameter("E_MAIL");
		this.OFFSEAL =request.getParameter("OFFSEAL");
		this.TEL1 =request.getParameter("TEL1");
		this.TEL2 =request.getParameter("TEL2");
		this.TEL3 =request.getParameter("TEL3");
		this.MOBILE1 =request.getParameter("MOBILE1");
		this.MOBILE2 =request.getParameter("MOBILE2");
		this.MOBILE3 =request.getParameter("MOBILE3");
		this.PHOTO =request.getParameter("PHOTO");
		this.FAX1 =request.getParameter("FAX1");
		this.FAX2 =request.getParameter("FAX2");
		this.FAX3 =request.getParameter("FAX3");
		this.FAX =request.getParameter("FAX");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.OFFI_ID =KJFMi.dsGet(ds, arg_row, "OFFI_ID");
		this.NM =KJFMi.dsGet(ds, arg_row, "NM");
		this.TEL =KJFMi.dsGet(ds, arg_row, "TEL");
		this.SIDO_CODE =KJFMi.dsGet(ds, arg_row, "SIDO_CODE");
		this.SIGUNGU_CODE =KJFMi.dsGet(ds, arg_row, "SIGUNGU_CODE");
		this.PART =KJFMi.dsGet(ds, arg_row, "PART");
		this.POS =KJFMi.dsGet(ds, arg_row, "POS");
		this.GROUP_CODE =KJFMi.dsGet(ds, arg_row, "GROUP_CODE");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.PASS =KJFMi.dsGet(ds, arg_row, "PASS");
		this.HOME_GROUP =KJFMi.dsGet(ds, arg_row, "HOME_GROUP");
		this.MOBILE =KJFMi.dsGet(ds, arg_row, "MOBILE");
		this.E_MAIL =KJFMi.dsGet(ds, arg_row, "E_MAIL");
		this.OFFSEAL =KJFMi.dsGet(ds, arg_row, "OFFSEAL");
		this.TEL1 =KJFMi.dsGet(ds, arg_row, "TEL1");
		this.TEL2 =KJFMi.dsGet(ds, arg_row, "TEL2");
		this.TEL3 =KJFMi.dsGet(ds, arg_row, "TEL3");
		this.MOBILE1 =KJFMi.dsGet(ds, arg_row, "MOBILE1");
		this.MOBILE2 =KJFMi.dsGet(ds, arg_row, "MOBILE2");
		this.MOBILE3 =KJFMi.dsGet(ds, arg_row, "MOBILE3");
		this.PHOTO =KJFMi.dsGet(ds, arg_row, "PHOTO");
		this.FAX1 =KJFMi.dsGet(ds, arg_row, "FAX1");
		this.FAX2 =KJFMi.dsGet(ds, arg_row, "FAX2");
		this.FAX3 =KJFMi.dsGet(ds, arg_row, "FAX3");
		this.FAX =KJFMi.dsGet(ds, arg_row, "FAX");
				
    }    
    
//Getter �Լ��� �����
  
     public String getOFFI_ID(){
             return OFFI_ID;
     };
  
     public String getNM(){
             return NM;
     };
  
     public String getTEL(){
             return TEL;
     };
  
     public String getSIDO_CODE(){
             return SIDO_CODE;
     };
  
     public String getSIGUNGU_CODE(){
             return SIGUNGU_CODE;
     };
  
     public String getPART(){
             return PART;
     };
  
     public String getPOS(){
             return POS;
     };
  
     public String getGROUP_CODE(){
             return GROUP_CODE;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getPASS(){
             return PASS;
     };
  
     public String getHOME_GROUP(){
             return HOME_GROUP;
     };
  
     public String getMOBILE(){
             return MOBILE;
     };
  
     public String getE_MAIL(){
             return E_MAIL;
     };
  
     public String getOFFSEAL(){
             return OFFSEAL;
     };
  
     public String getTEL1(){
             return TEL1;
     };
  
     public String getTEL2(){
             return TEL2;
     };
  
     public String getTEL3(){
             return TEL3;
     };
  
     public String getMOBILE1(){
             return MOBILE1;
     };
  
     public String getMOBILE2(){
             return MOBILE2;
     };
  
     public String getMOBILE3(){
             return MOBILE3;
     };
  
     public String getPHOTO(){
             return PHOTO;
     };
  
     public String getFAX1(){
             return FAX1;
     };
  
     public String getFAX2(){
             return FAX2;
     };
  
     public String getFAX3(){
             return FAX3;
     };
  
     public String getFAX(){
             return FAX;
     };
  

//Setter �Լ��� �����
  
     public void setOFFI_ID(String OFFI_ID){
            this.OFFI_ID=OFFI_ID;
     };
  
     public void setNM(String NM){
            this.NM=NM;
     };
  
     public void setTEL(String TEL){
            this.TEL=TEL;
     };
  
     public void setSIDO_CODE(String SIDO_CODE){
            this.SIDO_CODE=SIDO_CODE;
     };
  
     public void setSIGUNGU_CODE(String SIGUNGU_CODE){
            this.SIGUNGU_CODE=SIGUNGU_CODE;
     };
  
     public void setPART(String PART){
            this.PART=PART;
     };
  
     public void setPOS(String POS){
            this.POS=POS;
     };
  
     public void setGROUP_CODE(String GROUP_CODE){
            this.GROUP_CODE=GROUP_CODE;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setPASS(String PASS){
            this.PASS=PASS;
     };
  
     public void setHOME_GROUP(String HOME_GROUP){
            this.HOME_GROUP=HOME_GROUP;
     };
  
     public void setMOBILE(String MOBILE){
            this.MOBILE=MOBILE;
     };
  
     public void setE_MAIL(String E_MAIL){
            this.E_MAIL=E_MAIL;
     };
  
     public void setOFFSEAL(String OFFSEAL){
            this.OFFSEAL=OFFSEAL;
     };
  
     public void setTEL1(String TEL1){
            this.TEL1=TEL1;
     };
  
     public void setTEL2(String TEL2){
            this.TEL2=TEL2;
     };
  
     public void setTEL3(String TEL3){
            this.TEL3=TEL3;
     };
  
     public void setMOBILE1(String MOBILE1){
            this.MOBILE1=MOBILE1;
     };
  
     public void setMOBILE2(String MOBILE2){
            this.MOBILE2=MOBILE2;
     };
  
     public void setMOBILE3(String MOBILE3){
            this.MOBILE3=MOBILE3;
     };
  
     public void setPHOTO(String PHOTO){
            this.PHOTO=PHOTO;
     };
  
     public void setFAX1(String FAX1){
            this.FAX1=FAX1;
     };
  
     public void setFAX2(String FAX2){
            this.FAX2=FAX2;
     };
  
     public void setFAX3(String FAX3){
            this.FAX3=FAX3;
     };
  
     public void setFAX(String FAX){
            this.FAX=FAX;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("OFFI_ID:"+ this.getOFFI_ID()+"\n");
      
      strB.append("NM:"+ this.getNM()+"\n");
      
      strB.append("TEL:"+ this.getTEL()+"\n");
      
      strB.append("SIDO_CODE:"+ this.getSIDO_CODE()+"\n");
      
      strB.append("SIGUNGU_CODE:"+ this.getSIGUNGU_CODE()+"\n");
      
      strB.append("PART:"+ this.getPART()+"\n");
      
      strB.append("POS:"+ this.getPOS()+"\n");
      
      strB.append("GROUP_CODE:"+ this.getGROUP_CODE()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("PASS:"+ this.getPASS()+"\n");
      
      strB.append("HOME_GROUP:"+ this.getHOME_GROUP()+"\n");
      
      strB.append("MOBILE:"+ this.getMOBILE()+"\n");
      
      strB.append("E_MAIL:"+ this.getE_MAIL()+"\n");
      
      strB.append("OFFSEAL:"+ this.getOFFSEAL()+"\n");
      
      strB.append("TEL1:"+ this.getTEL1()+"\n");
      
      strB.append("TEL2:"+ this.getTEL2()+"\n");
      
      strB.append("TEL3:"+ this.getTEL3()+"\n");
      
      strB.append("MOBILE1:"+ this.getMOBILE1()+"\n");
      
      strB.append("MOBILE2:"+ this.getMOBILE2()+"\n");
      
      strB.append("MOBILE3:"+ this.getMOBILE3()+"\n");
      
      strB.append("PHOTO:"+ this.getPHOTO()+"\n");
      
      strB.append("FAX1:"+ this.getFAX1()+"\n");
      
      strB.append("FAX2:"+ this.getFAX2()+"\n");
      
      strB.append("FAX3:"+ this.getFAX3()+"\n");
      
      strB.append("FAX:"+ this.getFAX()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_MI_USER_BASICHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_MI_USER_BASICHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_MI_USER_BASICHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_MI_USER_BASICHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_MI_USER_BASICHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[1];
       values[0]= this.getOFFI_ID();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_MI_USER_BASICEntity();
  }

  public ValueObject getClone(){
         PT_MI_USER_BASICEntity newEnt = new PT_MI_USER_BASICEntity();
	 
          newEnt.setOFFI_ID(this.getOFFI_ID());
         
          newEnt.setNM(this.getNM());
         
          newEnt.setTEL(this.getTEL());
         
          newEnt.setSIDO_CODE(this.getSIDO_CODE());
         
          newEnt.setSIGUNGU_CODE(this.getSIGUNGU_CODE());
         
          newEnt.setPART(this.getPART());
         
          newEnt.setPOS(this.getPOS());
         
          newEnt.setGROUP_CODE(this.getGROUP_CODE());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setPASS(this.getPASS());
         
          newEnt.setHOME_GROUP(this.getHOME_GROUP());
         
          newEnt.setMOBILE(this.getMOBILE());
         
          newEnt.setE_MAIL(this.getE_MAIL());
         
          newEnt.setOFFSEAL(this.getOFFSEAL());
         
          newEnt.setTEL1(this.getTEL1());
         
          newEnt.setTEL2(this.getTEL2());
         
          newEnt.setTEL3(this.getTEL3());
         
          newEnt.setMOBILE1(this.getMOBILE1());
         
          newEnt.setMOBILE2(this.getMOBILE2());
         
          newEnt.setMOBILE3(this.getMOBILE3());
         
          newEnt.setPHOTO(this.getPHOTO());
         
          newEnt.setFAX1(this.getFAX1());
         
          newEnt.setFAX2(this.getFAX2());
         
          newEnt.setFAX3(this.getFAX3());
         
          newEnt.setFAX(this.getFAX());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_MI_USER_BASICHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getOFFI_ID();
        
             case 2 :
                 return  this.getNM();
        
             case 3 :
                 return  this.getTEL();
        
             case 4 :
                 return  this.getSIDO_CODE();
        
             case 5 :
                 return  this.getSIGUNGU_CODE();
        
             case 6 :
                 return  this.getPART();
        
             case 7 :
                 return  this.getPOS();
        
             case 8 :
                 return  this.getGROUP_CODE();
        
             case 9 :
                 return  this.getWRT_ID();
        
             case 10 :
                 return  this.getINS_DT();
        
             case 11 :
                 return  this.getUPD_DT();
        
             case 12 :
                 return  this.getPASS();
        
             case 13 :
                 return  this.getHOME_GROUP();
        
             case 14 :
                 return  this.getMOBILE();
        
             case 15 :
                 return  this.getE_MAIL();
        
             case 16 :
                 return  this.getOFFSEAL();
        
             case 17 :
                 return  this.getTEL1();
        
             case 18 :
                 return  this.getTEL2();
        
             case 19 :
                 return  this.getTEL3();
        
             case 20 :
                 return  this.getMOBILE1();
        
             case 21 :
                 return  this.getMOBILE2();
        
             case 22 :
                 return  this.getMOBILE3();
        
             case 23 :
                 return  this.getPHOTO();
        
             case 24 :
                 return  this.getFAX1();
        
             case 25 :
                 return  this.getFAX2();
        
             case 26 :
                 return  this.getFAX3();
        
             case 27 :
                 return  this.getFAX();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_MI_USER_BASICHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setOFFI_ID((String)value);
	            return;  
        
             case 2 :
                    this.setNM((String)value);
	            return;  
        
             case 3 :
                    this.setTEL((String)value);
	            return;  
        
             case 4 :
                    this.setSIDO_CODE((String)value);
	            return;  
        
             case 5 :
                    this.setSIGUNGU_CODE((String)value);
	            return;  
        
             case 6 :
                    this.setPART((String)value);
	            return;  
        
             case 7 :
                    this.setPOS((String)value);
	            return;  
        
             case 8 :
                    this.setGROUP_CODE((String)value);
	            return;  
        
             case 9 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 10 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 11 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 12 :
                    this.setPASS((String)value);
	            return;  
        
             case 13 :
                    this.setHOME_GROUP((String)value);
	            return;  
        
             case 14 :
                    this.setMOBILE((String)value);
	            return;  
        
             case 15 :
                    this.setE_MAIL((String)value);
	            return;  
        
             case 16 :
                    this.setOFFSEAL((String)value);
	            return;  
        
             case 17 :
                    this.setTEL1((String)value);
	            return;  
        
             case 18 :
                    this.setTEL2((String)value);
	            return;  
        
             case 19 :
                    this.setTEL3((String)value);
	            return;  
        
             case 20 :
                    this.setMOBILE1((String)value);
	            return;  
        
             case 21 :
                    this.setMOBILE2((String)value);
	            return;  
        
             case 22 :
                    this.setMOBILE3((String)value);
	            return;  
        
             case 23 :
                    this.setPHOTO((String)value);
	            return;  
        
             case 24 :
                    this.setFAX1((String)value);
	            return;  
        
             case 25 :
                    this.setFAX2((String)value);
	            return;  
        
             case 26 :
                    this.setFAX3((String)value);
	            return;  
        
             case 27 :
                    this.setFAX((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_MI_USER_BASICHelper.toXML(this);
  }
  
}
