

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_HOM_VISIT_HOUR_COUNT
*  ���̺� ���� :
*  ���̺� PK   :  
*               REG_DATE
*  ���̺� �÷� :  
*               REG_DATE:VARCHAR2(12):  
*               H_01:NUMBER(22):  
*               H_02:NUMBER(22):  
*               H_03:NUMBER(22):  
*               H_04:NUMBER(22):  
*               H_05:NUMBER(22):  
*               H_06:NUMBER(22):  
*               H_07:NUMBER(22):  
*               H_08:NUMBER(22):  
*               H_09:NUMBER(22):  
*               H_10:NUMBER(22):  
*               H_11:NUMBER(22):  
*               H_12:NUMBER(22):  
*               H_13:NUMBER(22):  
*               H_14:NUMBER(22):  
*               H_15:NUMBER(22):  
*               H_16:NUMBER(22):  
*               H_17:NUMBER(22):  
*               H_18:NUMBER(22):  
*               H_19:NUMBER(22):  
*               H_20:NUMBER(22):  
*               H_21:NUMBER(22):  
*               H_22:NUMBER(22):  
*               H_23:NUMBER(22):  
*               H_24:NUMBER(22):  
*               DAY_TOTAL:NUMBER(22):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_HOM_VISIT_HOUR_COUNTEntity extends ValueObject{

  
     private String REG_DATE;
  
     private String H_01;
  
     private String H_02;
  
     private String H_03;
  
     private String H_04;
  
     private String H_05;
  
     private String H_06;
  
     private String H_07;
  
     private String H_08;
  
     private String H_09;
  
     private String H_10;
  
     private String H_11;
  
     private String H_12;
  
     private String H_13;
  
     private String H_14;
  
     private String H_15;
  
     private String H_16;
  
     private String H_17;
  
     private String H_18;
  
     private String H_19;
  
     private String H_20;
  
     private String H_21;
  
     private String H_22;
  
     private String H_23;
  
     private String H_24;
  
     private String DAY_TOTAL;
  

//�����ڸ� �����
    public PT_HOM_VISIT_HOUR_COUNTEntity(){
    }
    
    
    public PT_HOM_VISIT_HOUR_COUNTEntity(String REG_DATE ){
       this.setREG_DATE(REG_DATE);
       
    }
      
    public PT_HOM_VISIT_HOUR_COUNTEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("REG_DATE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("REG_DATE",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.REG_DATE =request.getParameter("REG_DATE");
		this.H_01 =request.getParameter("H_01");
		this.H_02 =request.getParameter("H_02");
		this.H_03 =request.getParameter("H_03");
		this.H_04 =request.getParameter("H_04");
		this.H_05 =request.getParameter("H_05");
		this.H_06 =request.getParameter("H_06");
		this.H_07 =request.getParameter("H_07");
		this.H_08 =request.getParameter("H_08");
		this.H_09 =request.getParameter("H_09");
		this.H_10 =request.getParameter("H_10");
		this.H_11 =request.getParameter("H_11");
		this.H_12 =request.getParameter("H_12");
		this.H_13 =request.getParameter("H_13");
		this.H_14 =request.getParameter("H_14");
		this.H_15 =request.getParameter("H_15");
		this.H_16 =request.getParameter("H_16");
		this.H_17 =request.getParameter("H_17");
		this.H_18 =request.getParameter("H_18");
		this.H_19 =request.getParameter("H_19");
		this.H_20 =request.getParameter("H_20");
		this.H_21 =request.getParameter("H_21");
		this.H_22 =request.getParameter("H_22");
		this.H_23 =request.getParameter("H_23");
		this.H_24 =request.getParameter("H_24");
		this.DAY_TOTAL =request.getParameter("DAY_TOTAL");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.REG_DATE =KJFMi.dsGet(ds, arg_row, "REG_DATE");
		this.H_01 =KJFMi.dsGet(ds, arg_row, "H_01");
		this.H_02 =KJFMi.dsGet(ds, arg_row, "H_02");
		this.H_03 =KJFMi.dsGet(ds, arg_row, "H_03");
		this.H_04 =KJFMi.dsGet(ds, arg_row, "H_04");
		this.H_05 =KJFMi.dsGet(ds, arg_row, "H_05");
		this.H_06 =KJFMi.dsGet(ds, arg_row, "H_06");
		this.H_07 =KJFMi.dsGet(ds, arg_row, "H_07");
		this.H_08 =KJFMi.dsGet(ds, arg_row, "H_08");
		this.H_09 =KJFMi.dsGet(ds, arg_row, "H_09");
		this.H_10 =KJFMi.dsGet(ds, arg_row, "H_10");
		this.H_11 =KJFMi.dsGet(ds, arg_row, "H_11");
		this.H_12 =KJFMi.dsGet(ds, arg_row, "H_12");
		this.H_13 =KJFMi.dsGet(ds, arg_row, "H_13");
		this.H_14 =KJFMi.dsGet(ds, arg_row, "H_14");
		this.H_15 =KJFMi.dsGet(ds, arg_row, "H_15");
		this.H_16 =KJFMi.dsGet(ds, arg_row, "H_16");
		this.H_17 =KJFMi.dsGet(ds, arg_row, "H_17");
		this.H_18 =KJFMi.dsGet(ds, arg_row, "H_18");
		this.H_19 =KJFMi.dsGet(ds, arg_row, "H_19");
		this.H_20 =KJFMi.dsGet(ds, arg_row, "H_20");
		this.H_21 =KJFMi.dsGet(ds, arg_row, "H_21");
		this.H_22 =KJFMi.dsGet(ds, arg_row, "H_22");
		this.H_23 =KJFMi.dsGet(ds, arg_row, "H_23");
		this.H_24 =KJFMi.dsGet(ds, arg_row, "H_24");
		this.DAY_TOTAL =KJFMi.dsGet(ds, arg_row, "DAY_TOTAL");
				
    }    
    
//Getter �Լ��� �����
  
     public String getREG_DATE(){
             return REG_DATE;
     };
  
     public String getH_01(){
             return H_01;
     };
  
     public String getH_02(){
             return H_02;
     };
  
     public String getH_03(){
             return H_03;
     };
  
     public String getH_04(){
             return H_04;
     };
  
     public String getH_05(){
             return H_05;
     };
  
     public String getH_06(){
             return H_06;
     };
  
     public String getH_07(){
             return H_07;
     };
  
     public String getH_08(){
             return H_08;
     };
  
     public String getH_09(){
             return H_09;
     };
  
     public String getH_10(){
             return H_10;
     };
  
     public String getH_11(){
             return H_11;
     };
  
     public String getH_12(){
             return H_12;
     };
  
     public String getH_13(){
             return H_13;
     };
  
     public String getH_14(){
             return H_14;
     };
  
     public String getH_15(){
             return H_15;
     };
  
     public String getH_16(){
             return H_16;
     };
  
     public String getH_17(){
             return H_17;
     };
  
     public String getH_18(){
             return H_18;
     };
  
     public String getH_19(){
             return H_19;
     };
  
     public String getH_20(){
             return H_20;
     };
  
     public String getH_21(){
             return H_21;
     };
  
     public String getH_22(){
             return H_22;
     };
  
     public String getH_23(){
             return H_23;
     };
  
     public String getH_24(){
             return H_24;
     };
  
     public String getDAY_TOTAL(){
             return DAY_TOTAL;
     };
  

//Setter �Լ��� �����
  
     public void setREG_DATE(String REG_DATE){
            this.REG_DATE=REG_DATE;
     };
  
     public void setH_01(String H_01){
            this.H_01=H_01;
     };
  
     public void setH_02(String H_02){
            this.H_02=H_02;
     };
  
     public void setH_03(String H_03){
            this.H_03=H_03;
     };
  
     public void setH_04(String H_04){
            this.H_04=H_04;
     };
  
     public void setH_05(String H_05){
            this.H_05=H_05;
     };
  
     public void setH_06(String H_06){
            this.H_06=H_06;
     };
  
     public void setH_07(String H_07){
            this.H_07=H_07;
     };
  
     public void setH_08(String H_08){
            this.H_08=H_08;
     };
  
     public void setH_09(String H_09){
            this.H_09=H_09;
     };
  
     public void setH_10(String H_10){
            this.H_10=H_10;
     };
  
     public void setH_11(String H_11){
            this.H_11=H_11;
     };
  
     public void setH_12(String H_12){
            this.H_12=H_12;
     };
  
     public void setH_13(String H_13){
            this.H_13=H_13;
     };
  
     public void setH_14(String H_14){
            this.H_14=H_14;
     };
  
     public void setH_15(String H_15){
            this.H_15=H_15;
     };
  
     public void setH_16(String H_16){
            this.H_16=H_16;
     };
  
     public void setH_17(String H_17){
            this.H_17=H_17;
     };
  
     public void setH_18(String H_18){
            this.H_18=H_18;
     };
  
     public void setH_19(String H_19){
            this.H_19=H_19;
     };
  
     public void setH_20(String H_20){
            this.H_20=H_20;
     };
  
     public void setH_21(String H_21){
            this.H_21=H_21;
     };
  
     public void setH_22(String H_22){
            this.H_22=H_22;
     };
  
     public void setH_23(String H_23){
            this.H_23=H_23;
     };
  
     public void setH_24(String H_24){
            this.H_24=H_24;
     };
  
     public void setDAY_TOTAL(String DAY_TOTAL){
            this.DAY_TOTAL=DAY_TOTAL;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("REG_DATE:"+ this.getREG_DATE()+"\n");
      
      strB.append("H_01:"+ this.getH_01()+"\n");
      
      strB.append("H_02:"+ this.getH_02()+"\n");
      
      strB.append("H_03:"+ this.getH_03()+"\n");
      
      strB.append("H_04:"+ this.getH_04()+"\n");
      
      strB.append("H_05:"+ this.getH_05()+"\n");
      
      strB.append("H_06:"+ this.getH_06()+"\n");
      
      strB.append("H_07:"+ this.getH_07()+"\n");
      
      strB.append("H_08:"+ this.getH_08()+"\n");
      
      strB.append("H_09:"+ this.getH_09()+"\n");
      
      strB.append("H_10:"+ this.getH_10()+"\n");
      
      strB.append("H_11:"+ this.getH_11()+"\n");
      
      strB.append("H_12:"+ this.getH_12()+"\n");
      
      strB.append("H_13:"+ this.getH_13()+"\n");
      
      strB.append("H_14:"+ this.getH_14()+"\n");
      
      strB.append("H_15:"+ this.getH_15()+"\n");
      
      strB.append("H_16:"+ this.getH_16()+"\n");
      
      strB.append("H_17:"+ this.getH_17()+"\n");
      
      strB.append("H_18:"+ this.getH_18()+"\n");
      
      strB.append("H_19:"+ this.getH_19()+"\n");
      
      strB.append("H_20:"+ this.getH_20()+"\n");
      
      strB.append("H_21:"+ this.getH_21()+"\n");
      
      strB.append("H_22:"+ this.getH_22()+"\n");
      
      strB.append("H_23:"+ this.getH_23()+"\n");
      
      strB.append("H_24:"+ this.getH_24()+"\n");
      
      strB.append("DAY_TOTAL:"+ this.getDAY_TOTAL()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_HOM_VISIT_HOUR_COUNTHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_HOM_VISIT_HOUR_COUNTHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_HOM_VISIT_HOUR_COUNTHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_HOM_VISIT_HOUR_COUNTHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_HOM_VISIT_HOUR_COUNTHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[1];
       values[0]= this.getREG_DATE();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_HOM_VISIT_HOUR_COUNTEntity();
  }

  public ValueObject getClone(){
         PT_HOM_VISIT_HOUR_COUNTEntity newEnt = new PT_HOM_VISIT_HOUR_COUNTEntity();
	 
          newEnt.setREG_DATE(this.getREG_DATE());
         
          newEnt.setH_01(this.getH_01());
         
          newEnt.setH_02(this.getH_02());
         
          newEnt.setH_03(this.getH_03());
         
          newEnt.setH_04(this.getH_04());
         
          newEnt.setH_05(this.getH_05());
         
          newEnt.setH_06(this.getH_06());
         
          newEnt.setH_07(this.getH_07());
         
          newEnt.setH_08(this.getH_08());
         
          newEnt.setH_09(this.getH_09());
         
          newEnt.setH_10(this.getH_10());
         
          newEnt.setH_11(this.getH_11());
         
          newEnt.setH_12(this.getH_12());
         
          newEnt.setH_13(this.getH_13());
         
          newEnt.setH_14(this.getH_14());
         
          newEnt.setH_15(this.getH_15());
         
          newEnt.setH_16(this.getH_16());
         
          newEnt.setH_17(this.getH_17());
         
          newEnt.setH_18(this.getH_18());
         
          newEnt.setH_19(this.getH_19());
         
          newEnt.setH_20(this.getH_20());
         
          newEnt.setH_21(this.getH_21());
         
          newEnt.setH_22(this.getH_22());
         
          newEnt.setH_23(this.getH_23());
         
          newEnt.setH_24(this.getH_24());
         
          newEnt.setDAY_TOTAL(this.getDAY_TOTAL());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_HOM_VISIT_HOUR_COUNTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getREG_DATE();
        
             case 2 :
                 return  this.getH_01();
        
             case 3 :
                 return  this.getH_02();
        
             case 4 :
                 return  this.getH_03();
        
             case 5 :
                 return  this.getH_04();
        
             case 6 :
                 return  this.getH_05();
        
             case 7 :
                 return  this.getH_06();
        
             case 8 :
                 return  this.getH_07();
        
             case 9 :
                 return  this.getH_08();
        
             case 10 :
                 return  this.getH_09();
        
             case 11 :
                 return  this.getH_10();
        
             case 12 :
                 return  this.getH_11();
        
             case 13 :
                 return  this.getH_12();
        
             case 14 :
                 return  this.getH_13();
        
             case 15 :
                 return  this.getH_14();
        
             case 16 :
                 return  this.getH_15();
        
             case 17 :
                 return  this.getH_16();
        
             case 18 :
                 return  this.getH_17();
        
             case 19 :
                 return  this.getH_18();
        
             case 20 :
                 return  this.getH_19();
        
             case 21 :
                 return  this.getH_20();
        
             case 22 :
                 return  this.getH_21();
        
             case 23 :
                 return  this.getH_22();
        
             case 24 :
                 return  this.getH_23();
        
             case 25 :
                 return  this.getH_24();
        
             case 26 :
                 return  this.getDAY_TOTAL();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_HOM_VISIT_HOUR_COUNTHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setREG_DATE((String)value);
	            return;  
        
             case 2 :
                    this.setH_01((String)value);
	            return;  
        
             case 3 :
                    this.setH_02((String)value);
	            return;  
        
             case 4 :
                    this.setH_03((String)value);
	            return;  
        
             case 5 :
                    this.setH_04((String)value);
	            return;  
        
             case 6 :
                    this.setH_05((String)value);
	            return;  
        
             case 7 :
                    this.setH_06((String)value);
	            return;  
        
             case 8 :
                    this.setH_07((String)value);
	            return;  
        
             case 9 :
                    this.setH_08((String)value);
	            return;  
        
             case 10 :
                    this.setH_09((String)value);
	            return;  
        
             case 11 :
                    this.setH_10((String)value);
	            return;  
        
             case 12 :
                    this.setH_11((String)value);
	            return;  
        
             case 13 :
                    this.setH_12((String)value);
	            return;  
        
             case 14 :
                    this.setH_13((String)value);
	            return;  
        
             case 15 :
                    this.setH_14((String)value);
	            return;  
        
             case 16 :
                    this.setH_15((String)value);
	            return;  
        
             case 17 :
                    this.setH_16((String)value);
	            return;  
        
             case 18 :
                    this.setH_17((String)value);
	            return;  
        
             case 19 :
                    this.setH_18((String)value);
	            return;  
        
             case 20 :
                    this.setH_19((String)value);
	            return;  
        
             case 21 :
                    this.setH_20((String)value);
	            return;  
        
             case 22 :
                    this.setH_21((String)value);
	            return;  
        
             case 23 :
                    this.setH_22((String)value);
	            return;  
        
             case 24 :
                    this.setH_23((String)value);
	            return;  
        
             case 25 :
                    this.setH_24((String)value);
	            return;  
        
             case 26 :
                    this.setDAY_TOTAL((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_HOM_VISIT_HOUR_COUNTHelper.toXML(this);
  }
  
}
