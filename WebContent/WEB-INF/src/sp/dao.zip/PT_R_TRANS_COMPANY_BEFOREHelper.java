

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_TRANS_COMPANY_BEFORE
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE  
*               TMP_WRT_NUM
*  ���̺� �÷� :  
*               TMP_WRT_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               COMMANA_CLASS:VARCHAR2(1):  
*               MANA_NUM:VARCHAR2(18):  
*               NAME:VARCHAR2(50):  
*               REP_SSN1:VARCHAR2(18):  
*               REP_SSN2:VARCHAR2(21):  
*               REP_NM_KOR:VARCHAR2(20):  
*               REP_NM_HAN:VARCHAR2(20):  
*               REP_TEL_NUM:VARCHAR2(17):  
*               ADDR_POST_NUM:VARCHAR2(6):  
*               ADDR_ADDR:VARCHAR2(120):  
*               ADDR_DETAIL_ADDR:VARCHAR2(120):  
*               ADDR_TEL_NUM:VARCHAR2(17):  
*               ADDR_FAX_NUM:VARCHAR2(17):  
*               EMAIL_ADDR:VARCHAR2(30):  
*               OFFICE_AREA:VARCHAR2(10):  
*               OFFICE_USE_CODE:VARCHAR2(6):  
*               COMPANY_DIAG_CLASS_CODE:VARCHAR2(6):  
*               COMPANY_DIAG_BAS_DT:VARCHAR2(8):  
*               COMPANY_DIAG_ISSUE_DT:VARCHAR2(8):  
*               DIAG_ORG_CODE:VARCHAR2(6):  
*               DIAG_NM_NM:VARCHAR2(50):  
*               DIAG_NM_WRT_NUM:VARCHAR2(50):  
*               PAY_CAP:VARCHAR2(15):  
*               REA_CAP:VARCHAR2(15):  
*               TUP_AOM:VARCHAR2(15):  
*               TUP_CLASS_CODE:VARCHAR2(6):  
*               C_COM_DT:VARCHAR2(8):  
*               C_COM_CAUSE_CODE:VARCHAR2(6):  
*               COM_COV_DT:VARCHAR2(8):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(8):  
*               BAS_STA_DT:VARCHAR2(8):  
*               OFFICE_OWN_CLASS:VARCHAR2(1):  
*               COI_WRT_NUM:VARCHAR2(12):  
*               REP_MOBILE:VARCHAR2(17):  
*               LICTAX:VARCHAR2(1):  
*               HOSCRE:VARCHAR2(1):  
*               SND_DT:VARCHAR2(8):  
*               SND_STE:VARCHAR2(1):  
*               COM_NUM:VARCHAR2(13):  
*               ADDR_TEL_NUM1:VARCHAR2(4):  
*               ADDR_TEL_NUM2:VARCHAR2(4):  
*               ADDR_TEL_NUM3:VARCHAR2(4):  
*               ADDR_FAX_NUM1:VARCHAR2(4):  
*               ADDR_FAX_NUM2:VARCHAR2(4):  
*               ADDR_FAX_NUM3:VARCHAR2(4):  
*               REP_MOBILE1:VARCHAR2(4):  
*               REP_MOBILE2:VARCHAR2(4):  
*               REP_MOBILE3:VARCHAR2(4):  
*               RECV_NUM:VARCHAR2(20):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_TRANS_COMPANY_BEFOREHelper{

  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String COMMANA_CLASS = "COMMANA_CLASS";
  final static public String MANA_NUM = "MANA_NUM";
  final static public String NAME = "NAME";
  final static public String REP_SSN1 = "REP_SSN1";
  final static public String REP_SSN2 = "REP_SSN2";
  final static public String REP_NM_KOR = "REP_NM_KOR";
  final static public String REP_NM_HAN = "REP_NM_HAN";
  final static public String REP_TEL_NUM = "REP_TEL_NUM";
  final static public String ADDR_POST_NUM = "ADDR_POST_NUM";
  final static public String ADDR_ADDR = "ADDR_ADDR";
  final static public String ADDR_DETAIL_ADDR = "ADDR_DETAIL_ADDR";
  final static public String ADDR_TEL_NUM = "ADDR_TEL_NUM";
  final static public String ADDR_FAX_NUM = "ADDR_FAX_NUM";
  final static public String EMAIL_ADDR = "EMAIL_ADDR";
  final static public String OFFICE_AREA = "OFFICE_AREA";
  final static public String OFFICE_USE_CODE = "OFFICE_USE_CODE";
  final static public String COMPANY_DIAG_CLASS_CODE = "COMPANY_DIAG_CLASS_CODE";
  final static public String COMPANY_DIAG_BAS_DT = "COMPANY_DIAG_BAS_DT";
  final static public String COMPANY_DIAG_ISSUE_DT = "COMPANY_DIAG_ISSUE_DT";
  final static public String DIAG_ORG_CODE = "DIAG_ORG_CODE";
  final static public String DIAG_NM_NM = "DIAG_NM_NM";
  final static public String DIAG_NM_WRT_NUM = "DIAG_NM_WRT_NUM";
  final static public String PAY_CAP = "PAY_CAP";
  final static public String REA_CAP = "REA_CAP";
  final static public String TUP_AOM = "TUP_AOM";
  final static public String TUP_CLASS_CODE = "TUP_CLASS_CODE";
  final static public String C_COM_DT = "C_COM_DT";
  final static public String C_COM_CAUSE_CODE = "C_COM_CAUSE_CODE";
  final static public String COM_COV_DT = "COM_COV_DT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String WRT_DT = "WRT_DT";
  final static public String BAS_STA_DT = "BAS_STA_DT";
  final static public String OFFICE_OWN_CLASS = "OFFICE_OWN_CLASS";
  final static public String COI_WRT_NUM = "COI_WRT_NUM";
  final static public String REP_MOBILE = "REP_MOBILE";
  final static public String LICTAX = "LICTAX";
  final static public String HOSCRE = "HOSCRE";
  final static public String SND_DT = "SND_DT";
  final static public String SND_STE = "SND_STE";
  final static public String COM_NUM = "COM_NUM";
  final static public String ADDR_TEL_NUM1 = "ADDR_TEL_NUM1";
  final static public String ADDR_TEL_NUM2 = "ADDR_TEL_NUM2";
  final static public String ADDR_TEL_NUM3 = "ADDR_TEL_NUM3";
  final static public String ADDR_FAX_NUM1 = "ADDR_FAX_NUM1";
  final static public String ADDR_FAX_NUM2 = "ADDR_FAX_NUM2";
  final static public String ADDR_FAX_NUM3 = "ADDR_FAX_NUM3";
  final static public String REP_MOBILE1 = "REP_MOBILE1";
  final static public String REP_MOBILE2 = "REP_MOBILE2";
  final static public String REP_MOBILE3 = "REP_MOBILE3";
  final static public String RECV_NUM = "RECV_NUM";
  


  public static HashMap fieldMap = new HashMap(54);
  static{
  fieldMap.put(TMP_WRT_NUM,new Integer(1) );
  fieldMap.put(SIDO_CODE,new Integer(2) );
  fieldMap.put(COMMANA_CLASS,new Integer(3) );
  fieldMap.put(MANA_NUM,new Integer(4) );
  fieldMap.put(NAME,new Integer(5) );
  fieldMap.put(REP_SSN1,new Integer(6) );
  fieldMap.put(REP_SSN2,new Integer(7) );
  fieldMap.put(REP_NM_KOR,new Integer(8) );
  fieldMap.put(REP_NM_HAN,new Integer(9) );
  fieldMap.put(REP_TEL_NUM,new Integer(10) );
  fieldMap.put(ADDR_POST_NUM,new Integer(11) );
  fieldMap.put(ADDR_ADDR,new Integer(12) );
  fieldMap.put(ADDR_DETAIL_ADDR,new Integer(13) );
  fieldMap.put(ADDR_TEL_NUM,new Integer(14) );
  fieldMap.put(ADDR_FAX_NUM,new Integer(15) );
  fieldMap.put(EMAIL_ADDR,new Integer(16) );
  fieldMap.put(OFFICE_AREA,new Integer(17) );
  fieldMap.put(OFFICE_USE_CODE,new Integer(18) );
  fieldMap.put(COMPANY_DIAG_CLASS_CODE,new Integer(19) );
  fieldMap.put(COMPANY_DIAG_BAS_DT,new Integer(20) );
  fieldMap.put(COMPANY_DIAG_ISSUE_DT,new Integer(21) );
  fieldMap.put(DIAG_ORG_CODE,new Integer(22) );
  fieldMap.put(DIAG_NM_NM,new Integer(23) );
  fieldMap.put(DIAG_NM_WRT_NUM,new Integer(24) );
  fieldMap.put(PAY_CAP,new Integer(25) );
  fieldMap.put(REA_CAP,new Integer(26) );
  fieldMap.put(TUP_AOM,new Integer(27) );
  fieldMap.put(TUP_CLASS_CODE,new Integer(28) );
  fieldMap.put(C_COM_DT,new Integer(29) );
  fieldMap.put(C_COM_CAUSE_CODE,new Integer(30) );
  fieldMap.put(COM_COV_DT,new Integer(31) );
  fieldMap.put(WRT_ID,new Integer(32) );
  fieldMap.put(UPD_DT,new Integer(33) );
  fieldMap.put(INS_DT,new Integer(34) );
  fieldMap.put(WRT_DT,new Integer(35) );
  fieldMap.put(BAS_STA_DT,new Integer(36) );
  fieldMap.put(OFFICE_OWN_CLASS,new Integer(37) );
  fieldMap.put(COI_WRT_NUM,new Integer(38) );
  fieldMap.put(REP_MOBILE,new Integer(39) );
  fieldMap.put(LICTAX,new Integer(40) );
  fieldMap.put(HOSCRE,new Integer(41) );
  fieldMap.put(SND_DT,new Integer(42) );
  fieldMap.put(SND_STE,new Integer(43) );
  fieldMap.put(COM_NUM,new Integer(44) );
  fieldMap.put(ADDR_TEL_NUM1,new Integer(45) );
  fieldMap.put(ADDR_TEL_NUM2,new Integer(46) );
  fieldMap.put(ADDR_TEL_NUM3,new Integer(47) );
  fieldMap.put(ADDR_FAX_NUM1,new Integer(48) );
  fieldMap.put(ADDR_FAX_NUM2,new Integer(49) );
  fieldMap.put(ADDR_FAX_NUM3,new Integer(50) );
  fieldMap.put(REP_MOBILE1,new Integer(51) );
  fieldMap.put(REP_MOBILE2,new Integer(52) );
  fieldMap.put(REP_MOBILE3,new Integer(53) );
  fieldMap.put(RECV_NUM,new Integer(54) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_TRANS_COMPANY_BEFORE";
     final public static String PREFIX = "sp.dao.PT_R_TRANS_COMPANY_BEFORE";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SIDO_CODE,TMP_WRT_NUM };
     final public static String FIELD_LIST[] = { 
       TMP_WRT_NUM,SIDO_CODE,COMMANA_CLASS,MANA_NUM,NAME,REP_SSN1,REP_SSN2,REP_NM_KOR,REP_NM_HAN,REP_TEL_NUM,ADDR_POST_NUM,ADDR_ADDR,ADDR_DETAIL_ADDR,ADDR_TEL_NUM,ADDR_FAX_NUM,EMAIL_ADDR,OFFICE_AREA,OFFICE_USE_CODE,COMPANY_DIAG_CLASS_CODE,COMPANY_DIAG_BAS_DT,COMPANY_DIAG_ISSUE_DT,DIAG_ORG_CODE,DIAG_NM_NM,DIAG_NM_WRT_NUM,PAY_CAP,REA_CAP,TUP_AOM,TUP_CLASS_CODE,C_COM_DT,C_COM_CAUSE_CODE,COM_COV_DT,WRT_ID,UPD_DT,INS_DT,WRT_DT,BAS_STA_DT,OFFICE_OWN_CLASS,COI_WRT_NUM,REP_MOBILE,LICTAX,HOSCRE,SND_DT,SND_STE,COM_NUM,ADDR_TEL_NUM1,ADDR_TEL_NUM2,ADDR_TEL_NUM3,ADDR_FAX_NUM1,ADDR_FAX_NUM2,ADDR_FAX_NUM3,REP_MOBILE1,REP_MOBILE2,REP_MOBILE3,RECV_NUM };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
             case 21 : 
	                  return  "";
             case 22 : 
	                  return  "";
             case 23 : 
	                  return  "";
             case 24 : 
	                  return  "";
             case 25 : 
	                  return  "";
             case 26 : 
	                  return  "";
             case 27 : 
	                  return  "";
             case 28 : 
	                  return  "";
             case 29 : 
	                  return  "";
             case 30 : 
	                  return  "";
             case 31 : 
	                  return  "";
             case 32 : 
	                  return  "";
             case 33 : 
	                  return  "";
             case 34 : 
	                  return  "";
             case 35 : 
	                  return  "";
             case 36 : 
	                  return  "";
             case 37 : 
	                  return  "";
             case 38 : 
	                  return  "";
             case 39 : 
	                  return  "";
             case 40 : 
	                  return  "";
             case 41 : 
	                  return  "";
             case 42 : 
	                  return  "";
             case 43 : 
	                  return  "";
             case 44 : 
	                  return  "";
             case 45 : 
	                  return  "";
             case 46 : 
	                  return  "";
             case 47 : 
	                  return  "";
             case 48 : 
	                  return  "";
             case 49 : 
	                  return  "";
             case 50 : 
	                  return  "";
             case 51 : 
	                  return  "";
             case 52 : 
	                  return  "";
             case 53 : 
	                  return  "";
             case 54 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_TRANS_COMPANY_BEFOREEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMMANA_CLASS").append("'")
            .append(" value='").append(""+ent.getCOMMANA_CLASS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MANA_NUM").append("'")
            .append(" value='").append(""+ent.getMANA_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NAME").append("'")
            .append(" value='").append(""+ent.getNAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_SSN1").append("'")
            .append(" value='").append(""+ent.getREP_SSN1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_SSN2").append("'")
            .append(" value='").append(""+ent.getREP_SSN2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NM_KOR").append("'")
            .append(" value='").append(""+ent.getREP_NM_KOR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NM_HAN").append("'")
            .append(" value='").append(""+ent.getREP_NM_HAN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_TEL_NUM").append("'")
            .append(" value='").append(""+ent.getREP_TEL_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_POST_NUM").append("'")
            .append(" value='").append(""+ent.getADDR_POST_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_ADDR").append("'")
            .append(" value='").append(""+ent.getADDR_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_DETAIL_ADDR").append("'")
            .append(" value='").append(""+ent.getADDR_DETAIL_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_TEL_NUM").append("'")
            .append(" value='").append(""+ent.getADDR_TEL_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_FAX_NUM").append("'")
            .append(" value='").append(""+ent.getADDR_FAX_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("EMAIL_ADDR").append("'")
            .append(" value='").append(""+ent.getEMAIL_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFICE_AREA").append("'")
            .append(" value='").append(""+ent.getOFFICE_AREA()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFICE_USE_CODE").append("'")
            .append(" value='").append(""+ent.getOFFICE_USE_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_CLASS_CODE").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_CLASS_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_BAS_DT").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_BAS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COMPANY_DIAG_ISSUE_DT").append("'")
            .append(" value='").append(""+ent.getCOMPANY_DIAG_ISSUE_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_ORG_CODE").append("'")
            .append(" value='").append(""+ent.getDIAG_ORG_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_NM_NM").append("'")
            .append(" value='").append(""+ent.getDIAG_NM_NM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DIAG_NM_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getDIAG_NM_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PAY_CAP").append("'")
            .append(" value='").append(""+ent.getPAY_CAP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REA_CAP").append("'")
            .append(" value='").append(""+ent.getREA_CAP()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TUP_AOM").append("'")
            .append(" value='").append(""+ent.getTUP_AOM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TUP_CLASS_CODE").append("'")
            .append(" value='").append(""+ent.getTUP_CLASS_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("C_COM_DT").append("'")
            .append(" value='").append(""+ent.getC_COM_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("C_COM_CAUSE_CODE").append("'")
            .append(" value='").append(""+ent.getC_COM_CAUSE_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COM_COV_DT").append("'")
            .append(" value='").append(""+ent.getCOM_COV_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BAS_STA_DT").append("'")
            .append(" value='").append(""+ent.getBAS_STA_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFICE_OWN_CLASS").append("'")
            .append(" value='").append(""+ent.getOFFICE_OWN_CLASS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COI_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getCOI_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_MOBILE").append("'")
            .append(" value='").append(""+ent.getREP_MOBILE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LICTAX").append("'")
            .append(" value='").append(""+ent.getLICTAX()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("HOSCRE").append("'")
            .append(" value='").append(""+ent.getHOSCRE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SND_DT").append("'")
            .append(" value='").append(""+ent.getSND_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SND_STE").append("'")
            .append(" value='").append(""+ent.getSND_STE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COM_NUM").append("'")
            .append(" value='").append(""+ent.getCOM_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_TEL_NUM1").append("'")
            .append(" value='").append(""+ent.getADDR_TEL_NUM1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_TEL_NUM2").append("'")
            .append(" value='").append(""+ent.getADDR_TEL_NUM2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_TEL_NUM3").append("'")
            .append(" value='").append(""+ent.getADDR_TEL_NUM3()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_FAX_NUM1").append("'")
            .append(" value='").append(""+ent.getADDR_FAX_NUM1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_FAX_NUM2").append("'")
            .append(" value='").append(""+ent.getADDR_FAX_NUM2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_FAX_NUM3").append("'")
            .append(" value='").append(""+ent.getADDR_FAX_NUM3()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_MOBILE1").append("'")
            .append(" value='").append(""+ent.getREP_MOBILE1()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_MOBILE2").append("'")
            .append(" value='").append(""+ent.getREP_MOBILE2()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_MOBILE3").append("'")
            .append(" value='").append(""+ent.getREP_MOBILE3()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
