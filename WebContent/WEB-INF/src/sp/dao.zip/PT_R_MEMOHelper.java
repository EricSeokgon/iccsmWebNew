

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_MEMO
*  ���̺� ���� :
*  ���̺� PK   :  
*               MEMO_SEQ  
*               RECV_NUM  
*               SIDO_CODE
*  ���̺� �÷� :  
*               MEMO_SEQ:NUMBER(4):  
*               MEMO_CONT:VARCHAR2(256):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               RECV_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               INS_DT:VARCHAR2(24):  
*               WRT_DT:VARCHAR2(8):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_MEMOHelper{

  final static public String MEMO_SEQ = "MEMO_SEQ";
  final static public String MEMO_CONT = "MEMO_CONT";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String RECV_NUM = "RECV_NUM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String INS_DT = "INS_DT";
  final static public String WRT_DT = "WRT_DT";
  


  public static HashMap fieldMap = new HashMap(8);
  static{
  fieldMap.put(MEMO_SEQ,new Integer(1) );
  fieldMap.put(MEMO_CONT,new Integer(2) );
  fieldMap.put(WRT_ID,new Integer(3) );
  fieldMap.put(UPD_DT,new Integer(4) );
  fieldMap.put(RECV_NUM,new Integer(5) );
  fieldMap.put(SIDO_CODE,new Integer(6) );
  fieldMap.put(INS_DT,new Integer(7) );
  fieldMap.put(WRT_DT,new Integer(8) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_MEMO";
     final public static String PREFIX = "sp.dao.PT_R_MEMO";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       MEMO_SEQ,RECV_NUM,SIDO_CODE };
     final public static String FIELD_LIST[] = { 
       MEMO_SEQ,MEMO_CONT,WRT_ID,UPD_DT,RECV_NUM,SIDO_CODE,INS_DT,WRT_DT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_MEMOEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MEMO_SEQ").append("'")
            .append(" value='").append(""+ent.getMEMO_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MEMO_CONT").append("'")
            .append(" value='").append(""+ent.getMEMO_CONT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
