

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_R_BASIC_STATEMENT
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE
*  ���̺� �÷� :  
*               RECV_NUM:VARCHAR2(12):  
*               SIDO_CODE:VARCHAR2(4):  
*               RECV_DT:VARCHAR2(8):  
*               RECV_TIME:VARCHAR2(4):  
*               PROC_LIM:VARCHAR2(8):  
*               OFFI_PART:VARCHAR2(50):  
*               OFFI_PART_REBO_WRT_NUM:VARCHAR2(12):  
*               COI_WRT_NUM:VARCHAR2(12):  
*               DEFI_STE:VARCHAR2(1):  
*               WRT_ID:VARCHAR2(16):  
*               UPD_DT:VARCHAR2(24):  
*               INS_DT:VARCHAR2(24):  
*               NAME:VARCHAR2(50):  
*               REP_NM_KOR:VARCHAR2(20):  
*               ADDR_ADDR:VARCHAR2(200):  
*               WRT_DT:VARCHAR2(8):  
*               PROC_TIME:VARCHAR2(6):  
*               ADDR_DETAIL_ADDR:VARCHAR2(120):  
*               ADDR_POST_NUM:VARCHAR2(6):  
*               TMP_WRT_NUM:VARCHAR2(12):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_R_BASIC_STATEMENTHelper{

  final static public String RECV_NUM = "RECV_NUM";
  final static public String SIDO_CODE = "SIDO_CODE";
  final static public String RECV_DT = "RECV_DT";
  final static public String RECV_TIME = "RECV_TIME";
  final static public String PROC_LIM = "PROC_LIM";
  final static public String OFFI_PART = "OFFI_PART";
  final static public String OFFI_PART_REBO_WRT_NUM = "OFFI_PART_REBO_WRT_NUM";
  final static public String COI_WRT_NUM = "COI_WRT_NUM";
  final static public String DEFI_STE = "DEFI_STE";
  final static public String WRT_ID = "WRT_ID";
  final static public String UPD_DT = "UPD_DT";
  final static public String INS_DT = "INS_DT";
  final static public String NAME = "NAME";
  final static public String REP_NM_KOR = "REP_NM_KOR";
  final static public String ADDR_ADDR = "ADDR_ADDR";
  final static public String WRT_DT = "WRT_DT";
  final static public String PROC_TIME = "PROC_TIME";
  final static public String ADDR_DETAIL_ADDR = "ADDR_DETAIL_ADDR";
  final static public String ADDR_POST_NUM = "ADDR_POST_NUM";
  final static public String TMP_WRT_NUM = "TMP_WRT_NUM";
  


  public static HashMap fieldMap = new HashMap(20);
  static{
  fieldMap.put(RECV_NUM,new Integer(1) );
  fieldMap.put(SIDO_CODE,new Integer(2) );
  fieldMap.put(RECV_DT,new Integer(3) );
  fieldMap.put(RECV_TIME,new Integer(4) );
  fieldMap.put(PROC_LIM,new Integer(5) );
  fieldMap.put(OFFI_PART,new Integer(6) );
  fieldMap.put(OFFI_PART_REBO_WRT_NUM,new Integer(7) );
  fieldMap.put(COI_WRT_NUM,new Integer(8) );
  fieldMap.put(DEFI_STE,new Integer(9) );
  fieldMap.put(WRT_ID,new Integer(10) );
  fieldMap.put(UPD_DT,new Integer(11) );
  fieldMap.put(INS_DT,new Integer(12) );
  fieldMap.put(NAME,new Integer(13) );
  fieldMap.put(REP_NM_KOR,new Integer(14) );
  fieldMap.put(ADDR_ADDR,new Integer(15) );
  fieldMap.put(WRT_DT,new Integer(16) );
  fieldMap.put(PROC_TIME,new Integer(17) );
  fieldMap.put(ADDR_DETAIL_ADDR,new Integer(18) );
  fieldMap.put(ADDR_POST_NUM,new Integer(19) );
  fieldMap.put(TMP_WRT_NUM,new Integer(20) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_R_BASIC_STATEMENT";
     final public static String PREFIX = "sp.dao.PT_R_BASIC_STATEMENT";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       RECV_NUM,SIDO_CODE };
     final public static String FIELD_LIST[] = { 
       RECV_NUM,SIDO_CODE,RECV_DT,RECV_TIME,PROC_LIM,OFFI_PART,OFFI_PART_REBO_WRT_NUM,COI_WRT_NUM,DEFI_STE,WRT_ID,UPD_DT,INS_DT,NAME,REP_NM_KOR,ADDR_ADDR,WRT_DT,PROC_TIME,ADDR_DETAIL_ADDR,ADDR_POST_NUM,TMP_WRT_NUM };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
             case 14 : 
	                  return  "";
             case 15 : 
	                  return  "";
             case 16 : 
	                  return  "";
             case 17 : 
	                  return  "";
             case 18 : 
	                  return  "";
             case 19 : 
	                  return  "";
             case 20 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_R_BASIC_STATEMENTEntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_NUM").append("'")
            .append(" value='").append(""+ent.getRECV_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SIDO_CODE").append("'")
            .append(" value='").append(""+ent.getSIDO_CODE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_DT").append("'")
            .append(" value='").append(""+ent.getRECV_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("RECV_TIME").append("'")
            .append(" value='").append(""+ent.getRECV_TIME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PROC_LIM").append("'")
            .append(" value='").append(""+ent.getPROC_LIM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFI_PART").append("'")
            .append(" value='").append(""+ent.getOFFI_PART()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("OFFI_PART_REBO_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getOFFI_PART_REBO_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("COI_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getCOI_WRT_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DEFI_STE").append("'")
            .append(" value='").append(""+ent.getDEFI_STE()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("NAME").append("'")
            .append(" value='").append(""+ent.getNAME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("REP_NM_KOR").append("'")
            .append(" value='").append(""+ent.getREP_NM_KOR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_ADDR").append("'")
            .append(" value='").append(""+ent.getADDR_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_DT").append("'")
            .append(" value='").append(""+ent.getWRT_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("PROC_TIME").append("'")
            .append(" value='").append(""+ent.getPROC_TIME()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_DETAIL_ADDR").append("'")
            .append(" value='").append(""+ent.getADDR_DETAIL_ADDR()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ADDR_POST_NUM").append("'")
            .append(" value='").append(""+ent.getADDR_POST_NUM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("TMP_WRT_NUM").append("'")
            .append(" value='").append(""+ent.getTMP_WRT_NUM()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
