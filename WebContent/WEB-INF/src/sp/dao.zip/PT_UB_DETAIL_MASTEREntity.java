

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_DETAIL_MASTER
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(22):  
*               ITEM:VARCHAR2(4):  
*               LARCLAS:VARCHAR2(255):  
*               SMACLAS:VARCHAR2(255):  
*               CONT:VARCHAR2(255):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               MIDCLAS:VARCHAR2(255):  
*               BAS:VARCHAR2(200):  
*               CONT_YN:VARCHAR2(10):  
*               ORDER_SEQ:NUMBER(4):  
*               DETAIL_CONT:VARCHAR2(255):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_UB_DETAIL_MASTEREntity extends ValueObject{

  
     private String SEQ;
  
     private String ITEM;
  
     private String LARCLAS;
  
     private String SMACLAS;
  
     private String CONT;
  
     private String WRT_ID;
  
     private String INS_DT;
  
     private String UPD_DT;
  
     private String MIDCLAS;
  
     private String BAS;
  
     private String CONT_YN;
  
     private String ORDER_SEQ;
  
     private String DETAIL_CONT;
  

//�����ڸ� �����
    public PT_UB_DETAIL_MASTEREntity(){
    }
    
    
    public PT_UB_DETAIL_MASTEREntity(String SEQ ){
       this.setSEQ(SEQ);
       
    }
      
    public PT_UB_DETAIL_MASTEREntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("SEQ");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SEQ",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.SEQ =request.getParameter("SEQ");
		this.ITEM =request.getParameter("ITEM");
		this.LARCLAS =request.getParameter("LARCLAS");
		this.SMACLAS =request.getParameter("SMACLAS");
		this.CONT =request.getParameter("CONT");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.INS_DT =request.getParameter("INS_DT");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.MIDCLAS =request.getParameter("MIDCLAS");
		this.BAS =request.getParameter("BAS");
		this.CONT_YN =request.getParameter("CONT_YN");
		this.ORDER_SEQ =request.getParameter("ORDER_SEQ");
		this.DETAIL_CONT =request.getParameter("DETAIL_CONT");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.SEQ =KJFMi.dsGet(ds, arg_row, "SEQ");
		this.ITEM =KJFMi.dsGet(ds, arg_row, "ITEM");
		this.LARCLAS =KJFMi.dsGet(ds, arg_row, "LARCLAS");
		this.SMACLAS =KJFMi.dsGet(ds, arg_row, "SMACLAS");
		this.CONT =KJFMi.dsGet(ds, arg_row, "CONT");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.MIDCLAS =KJFMi.dsGet(ds, arg_row, "MIDCLAS");
		this.BAS =KJFMi.dsGet(ds, arg_row, "BAS");
		this.CONT_YN =KJFMi.dsGet(ds, arg_row, "CONT_YN");
		this.ORDER_SEQ =KJFMi.dsGet(ds, arg_row, "ORDER_SEQ");
		this.DETAIL_CONT =KJFMi.dsGet(ds, arg_row, "DETAIL_CONT");
				
    }    
    
//Getter �Լ��� �����
  
     public String getSEQ(){
             return SEQ;
     };
  
     public String getITEM(){
             return ITEM;
     };
  
     public String getLARCLAS(){
             return LARCLAS;
     };
  
     public String getSMACLAS(){
             return SMACLAS;
     };
  
     public String getCONT(){
             return CONT;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getMIDCLAS(){
             return MIDCLAS;
     };
  
     public String getBAS(){
             return BAS;
     };
  
     public String getCONT_YN(){
             return CONT_YN;
     };
  
     public String getORDER_SEQ(){
             return ORDER_SEQ;
     };
  
     public String getDETAIL_CONT(){
             return DETAIL_CONT;
     };
  

//Setter �Լ��� �����
  
     public void setSEQ(String SEQ){
            this.SEQ=SEQ;
     };
  
     public void setITEM(String ITEM){
            this.ITEM=ITEM;
     };
  
     public void setLARCLAS(String LARCLAS){
            this.LARCLAS=LARCLAS;
     };
  
     public void setSMACLAS(String SMACLAS){
            this.SMACLAS=SMACLAS;
     };
  
     public void setCONT(String CONT){
            this.CONT=CONT;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setMIDCLAS(String MIDCLAS){
            this.MIDCLAS=MIDCLAS;
     };
  
     public void setBAS(String BAS){
            this.BAS=BAS;
     };
  
     public void setCONT_YN(String CONT_YN){
            this.CONT_YN=CONT_YN;
     };
  
     public void setORDER_SEQ(String ORDER_SEQ){
            this.ORDER_SEQ=ORDER_SEQ;
     };
  
     public void setDETAIL_CONT(String DETAIL_CONT){
            this.DETAIL_CONT=DETAIL_CONT;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("SEQ:"+ this.getSEQ()+"\n");
      
      strB.append("ITEM:"+ this.getITEM()+"\n");
      
      strB.append("LARCLAS:"+ this.getLARCLAS()+"\n");
      
      strB.append("SMACLAS:"+ this.getSMACLAS()+"\n");
      
      strB.append("CONT:"+ this.getCONT()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("MIDCLAS:"+ this.getMIDCLAS()+"\n");
      
      strB.append("BAS:"+ this.getBAS()+"\n");
      
      strB.append("CONT_YN:"+ this.getCONT_YN()+"\n");
      
      strB.append("ORDER_SEQ:"+ this.getORDER_SEQ()+"\n");
      
      strB.append("DETAIL_CONT:"+ this.getDETAIL_CONT()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_UB_DETAIL_MASTERHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_UB_DETAIL_MASTERHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_UB_DETAIL_MASTERHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_UB_DETAIL_MASTERHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_UB_DETAIL_MASTERHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[1];
       values[0]= this.getSEQ();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_UB_DETAIL_MASTEREntity();
  }

  public ValueObject getClone(){
         PT_UB_DETAIL_MASTEREntity newEnt = new PT_UB_DETAIL_MASTEREntity();
	 
          newEnt.setSEQ(this.getSEQ());
         
          newEnt.setITEM(this.getITEM());
         
          newEnt.setLARCLAS(this.getLARCLAS());
         
          newEnt.setSMACLAS(this.getSMACLAS());
         
          newEnt.setCONT(this.getCONT());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setMIDCLAS(this.getMIDCLAS());
         
          newEnt.setBAS(this.getBAS());
         
          newEnt.setCONT_YN(this.getCONT_YN());
         
          newEnt.setORDER_SEQ(this.getORDER_SEQ());
         
          newEnt.setDETAIL_CONT(this.getDETAIL_CONT());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_UB_DETAIL_MASTERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getSEQ();
        
             case 2 :
                 return  this.getITEM();
        
             case 3 :
                 return  this.getLARCLAS();
        
             case 4 :
                 return  this.getSMACLAS();
        
             case 5 :
                 return  this.getCONT();
        
             case 6 :
                 return  this.getWRT_ID();
        
             case 7 :
                 return  this.getINS_DT();
        
             case 8 :
                 return  this.getUPD_DT();
        
             case 9 :
                 return  this.getMIDCLAS();
        
             case 10 :
                 return  this.getBAS();
        
             case 11 :
                 return  this.getCONT_YN();
        
             case 12 :
                 return  this.getORDER_SEQ();
        
             case 13 :
                 return  this.getDETAIL_CONT();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_UB_DETAIL_MASTERHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setSEQ((String)value);
	            return;  
        
             case 2 :
                    this.setITEM((String)value);
	            return;  
        
             case 3 :
                    this.setLARCLAS((String)value);
	            return;  
        
             case 4 :
                    this.setSMACLAS((String)value);
	            return;  
        
             case 5 :
                    this.setCONT((String)value);
	            return;  
        
             case 6 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 7 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 8 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 9 :
                    this.setMIDCLAS((String)value);
	            return;  
        
             case 10 :
                    this.setBAS((String)value);
	            return;  
        
             case 11 :
                    this.setCONT_YN((String)value);
	            return;  
        
             case 12 :
                    this.setORDER_SEQ((String)value);
	            return;  
        
             case 13 :
                    this.setDETAIL_CONT((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_UB_DETAIL_MASTERHelper.toXML(this);
  }
  
}
