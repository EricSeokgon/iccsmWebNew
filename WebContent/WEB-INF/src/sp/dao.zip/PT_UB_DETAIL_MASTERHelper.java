

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_DETAIL_MASTER
*  ���̺� ���� :
*  ���̺� PK   :  
*               SEQ
*  ���̺� �÷� :  
*               SEQ:NUMBER(22):  
*               ITEM:VARCHAR2(4):  
*               LARCLAS:VARCHAR2(255):  
*               SMACLAS:VARCHAR2(255):  
*               CONT:VARCHAR2(255):  
*               WRT_ID:VARCHAR2(16):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               MIDCLAS:VARCHAR2(255):  
*               BAS:VARCHAR2(200):  
*               CONT_YN:VARCHAR2(10):  
*               ORDER_SEQ:NUMBER(4):  
*               DETAIL_CONT:VARCHAR2(255):
*/
package sp.dao;


import kjf.ops.*;

import java.util.*;

public class PT_UB_DETAIL_MASTERHelper{

  final static public String SEQ = "SEQ";
  final static public String ITEM = "ITEM";
  final static public String LARCLAS = "LARCLAS";
  final static public String SMACLAS = "SMACLAS";
  final static public String CONT = "CONT";
  final static public String WRT_ID = "WRT_ID";
  final static public String INS_DT = "INS_DT";
  final static public String UPD_DT = "UPD_DT";
  final static public String MIDCLAS = "MIDCLAS";
  final static public String BAS = "BAS";
  final static public String CONT_YN = "CONT_YN";
  final static public String ORDER_SEQ = "ORDER_SEQ";
  final static public String DETAIL_CONT = "DETAIL_CONT";
  


  public static HashMap fieldMap = new HashMap(13);
  static{
  fieldMap.put(SEQ,new Integer(1) );
  fieldMap.put(ITEM,new Integer(2) );
  fieldMap.put(LARCLAS,new Integer(3) );
  fieldMap.put(SMACLAS,new Integer(4) );
  fieldMap.put(CONT,new Integer(5) );
  fieldMap.put(WRT_ID,new Integer(6) );
  fieldMap.put(INS_DT,new Integer(7) );
  fieldMap.put(UPD_DT,new Integer(8) );
  fieldMap.put(MIDCLAS,new Integer(9) );
  fieldMap.put(BAS,new Integer(10) );
  fieldMap.put(CONT_YN,new Integer(11) );
  fieldMap.put(ORDER_SEQ,new Integer(12) );
  fieldMap.put(DETAIL_CONT,new Integer(13) );
  
  }

     final public static String PACKAGE = "sp.dao";
     final public static String TABLE = "PT_UB_DETAIL_MASTER";
     final public static String PREFIX = "sp.dao.PT_UB_DETAIL_MASTER";
     final public static String TABLE_DESC = "";
  
     final public static String PRIMARYKEY_LIST[] = { 
       SEQ };
     final public static String FIELD_LIST[] = { 
       SEQ,ITEM,LARCLAS,SMACLAS,CONT,WRT_ID,INS_DT,UPD_DT,MIDCLAS,BAS,CONT_YN,ORDER_SEQ,DETAIL_CONT };
     public static String getFieldDesc(String key){
         Integer idx = (Integer)fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 : 
	                  return  "";
             case 2 : 
	                  return  "";
             case 3 : 
	                  return  "";
             case 4 : 
	                  return  "";
             case 5 : 
	                  return  "";
             case 6 : 
	                  return  "";
             case 7 : 
	                  return  "";
             case 8 : 
	                  return  "";
             case 9 : 
	                  return  "";
             case 10 : 
	                  return  "";
             case 11 : 
	                  return  "";
             case 12 : 
	                  return  "";
             case 13 : 
	                  return  "";
	    }

         return null;
    }

   public static String toXML(PT_UB_DETAIL_MASTEREntity ent){

         StringBuffer xml = new StringBuffer(); 
         xml.append("<object type='object' name='").append(ent.getClass().getName()).append("' >\n");
        
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SEQ").append("'")
            .append(" value='").append(""+ent.getSEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ITEM").append("'")
            .append(" value='").append(""+ent.getITEM()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("LARCLAS").append("'")
            .append(" value='").append(""+ent.getLARCLAS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("SMACLAS").append("'")
            .append(" value='").append(""+ent.getSMACLAS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONT").append("'")
            .append(" value='").append(""+ent.getCONT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("WRT_ID").append("'")
            .append(" value='").append(""+ent.getWRT_ID()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("INS_DT").append("'")
            .append(" value='").append(""+ent.getINS_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("UPD_DT").append("'")
            .append(" value='").append(""+ent.getUPD_DT()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("MIDCLAS").append("'")
            .append(" value='").append(""+ent.getMIDCLAS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("BAS").append("'")
            .append(" value='").append(""+ent.getBAS()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("CONT_YN").append("'")
            .append(" value='").append(""+ent.getCONT_YN()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("ORDER_SEQ").append("'")
            .append(" value='").append(""+ent.getORDER_SEQ()).append("' />\n");
        
         xml.append("<field type='").append("String").append("' ")
            .append(" name='").append("DETAIL_CONT").append("'")
            .append(" value='").append(""+ent.getDETAIL_CONT()).append("' />\n");
        

         xml.append("</object>\n");
         
         return xml.toString();
  }

}
