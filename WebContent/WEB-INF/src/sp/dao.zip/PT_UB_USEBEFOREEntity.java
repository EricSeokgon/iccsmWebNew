

/*
*  Automatic generated  source
*  ��  ��  �� : ���� 
*
*  ���̺� ��   :PT_UB_USEBEFORE
*  ���̺� ���� :
*  ���̺� PK   :  
*               RECV_NUM  
*               SIDO_CODE  
*               SIGUNGU_CODE
*  ���̺� �÷� :  
*               SIDO_CODE:VARCHAR2(5):  
*               SIGUNGU_CODE:VARCHAR2(4):  
*               APPLPER_NM:VARCHAR2(50):  
*               APPLPER_REP:VARCHAR2(24):  
*               APPLPER_POSTNUM:VARCHAR2(16):  
*               APPLPER_ADDR:VARCHAR2(100):  
*               APPLPER_DETAILADDR:VARCHAR2(128):  
*               APPLPER_TELNUM:VARCHAR2(24):  
*               OPE_NAME:VARCHAR2(100):  
*               OPE_REP:VARCHAR2(24):  
*               OPE_TELNUM:VARCHAR2(24):  
*               COI_WRT_NUM:VARCHAR2(24):  
*               OPE_POSTNUM:VARCHAR2(16):  
*               OPE_ADDR:VARCHAR2(100):  
*               OPE_DETAILADDR:VARCHAR2(128):  
*               INSP_SPOT_NM:VARCHAR2(100):  
*               INSP_SPOT_POSTNUM:VARCHAR2(16):  
*               INSP_SPOT_ADDR:VARCHAR2(100):  
*               INSP_SPOT_DETAILADDR:VARCHAR2(128):  
*               PLANER_NM:VARCHAR2(26):  
*               WORK_ITEM:VARCHAR2(250):  
*               AREA:VARCHAR2(10):  
*               NUM_FL:VARCHAR2(200):  
*               USE:VARCHAR2(100):  
*               INSP_APPL_WORK:VARCHAR2(200):  
*               INSP_APPL_DT:VARCHAR2(24):  
*               INSP_DT:VARCHAR2(24):  
*               INSP_FEE:VARCHAR2(26):  
*               INSPER_NM:VARCHAR2(50):  
*               INSPER_POSI:VARCHAR2(50):  
*               JUDGM:VARCHAR2(255):  
*               PLAN_CONFIRM_YN:VARCHAR2(5):  
*               SW_BEF_REPO_DELINUM:VARCHAR2(50):  
*               SW_DT:VARCHAR2(24):  
*               EW_DT:VARCHAR2(24):  
*               INSP_WISH_YMD:VARCHAR2(24):  
*               OFFI_TELNUM:VARCHAR2(26):  
*               OFFI_NM:VARCHAR2(60):  
*               USEBEFINSP_DELINUM:VARCHAR2(50):  
*               SUV:VARCHAR2(100):  
*               REMARK:VARCHAR2(255):  
*               CER_DELI_YN:VARCHAR2(5):  
*               PLAN_CONFIRM_REMARK:VARCHAR2(255):  
*               NAPPL_YN:VARCHAR2(20):  
*               NAPPL_CAUSE:VARCHAR2(100):  
*               DOC_INSP_REMARK:VARCHAR2(255):  
*               WRT_ID:VARCHAR2(50):  
*               INS_DT:VARCHAR2(24):  
*               UPD_DT:VARCHAR2(24):  
*               CIV_RECV_NUM:VARCHAR2(100):  
*               RECV_DT:VARCHAR2(8):  
*               PLAN_CONFIRM_PER_YN:VARCHAR2(100):  
*               PLAN_ENT_CHG_YN:VARCHAR2(200):  
*               PLAN_CONT_CHG_YN:VARCHAR2(200):  
*               RECV_NUM:VARCHAR2(30):  
*               ATT_DOC:VARCHAR2(250):  
*               DELI_DT:VARCHAR2(24):  
*               DEFI_YN:VARCHAR2(4):  
*               PROC_STE:VARCHAR2(4):  
*               ISSUE_ITEM:VARCHAR2(4):  
*               NET_RECV_YN:VARCHAR2(4):  
*               PROC_LIM:VARCHAR2(24):  
*               INSP_NUM:VARCHAR2(20):  
*               PROC_OFFI:VARCHAR2(20):  
*               PLAN_CONFIRM_PER_YN_CONT:VARCHAR2(200):  
*               PLAN_ENT_CHG_YN_CONT:VARCHAR2(200):  
*               PLAN_CONT_CHG_YN_CONT:VARCHAR2(200):  
*               CHG_INSP:VARCHAR2(10):  
*               INSP_ITEM:VARCHAR2(5):  
*               ETC_INSP_BAS:VARCHAR2(200):  
*               WORK_ITEM_ETC:VARCHAR2(200):  
*               UPD_DT_OLD:VARCHAR2(24):  
*               BACKUP_TRANS_DT:VARCHAR2(24):  
*               TAKE_TM:VARCHAR2(24):  
*               USER_NAME:VARCHAR2(255):  
*               MW_PPS_GETR_ID:VARCHAR2(255):  
*               OUTVARS:VARCHAR2(255):  
*               MW_AFR_SHTNM:VARCHAR2(255):  
*               MW_SE:VARCHAR2(255):  
*               MW_CODE_CN:VARCHAR2(255):  
*               TAKE_CONFRM_CODE:VARCHAR2(255):  
*               DEAL_SE:VARCHAR2(255):  
*               DEAL_CODE_CN:VARCHAR2(255):  
*               TAKE_SE:VARCHAR2(255):  
*               TAKE_CODE_CN:VARCHAR2(255):  
*               REAL_DEAL_YMD:VARCHAR2(255):  
*               MW_TAKE_NO:VARCHAR2(30):  
*               ETC1:VARCHAR2(50):  
*               ETC2:VARCHAR2(50):  
*               ETC3:VARCHAR2(50):  
*               BEF_PLANER_NAME:VARCHAR2(50):  
*               PROC_OFFI_ID:VARCHAR2(20):  
*               ADMIT_DT:VARCHAR2(24):
*/
package sp.dao;

import kjf.ops.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import kjf.util.KJFMi;
import com.tobesoft.platform.data.Dataset;

public class PT_UB_USEBEFOREEntity extends ValueObject{

  
     private String SIDO_CODE;
  
     private String SIGUNGU_CODE;
  
     private String APPLPER_NM;
  
     private String APPLPER_REP;
  
     private String APPLPER_POSTNUM;
  
     private String APPLPER_ADDR;
  
     private String APPLPER_DETAILADDR;
  
     private String APPLPER_TELNUM;
  
     private String OPE_NAME;
  
     private String OPE_REP;
  
     private String OPE_TELNUM;
  
     private String COI_WRT_NUM;
  
     private String OPE_POSTNUM;
  
     private String OPE_ADDR;
  
     private String OPE_DETAILADDR;
  
     private String INSP_SPOT_NM;
  
     private String INSP_SPOT_POSTNUM;
  
     private String INSP_SPOT_ADDR;
  
     private String INSP_SPOT_DETAILADDR;
  
     private String PLANER_NM;
  
     private String WORK_ITEM;
  
     private String AREA;
  
     private String NUM_FL;
  
     private String USE;
  
     private String INSP_APPL_WORK;
  
     private String INSP_APPL_DT;
  
     private String INSP_DT;
  
     private String INSP_FEE;
  
     private String INSPER_NM;
  
     private String INSPER_POSI;
  
     private String JUDGM;
  
     private String PLAN_CONFIRM_YN;
  
     private String SW_BEF_REPO_DELINUM;
  
     private String SW_DT;
  
     private String EW_DT;
  
     private String INSP_WISH_YMD;
  
     private String OFFI_TELNUM;
  
     private String OFFI_NM;
  
     private String USEBEFINSP_DELINUM;
  
     private String SUV;
  
     private String REMARK;
  
     private String CER_DELI_YN;
  
     private String PLAN_CONFIRM_REMARK;
  
     private String NAPPL_YN;
  
     private String NAPPL_CAUSE;
  
     private String DOC_INSP_REMARK;
  
     private String WRT_ID;
  
     private String INS_DT;
  
     private String UPD_DT;
  
     private String CIV_RECV_NUM;
  
     private String RECV_DT;
  
     private String PLAN_CONFIRM_PER_YN;
  
     private String PLAN_ENT_CHG_YN;
  
     private String PLAN_CONT_CHG_YN;
  
     private String RECV_NUM;
  
     private String ATT_DOC;
  
     private String DELI_DT;
  
     private String DEFI_YN;
  
     private String PROC_STE;
  
     private String ISSUE_ITEM;
  
     private String NET_RECV_YN;
  
     private String PROC_LIM;
  
     private String INSP_NUM;
  
     private String PROC_OFFI;
  
     private String PLAN_CONFIRM_PER_YN_CONT;
  
     private String PLAN_ENT_CHG_YN_CONT;
  
     private String PLAN_CONT_CHG_YN_CONT;
  
     private String CHG_INSP;
  
     private String INSP_ITEM;
  
     private String ETC_INSP_BAS;
  
     private String WORK_ITEM_ETC;
  
     private String UPD_DT_OLD;
  
     private String BACKUP_TRANS_DT;
  
     private String TAKE_TM;
  
     private String USER_NAME;
  
     private String MW_PPS_GETR_ID;
  
     private String OUTVARS;
  
     private String MW_AFR_SHTNM;
  
     private String MW_SE;
  
     private String MW_CODE_CN;
  
     private String TAKE_CONFRM_CODE;
  
     private String DEAL_SE;
  
     private String DEAL_CODE_CN;
  
     private String TAKE_SE;
  
     private String TAKE_CODE_CN;
  
     private String REAL_DEAL_YMD;
  
     private String MW_TAKE_NO;
  
     private String ETC1;
  
     private String ETC2;
  
     private String ETC3;
  
     private String BEF_PLANER_NAME;
  
     private String PROC_OFFI_ID;
  
     private String ADMIT_DT;
  

//�����ڸ� �����
    public PT_UB_USEBEFOREEntity(){
    }
    
    
    public PT_UB_USEBEFOREEntity(String RECV_NUM,String SIDO_CODE,String SIGUNGU_CODE ){
       this.setRECV_NUM(RECV_NUM);
       this.setSIDO_CODE(SIDO_CODE);
       this.setSIGUNGU_CODE(SIGUNGU_CODE);
       
    }
      
    public PT_UB_USEBEFOREEntity(ValueObject ent) throws Exception{
       Object value = null; 
       
       value = ent.getByName("RECV_NUM");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("RECV_NUM",value);
       
       value = ent.getByName("SIDO_CODE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SIDO_CODE",value);
       
       value = ent.getByName("SIGUNGU_CODE");
       if(value == null) 
          throw new Exception("�������� PK���� : null");
       this.setByName("SIGUNGU_CODE",value);
       
    }
    
    public void setRequestOnlyString(HttpServletRequest request) throws Exception{
		this.SIDO_CODE =request.getParameter("SIDO_CODE");
		this.SIGUNGU_CODE =request.getParameter("SIGUNGU_CODE");
		this.APPLPER_NM =request.getParameter("APPLPER_NM");
		this.APPLPER_REP =request.getParameter("APPLPER_REP");
		this.APPLPER_POSTNUM =request.getParameter("APPLPER_POSTNUM");
		this.APPLPER_ADDR =request.getParameter("APPLPER_ADDR");
		this.APPLPER_DETAILADDR =request.getParameter("APPLPER_DETAILADDR");
		this.APPLPER_TELNUM =request.getParameter("APPLPER_TELNUM");
		this.OPE_NAME =request.getParameter("OPE_NAME");
		this.OPE_REP =request.getParameter("OPE_REP");
		this.OPE_TELNUM =request.getParameter("OPE_TELNUM");
		this.COI_WRT_NUM =request.getParameter("COI_WRT_NUM");
		this.OPE_POSTNUM =request.getParameter("OPE_POSTNUM");
		this.OPE_ADDR =request.getParameter("OPE_ADDR");
		this.OPE_DETAILADDR =request.getParameter("OPE_DETAILADDR");
		this.INSP_SPOT_NM =request.getParameter("INSP_SPOT_NM");
		this.INSP_SPOT_POSTNUM =request.getParameter("INSP_SPOT_POSTNUM");
		this.INSP_SPOT_ADDR =request.getParameter("INSP_SPOT_ADDR");
		this.INSP_SPOT_DETAILADDR =request.getParameter("INSP_SPOT_DETAILADDR");
		this.PLANER_NM =request.getParameter("PLANER_NM");
		this.WORK_ITEM =request.getParameter("WORK_ITEM");
		this.AREA =request.getParameter("AREA");
		this.NUM_FL =request.getParameter("NUM_FL");
		this.USE =request.getParameter("USE");
		this.INSP_APPL_WORK =request.getParameter("INSP_APPL_WORK");
		this.INSP_APPL_DT =request.getParameter("INSP_APPL_DT");
		this.INSP_DT =request.getParameter("INSP_DT");
		this.INSP_FEE =request.getParameter("INSP_FEE");
		this.INSPER_NM =request.getParameter("INSPER_NM");
		this.INSPER_POSI =request.getParameter("INSPER_POSI");
		this.JUDGM =request.getParameter("JUDGM");
		this.PLAN_CONFIRM_YN =request.getParameter("PLAN_CONFIRM_YN");
		this.SW_BEF_REPO_DELINUM =request.getParameter("SW_BEF_REPO_DELINUM");
		this.SW_DT =request.getParameter("SW_DT");
		this.EW_DT =request.getParameter("EW_DT");
		this.INSP_WISH_YMD =request.getParameter("INSP_WISH_YMD");
		this.OFFI_TELNUM =request.getParameter("OFFI_TELNUM");
		this.OFFI_NM =request.getParameter("OFFI_NM");
		this.USEBEFINSP_DELINUM =request.getParameter("USEBEFINSP_DELINUM");
		this.SUV =request.getParameter("SUV");
		this.REMARK =request.getParameter("REMARK");
		this.CER_DELI_YN =request.getParameter("CER_DELI_YN");
		this.PLAN_CONFIRM_REMARK =request.getParameter("PLAN_CONFIRM_REMARK");
		this.NAPPL_YN =request.getParameter("NAPPL_YN");
		this.NAPPL_CAUSE =request.getParameter("NAPPL_CAUSE");
		this.DOC_INSP_REMARK =request.getParameter("DOC_INSP_REMARK");
		this.WRT_ID =request.getParameter("WRT_ID");
		this.INS_DT =request.getParameter("INS_DT");
		this.UPD_DT =request.getParameter("UPD_DT");
		this.CIV_RECV_NUM =request.getParameter("CIV_RECV_NUM");
		this.RECV_DT =request.getParameter("RECV_DT");
		this.PLAN_CONFIRM_PER_YN =request.getParameter("PLAN_CONFIRM_PER_YN");
		this.PLAN_ENT_CHG_YN =request.getParameter("PLAN_ENT_CHG_YN");
		this.PLAN_CONT_CHG_YN =request.getParameter("PLAN_CONT_CHG_YN");
		this.RECV_NUM =request.getParameter("RECV_NUM");
		this.ATT_DOC =request.getParameter("ATT_DOC");
		this.DELI_DT =request.getParameter("DELI_DT");
		this.DEFI_YN =request.getParameter("DEFI_YN");
		this.PROC_STE =request.getParameter("PROC_STE");
		this.ISSUE_ITEM =request.getParameter("ISSUE_ITEM");
		this.NET_RECV_YN =request.getParameter("NET_RECV_YN");
		this.PROC_LIM =request.getParameter("PROC_LIM");
		this.INSP_NUM =request.getParameter("INSP_NUM");
		this.PROC_OFFI =request.getParameter("PROC_OFFI");
		this.PLAN_CONFIRM_PER_YN_CONT =request.getParameter("PLAN_CONFIRM_PER_YN_CONT");
		this.PLAN_ENT_CHG_YN_CONT =request.getParameter("PLAN_ENT_CHG_YN_CONT");
		this.PLAN_CONT_CHG_YN_CONT =request.getParameter("PLAN_CONT_CHG_YN_CONT");
		this.CHG_INSP =request.getParameter("CHG_INSP");
		this.INSP_ITEM =request.getParameter("INSP_ITEM");
		this.ETC_INSP_BAS =request.getParameter("ETC_INSP_BAS");
		this.WORK_ITEM_ETC =request.getParameter("WORK_ITEM_ETC");
		this.UPD_DT_OLD =request.getParameter("UPD_DT_OLD");
		this.BACKUP_TRANS_DT =request.getParameter("BACKUP_TRANS_DT");
		this.TAKE_TM =request.getParameter("TAKE_TM");
		this.USER_NAME =request.getParameter("USER_NAME");
		this.MW_PPS_GETR_ID =request.getParameter("MW_PPS_GETR_ID");
		this.OUTVARS =request.getParameter("OUTVARS");
		this.MW_AFR_SHTNM =request.getParameter("MW_AFR_SHTNM");
		this.MW_SE =request.getParameter("MW_SE");
		this.MW_CODE_CN =request.getParameter("MW_CODE_CN");
		this.TAKE_CONFRM_CODE =request.getParameter("TAKE_CONFRM_CODE");
		this.DEAL_SE =request.getParameter("DEAL_SE");
		this.DEAL_CODE_CN =request.getParameter("DEAL_CODE_CN");
		this.TAKE_SE =request.getParameter("TAKE_SE");
		this.TAKE_CODE_CN =request.getParameter("TAKE_CODE_CN");
		this.REAL_DEAL_YMD =request.getParameter("REAL_DEAL_YMD");
		this.MW_TAKE_NO =request.getParameter("MW_TAKE_NO");
		this.ETC1 =request.getParameter("ETC1");
		this.ETC2 =request.getParameter("ETC2");
		this.ETC3 =request.getParameter("ETC3");
		this.BEF_PLANER_NAME =request.getParameter("BEF_PLANER_NAME");
		this.PROC_OFFI_ID =request.getParameter("PROC_OFFI_ID");
		this.ADMIT_DT =request.getParameter("ADMIT_DT");
		
    }  
    
    public void setDsOnlyString(Dataset ds, int arg_row) throws Exception{  
		this.SIDO_CODE =KJFMi.dsGet(ds, arg_row, "SIDO_CODE");
		this.SIGUNGU_CODE =KJFMi.dsGet(ds, arg_row, "SIGUNGU_CODE");
		this.APPLPER_NM =KJFMi.dsGet(ds, arg_row, "APPLPER_NM");
		this.APPLPER_REP =KJFMi.dsGet(ds, arg_row, "APPLPER_REP");
		this.APPLPER_POSTNUM =KJFMi.dsGet(ds, arg_row, "APPLPER_POSTNUM");
		this.APPLPER_ADDR =KJFMi.dsGet(ds, arg_row, "APPLPER_ADDR");
		this.APPLPER_DETAILADDR =KJFMi.dsGet(ds, arg_row, "APPLPER_DETAILADDR");
		this.APPLPER_TELNUM =KJFMi.dsGet(ds, arg_row, "APPLPER_TELNUM");
		this.OPE_NAME =KJFMi.dsGet(ds, arg_row, "OPE_NAME");
		this.OPE_REP =KJFMi.dsGet(ds, arg_row, "OPE_REP");
		this.OPE_TELNUM =KJFMi.dsGet(ds, arg_row, "OPE_TELNUM");
		this.COI_WRT_NUM =KJFMi.dsGet(ds, arg_row, "COI_WRT_NUM");
		this.OPE_POSTNUM =KJFMi.dsGet(ds, arg_row, "OPE_POSTNUM");
		this.OPE_ADDR =KJFMi.dsGet(ds, arg_row, "OPE_ADDR");
		this.OPE_DETAILADDR =KJFMi.dsGet(ds, arg_row, "OPE_DETAILADDR");
		this.INSP_SPOT_NM =KJFMi.dsGet(ds, arg_row, "INSP_SPOT_NM");
		this.INSP_SPOT_POSTNUM =KJFMi.dsGet(ds, arg_row, "INSP_SPOT_POSTNUM");
		this.INSP_SPOT_ADDR =KJFMi.dsGet(ds, arg_row, "INSP_SPOT_ADDR");
		this.INSP_SPOT_DETAILADDR =KJFMi.dsGet(ds, arg_row, "INSP_SPOT_DETAILADDR");
		this.PLANER_NM =KJFMi.dsGet(ds, arg_row, "PLANER_NM");
		this.WORK_ITEM =KJFMi.dsGet(ds, arg_row, "WORK_ITEM");
		this.AREA =KJFMi.dsGet(ds, arg_row, "AREA");
		this.NUM_FL =KJFMi.dsGet(ds, arg_row, "NUM_FL");
		this.USE =KJFMi.dsGet(ds, arg_row, "USE");
		this.INSP_APPL_WORK =KJFMi.dsGet(ds, arg_row, "INSP_APPL_WORK");
		this.INSP_APPL_DT =KJFMi.dsGet(ds, arg_row, "INSP_APPL_DT");
		this.INSP_DT =KJFMi.dsGet(ds, arg_row, "INSP_DT");
		this.INSP_FEE =KJFMi.dsGet(ds, arg_row, "INSP_FEE");
		this.INSPER_NM =KJFMi.dsGet(ds, arg_row, "INSPER_NM");
		this.INSPER_POSI =KJFMi.dsGet(ds, arg_row, "INSPER_POSI");
		this.JUDGM =KJFMi.dsGet(ds, arg_row, "JUDGM");
		this.PLAN_CONFIRM_YN =KJFMi.dsGet(ds, arg_row, "PLAN_CONFIRM_YN");
		this.SW_BEF_REPO_DELINUM =KJFMi.dsGet(ds, arg_row, "SW_BEF_REPO_DELINUM");
		this.SW_DT =KJFMi.dsGet(ds, arg_row, "SW_DT");
		this.EW_DT =KJFMi.dsGet(ds, arg_row, "EW_DT");
		this.INSP_WISH_YMD =KJFMi.dsGet(ds, arg_row, "INSP_WISH_YMD");
		this.OFFI_TELNUM =KJFMi.dsGet(ds, arg_row, "OFFI_TELNUM");
		this.OFFI_NM =KJFMi.dsGet(ds, arg_row, "OFFI_NM");
		this.USEBEFINSP_DELINUM =KJFMi.dsGet(ds, arg_row, "USEBEFINSP_DELINUM");
		this.SUV =KJFMi.dsGet(ds, arg_row, "SUV");
		this.REMARK =KJFMi.dsGet(ds, arg_row, "REMARK");
		this.CER_DELI_YN =KJFMi.dsGet(ds, arg_row, "CER_DELI_YN");
		this.PLAN_CONFIRM_REMARK =KJFMi.dsGet(ds, arg_row, "PLAN_CONFIRM_REMARK");
		this.NAPPL_YN =KJFMi.dsGet(ds, arg_row, "NAPPL_YN");
		this.NAPPL_CAUSE =KJFMi.dsGet(ds, arg_row, "NAPPL_CAUSE");
		this.DOC_INSP_REMARK =KJFMi.dsGet(ds, arg_row, "DOC_INSP_REMARK");
		this.WRT_ID =KJFMi.dsGet(ds, arg_row, "WRT_ID");
		this.INS_DT =KJFMi.dsGet(ds, arg_row, "INS_DT");
		this.UPD_DT =KJFMi.dsGet(ds, arg_row, "UPD_DT");
		this.CIV_RECV_NUM =KJFMi.dsGet(ds, arg_row, "CIV_RECV_NUM");
		this.RECV_DT =KJFMi.dsGet(ds, arg_row, "RECV_DT");
		this.PLAN_CONFIRM_PER_YN =KJFMi.dsGet(ds, arg_row, "PLAN_CONFIRM_PER_YN");
		this.PLAN_ENT_CHG_YN =KJFMi.dsGet(ds, arg_row, "PLAN_ENT_CHG_YN");
		this.PLAN_CONT_CHG_YN =KJFMi.dsGet(ds, arg_row, "PLAN_CONT_CHG_YN");
		this.RECV_NUM =KJFMi.dsGet(ds, arg_row, "RECV_NUM");
		this.ATT_DOC =KJFMi.dsGet(ds, arg_row, "ATT_DOC");
		this.DELI_DT =KJFMi.dsGet(ds, arg_row, "DELI_DT");
		this.DEFI_YN =KJFMi.dsGet(ds, arg_row, "DEFI_YN");
		this.PROC_STE =KJFMi.dsGet(ds, arg_row, "PROC_STE");
		this.ISSUE_ITEM =KJFMi.dsGet(ds, arg_row, "ISSUE_ITEM");
		this.NET_RECV_YN =KJFMi.dsGet(ds, arg_row, "NET_RECV_YN");
		this.PROC_LIM =KJFMi.dsGet(ds, arg_row, "PROC_LIM");
		this.INSP_NUM =KJFMi.dsGet(ds, arg_row, "INSP_NUM");
		this.PROC_OFFI =KJFMi.dsGet(ds, arg_row, "PROC_OFFI");
		this.PLAN_CONFIRM_PER_YN_CONT =KJFMi.dsGet(ds, arg_row, "PLAN_CONFIRM_PER_YN_CONT");
		this.PLAN_ENT_CHG_YN_CONT =KJFMi.dsGet(ds, arg_row, "PLAN_ENT_CHG_YN_CONT");
		this.PLAN_CONT_CHG_YN_CONT =KJFMi.dsGet(ds, arg_row, "PLAN_CONT_CHG_YN_CONT");
		this.CHG_INSP =KJFMi.dsGet(ds, arg_row, "CHG_INSP");
		this.INSP_ITEM =KJFMi.dsGet(ds, arg_row, "INSP_ITEM");
		this.ETC_INSP_BAS =KJFMi.dsGet(ds, arg_row, "ETC_INSP_BAS");
		this.WORK_ITEM_ETC =KJFMi.dsGet(ds, arg_row, "WORK_ITEM_ETC");
		this.UPD_DT_OLD =KJFMi.dsGet(ds, arg_row, "UPD_DT_OLD");
		this.BACKUP_TRANS_DT =KJFMi.dsGet(ds, arg_row, "BACKUP_TRANS_DT");
		this.TAKE_TM =KJFMi.dsGet(ds, arg_row, "TAKE_TM");
		this.USER_NAME =KJFMi.dsGet(ds, arg_row, "USER_NAME");
		this.MW_PPS_GETR_ID =KJFMi.dsGet(ds, arg_row, "MW_PPS_GETR_ID");
		this.OUTVARS =KJFMi.dsGet(ds, arg_row, "OUTVARS");
		this.MW_AFR_SHTNM =KJFMi.dsGet(ds, arg_row, "MW_AFR_SHTNM");
		this.MW_SE =KJFMi.dsGet(ds, arg_row, "MW_SE");
		this.MW_CODE_CN =KJFMi.dsGet(ds, arg_row, "MW_CODE_CN");
		this.TAKE_CONFRM_CODE =KJFMi.dsGet(ds, arg_row, "TAKE_CONFRM_CODE");
		this.DEAL_SE =KJFMi.dsGet(ds, arg_row, "DEAL_SE");
		this.DEAL_CODE_CN =KJFMi.dsGet(ds, arg_row, "DEAL_CODE_CN");
		this.TAKE_SE =KJFMi.dsGet(ds, arg_row, "TAKE_SE");
		this.TAKE_CODE_CN =KJFMi.dsGet(ds, arg_row, "TAKE_CODE_CN");
		this.REAL_DEAL_YMD =KJFMi.dsGet(ds, arg_row, "REAL_DEAL_YMD");
		this.MW_TAKE_NO =KJFMi.dsGet(ds, arg_row, "MW_TAKE_NO");
		this.ETC1 =KJFMi.dsGet(ds, arg_row, "ETC1");
		this.ETC2 =KJFMi.dsGet(ds, arg_row, "ETC2");
		this.ETC3 =KJFMi.dsGet(ds, arg_row, "ETC3");
		this.BEF_PLANER_NAME =KJFMi.dsGet(ds, arg_row, "BEF_PLANER_NAME");
		this.PROC_OFFI_ID =KJFMi.dsGet(ds, arg_row, "PROC_OFFI_ID");
		this.ADMIT_DT =KJFMi.dsGet(ds, arg_row, "ADMIT_DT");
				
    }    
    
//Getter �Լ��� �����
  
     public String getSIDO_CODE(){
             return SIDO_CODE;
     };
  
     public String getSIGUNGU_CODE(){
             return SIGUNGU_CODE;
     };
  
     public String getAPPLPER_NM(){
             return APPLPER_NM;
     };
  
     public String getAPPLPER_REP(){
             return APPLPER_REP;
     };
  
     public String getAPPLPER_POSTNUM(){
             return APPLPER_POSTNUM;
     };
  
     public String getAPPLPER_ADDR(){
             return APPLPER_ADDR;
     };
  
     public String getAPPLPER_DETAILADDR(){
             return APPLPER_DETAILADDR;
     };
  
     public String getAPPLPER_TELNUM(){
             return APPLPER_TELNUM;
     };
  
     public String getOPE_NAME(){
             return OPE_NAME;
     };
  
     public String getOPE_REP(){
             return OPE_REP;
     };
  
     public String getOPE_TELNUM(){
             return OPE_TELNUM;
     };
  
     public String getCOI_WRT_NUM(){
             return COI_WRT_NUM;
     };
  
     public String getOPE_POSTNUM(){
             return OPE_POSTNUM;
     };
  
     public String getOPE_ADDR(){
             return OPE_ADDR;
     };
  
     public String getOPE_DETAILADDR(){
             return OPE_DETAILADDR;
     };
  
     public String getINSP_SPOT_NM(){
             return INSP_SPOT_NM;
     };
  
     public String getINSP_SPOT_POSTNUM(){
             return INSP_SPOT_POSTNUM;
     };
  
     public String getINSP_SPOT_ADDR(){
             return INSP_SPOT_ADDR;
     };
  
     public String getINSP_SPOT_DETAILADDR(){
             return INSP_SPOT_DETAILADDR;
     };
  
     public String getPLANER_NM(){
             return PLANER_NM;
     };
  
     public String getWORK_ITEM(){
             return WORK_ITEM;
     };
  
     public String getAREA(){
             return AREA;
     };
  
     public String getNUM_FL(){
             return NUM_FL;
     };
  
     public String getUSE(){
             return USE;
     };
  
     public String getINSP_APPL_WORK(){
             return INSP_APPL_WORK;
     };
  
     public String getINSP_APPL_DT(){
             return INSP_APPL_DT;
     };
  
     public String getINSP_DT(){
             return INSP_DT;
     };
  
     public String getINSP_FEE(){
             return INSP_FEE;
     };
  
     public String getINSPER_NM(){
             return INSPER_NM;
     };
  
     public String getINSPER_POSI(){
             return INSPER_POSI;
     };
  
     public String getJUDGM(){
             return JUDGM;
     };
  
     public String getPLAN_CONFIRM_YN(){
             return PLAN_CONFIRM_YN;
     };
  
     public String getSW_BEF_REPO_DELINUM(){
             return SW_BEF_REPO_DELINUM;
     };
  
     public String getSW_DT(){
             return SW_DT;
     };
  
     public String getEW_DT(){
             return EW_DT;
     };
  
     public String getINSP_WISH_YMD(){
             return INSP_WISH_YMD;
     };
  
     public String getOFFI_TELNUM(){
             return OFFI_TELNUM;
     };
  
     public String getOFFI_NM(){
             return OFFI_NM;
     };
  
     public String getUSEBEFINSP_DELINUM(){
             return USEBEFINSP_DELINUM;
     };
  
     public String getSUV(){
             return SUV;
     };
  
     public String getREMARK(){
             return REMARK;
     };
  
     public String getCER_DELI_YN(){
             return CER_DELI_YN;
     };
  
     public String getPLAN_CONFIRM_REMARK(){
             return PLAN_CONFIRM_REMARK;
     };
  
     public String getNAPPL_YN(){
             return NAPPL_YN;
     };
  
     public String getNAPPL_CAUSE(){
             return NAPPL_CAUSE;
     };
  
     public String getDOC_INSP_REMARK(){
             return DOC_INSP_REMARK;
     };
  
     public String getWRT_ID(){
             return WRT_ID;
     };
  
     public String getINS_DT(){
             return INS_DT;
     };
  
     public String getUPD_DT(){
             return UPD_DT;
     };
  
     public String getCIV_RECV_NUM(){
             return CIV_RECV_NUM;
     };
  
     public String getRECV_DT(){
             return RECV_DT;
     };
  
     public String getPLAN_CONFIRM_PER_YN(){
             return PLAN_CONFIRM_PER_YN;
     };
  
     public String getPLAN_ENT_CHG_YN(){
             return PLAN_ENT_CHG_YN;
     };
  
     public String getPLAN_CONT_CHG_YN(){
             return PLAN_CONT_CHG_YN;
     };
  
     public String getRECV_NUM(){
             return RECV_NUM;
     };
  
     public String getATT_DOC(){
             return ATT_DOC;
     };
  
     public String getDELI_DT(){
             return DELI_DT;
     };
  
     public String getDEFI_YN(){
             return DEFI_YN;
     };
  
     public String getPROC_STE(){
             return PROC_STE;
     };
  
     public String getISSUE_ITEM(){
             return ISSUE_ITEM;
     };
  
     public String getNET_RECV_YN(){
             return NET_RECV_YN;
     };
  
     public String getPROC_LIM(){
             return PROC_LIM;
     };
  
     public String getINSP_NUM(){
             return INSP_NUM;
     };
  
     public String getPROC_OFFI(){
             return PROC_OFFI;
     };
  
     public String getPLAN_CONFIRM_PER_YN_CONT(){
             return PLAN_CONFIRM_PER_YN_CONT;
     };
  
     public String getPLAN_ENT_CHG_YN_CONT(){
             return PLAN_ENT_CHG_YN_CONT;
     };
  
     public String getPLAN_CONT_CHG_YN_CONT(){
             return PLAN_CONT_CHG_YN_CONT;
     };
  
     public String getCHG_INSP(){
             return CHG_INSP;
     };
  
     public String getINSP_ITEM(){
             return INSP_ITEM;
     };
  
     public String getETC_INSP_BAS(){
             return ETC_INSP_BAS;
     };
  
     public String getWORK_ITEM_ETC(){
             return WORK_ITEM_ETC;
     };
  
     public String getUPD_DT_OLD(){
             return UPD_DT_OLD;
     };
  
     public String getBACKUP_TRANS_DT(){
             return BACKUP_TRANS_DT;
     };
  
     public String getTAKE_TM(){
             return TAKE_TM;
     };
  
     public String getUSER_NAME(){
             return USER_NAME;
     };
  
     public String getMW_PPS_GETR_ID(){
             return MW_PPS_GETR_ID;
     };
  
     public String getOUTVARS(){
             return OUTVARS;
     };
  
     public String getMW_AFR_SHTNM(){
             return MW_AFR_SHTNM;
     };
  
     public String getMW_SE(){
             return MW_SE;
     };
  
     public String getMW_CODE_CN(){
             return MW_CODE_CN;
     };
  
     public String getTAKE_CONFRM_CODE(){
             return TAKE_CONFRM_CODE;
     };
  
     public String getDEAL_SE(){
             return DEAL_SE;
     };
  
     public String getDEAL_CODE_CN(){
             return DEAL_CODE_CN;
     };
  
     public String getTAKE_SE(){
             return TAKE_SE;
     };
  
     public String getTAKE_CODE_CN(){
             return TAKE_CODE_CN;
     };
  
     public String getREAL_DEAL_YMD(){
             return REAL_DEAL_YMD;
     };
  
     public String getMW_TAKE_NO(){
             return MW_TAKE_NO;
     };
  
     public String getETC1(){
             return ETC1;
     };
  
     public String getETC2(){
             return ETC2;
     };
  
     public String getETC3(){
             return ETC3;
     };
  
     public String getBEF_PLANER_NAME(){
             return BEF_PLANER_NAME;
     };
  
     public String getPROC_OFFI_ID(){
             return PROC_OFFI_ID;
     };
  
     public String getADMIT_DT(){
             return ADMIT_DT;
     };
  

//Setter �Լ��� �����
  
     public void setSIDO_CODE(String SIDO_CODE){
            this.SIDO_CODE=SIDO_CODE;
     };
  
     public void setSIGUNGU_CODE(String SIGUNGU_CODE){
            this.SIGUNGU_CODE=SIGUNGU_CODE;
     };
  
     public void setAPPLPER_NM(String APPLPER_NM){
            this.APPLPER_NM=APPLPER_NM;
     };
  
     public void setAPPLPER_REP(String APPLPER_REP){
            this.APPLPER_REP=APPLPER_REP;
     };
  
     public void setAPPLPER_POSTNUM(String APPLPER_POSTNUM){
            this.APPLPER_POSTNUM=APPLPER_POSTNUM;
     };
  
     public void setAPPLPER_ADDR(String APPLPER_ADDR){
            this.APPLPER_ADDR=APPLPER_ADDR;
     };
  
     public void setAPPLPER_DETAILADDR(String APPLPER_DETAILADDR){
            this.APPLPER_DETAILADDR=APPLPER_DETAILADDR;
     };
  
     public void setAPPLPER_TELNUM(String APPLPER_TELNUM){
            this.APPLPER_TELNUM=APPLPER_TELNUM;
     };
  
     public void setOPE_NAME(String OPE_NAME){
            this.OPE_NAME=OPE_NAME;
     };
  
     public void setOPE_REP(String OPE_REP){
            this.OPE_REP=OPE_REP;
     };
  
     public void setOPE_TELNUM(String OPE_TELNUM){
            this.OPE_TELNUM=OPE_TELNUM;
     };
  
     public void setCOI_WRT_NUM(String COI_WRT_NUM){
            this.COI_WRT_NUM=COI_WRT_NUM;
     };
  
     public void setOPE_POSTNUM(String OPE_POSTNUM){
            this.OPE_POSTNUM=OPE_POSTNUM;
     };
  
     public void setOPE_ADDR(String OPE_ADDR){
            this.OPE_ADDR=OPE_ADDR;
     };
  
     public void setOPE_DETAILADDR(String OPE_DETAILADDR){
            this.OPE_DETAILADDR=OPE_DETAILADDR;
     };
  
     public void setINSP_SPOT_NM(String INSP_SPOT_NM){
            this.INSP_SPOT_NM=INSP_SPOT_NM;
     };
  
     public void setINSP_SPOT_POSTNUM(String INSP_SPOT_POSTNUM){
            this.INSP_SPOT_POSTNUM=INSP_SPOT_POSTNUM;
     };
  
     public void setINSP_SPOT_ADDR(String INSP_SPOT_ADDR){
            this.INSP_SPOT_ADDR=INSP_SPOT_ADDR;
     };
  
     public void setINSP_SPOT_DETAILADDR(String INSP_SPOT_DETAILADDR){
            this.INSP_SPOT_DETAILADDR=INSP_SPOT_DETAILADDR;
     };
  
     public void setPLANER_NM(String PLANER_NM){
            this.PLANER_NM=PLANER_NM;
     };
  
     public void setWORK_ITEM(String WORK_ITEM){
            this.WORK_ITEM=WORK_ITEM;
     };
  
     public void setAREA(String AREA){
            this.AREA=AREA;
     };
  
     public void setNUM_FL(String NUM_FL){
            this.NUM_FL=NUM_FL;
     };
  
     public void setUSE(String USE){
            this.USE=USE;
     };
  
     public void setINSP_APPL_WORK(String INSP_APPL_WORK){
            this.INSP_APPL_WORK=INSP_APPL_WORK;
     };
  
     public void setINSP_APPL_DT(String INSP_APPL_DT){
            this.INSP_APPL_DT=INSP_APPL_DT;
     };
  
     public void setINSP_DT(String INSP_DT){
            this.INSP_DT=INSP_DT;
     };
  
     public void setINSP_FEE(String INSP_FEE){
            this.INSP_FEE=INSP_FEE;
     };
  
     public void setINSPER_NM(String INSPER_NM){
            this.INSPER_NM=INSPER_NM;
     };
  
     public void setINSPER_POSI(String INSPER_POSI){
            this.INSPER_POSI=INSPER_POSI;
     };
  
     public void setJUDGM(String JUDGM){
            this.JUDGM=JUDGM;
     };
  
     public void setPLAN_CONFIRM_YN(String PLAN_CONFIRM_YN){
            this.PLAN_CONFIRM_YN=PLAN_CONFIRM_YN;
     };
  
     public void setSW_BEF_REPO_DELINUM(String SW_BEF_REPO_DELINUM){
            this.SW_BEF_REPO_DELINUM=SW_BEF_REPO_DELINUM;
     };
  
     public void setSW_DT(String SW_DT){
            this.SW_DT=SW_DT;
     };
  
     public void setEW_DT(String EW_DT){
            this.EW_DT=EW_DT;
     };
  
     public void setINSP_WISH_YMD(String INSP_WISH_YMD){
            this.INSP_WISH_YMD=INSP_WISH_YMD;
     };
  
     public void setOFFI_TELNUM(String OFFI_TELNUM){
            this.OFFI_TELNUM=OFFI_TELNUM;
     };
  
     public void setOFFI_NM(String OFFI_NM){
            this.OFFI_NM=OFFI_NM;
     };
  
     public void setUSEBEFINSP_DELINUM(String USEBEFINSP_DELINUM){
            this.USEBEFINSP_DELINUM=USEBEFINSP_DELINUM;
     };
  
     public void setSUV(String SUV){
            this.SUV=SUV;
     };
  
     public void setREMARK(String REMARK){
            this.REMARK=REMARK;
     };
  
     public void setCER_DELI_YN(String CER_DELI_YN){
            this.CER_DELI_YN=CER_DELI_YN;
     };
  
     public void setPLAN_CONFIRM_REMARK(String PLAN_CONFIRM_REMARK){
            this.PLAN_CONFIRM_REMARK=PLAN_CONFIRM_REMARK;
     };
  
     public void setNAPPL_YN(String NAPPL_YN){
            this.NAPPL_YN=NAPPL_YN;
     };
  
     public void setNAPPL_CAUSE(String NAPPL_CAUSE){
            this.NAPPL_CAUSE=NAPPL_CAUSE;
     };
  
     public void setDOC_INSP_REMARK(String DOC_INSP_REMARK){
            this.DOC_INSP_REMARK=DOC_INSP_REMARK;
     };
  
     public void setWRT_ID(String WRT_ID){
            this.WRT_ID=WRT_ID;
     };
  
     public void setINS_DT(String INS_DT){
            this.INS_DT=INS_DT;
     };
  
     public void setUPD_DT(String UPD_DT){
            this.UPD_DT=UPD_DT;
     };
  
     public void setCIV_RECV_NUM(String CIV_RECV_NUM){
            this.CIV_RECV_NUM=CIV_RECV_NUM;
     };
  
     public void setRECV_DT(String RECV_DT){
            this.RECV_DT=RECV_DT;
     };
  
     public void setPLAN_CONFIRM_PER_YN(String PLAN_CONFIRM_PER_YN){
            this.PLAN_CONFIRM_PER_YN=PLAN_CONFIRM_PER_YN;
     };
  
     public void setPLAN_ENT_CHG_YN(String PLAN_ENT_CHG_YN){
            this.PLAN_ENT_CHG_YN=PLAN_ENT_CHG_YN;
     };
  
     public void setPLAN_CONT_CHG_YN(String PLAN_CONT_CHG_YN){
            this.PLAN_CONT_CHG_YN=PLAN_CONT_CHG_YN;
     };
  
     public void setRECV_NUM(String RECV_NUM){
            this.RECV_NUM=RECV_NUM;
     };
  
     public void setATT_DOC(String ATT_DOC){
            this.ATT_DOC=ATT_DOC;
     };
  
     public void setDELI_DT(String DELI_DT){
            this.DELI_DT=DELI_DT;
     };
  
     public void setDEFI_YN(String DEFI_YN){
            this.DEFI_YN=DEFI_YN;
     };
  
     public void setPROC_STE(String PROC_STE){
            this.PROC_STE=PROC_STE;
     };
  
     public void setISSUE_ITEM(String ISSUE_ITEM){
            this.ISSUE_ITEM=ISSUE_ITEM;
     };
  
     public void setNET_RECV_YN(String NET_RECV_YN){
            this.NET_RECV_YN=NET_RECV_YN;
     };
  
     public void setPROC_LIM(String PROC_LIM){
            this.PROC_LIM=PROC_LIM;
     };
  
     public void setINSP_NUM(String INSP_NUM){
            this.INSP_NUM=INSP_NUM;
     };
  
     public void setPROC_OFFI(String PROC_OFFI){
            this.PROC_OFFI=PROC_OFFI;
     };
  
     public void setPLAN_CONFIRM_PER_YN_CONT(String PLAN_CONFIRM_PER_YN_CONT){
            this.PLAN_CONFIRM_PER_YN_CONT=PLAN_CONFIRM_PER_YN_CONT;
     };
  
     public void setPLAN_ENT_CHG_YN_CONT(String PLAN_ENT_CHG_YN_CONT){
            this.PLAN_ENT_CHG_YN_CONT=PLAN_ENT_CHG_YN_CONT;
     };
  
     public void setPLAN_CONT_CHG_YN_CONT(String PLAN_CONT_CHG_YN_CONT){
            this.PLAN_CONT_CHG_YN_CONT=PLAN_CONT_CHG_YN_CONT;
     };
  
     public void setCHG_INSP(String CHG_INSP){
            this.CHG_INSP=CHG_INSP;
     };
  
     public void setINSP_ITEM(String INSP_ITEM){
            this.INSP_ITEM=INSP_ITEM;
     };
  
     public void setETC_INSP_BAS(String ETC_INSP_BAS){
            this.ETC_INSP_BAS=ETC_INSP_BAS;
     };
  
     public void setWORK_ITEM_ETC(String WORK_ITEM_ETC){
            this.WORK_ITEM_ETC=WORK_ITEM_ETC;
     };
  
     public void setUPD_DT_OLD(String UPD_DT_OLD){
            this.UPD_DT_OLD=UPD_DT_OLD;
     };
  
     public void setBACKUP_TRANS_DT(String BACKUP_TRANS_DT){
            this.BACKUP_TRANS_DT=BACKUP_TRANS_DT;
     };
  
     public void setTAKE_TM(String TAKE_TM){
            this.TAKE_TM=TAKE_TM;
     };
  
     public void setUSER_NAME(String USER_NAME){
            this.USER_NAME=USER_NAME;
     };
  
     public void setMW_PPS_GETR_ID(String MW_PPS_GETR_ID){
            this.MW_PPS_GETR_ID=MW_PPS_GETR_ID;
     };
  
     public void setOUTVARS(String OUTVARS){
            this.OUTVARS=OUTVARS;
     };
  
     public void setMW_AFR_SHTNM(String MW_AFR_SHTNM){
            this.MW_AFR_SHTNM=MW_AFR_SHTNM;
     };
  
     public void setMW_SE(String MW_SE){
            this.MW_SE=MW_SE;
     };
  
     public void setMW_CODE_CN(String MW_CODE_CN){
            this.MW_CODE_CN=MW_CODE_CN;
     };
  
     public void setTAKE_CONFRM_CODE(String TAKE_CONFRM_CODE){
            this.TAKE_CONFRM_CODE=TAKE_CONFRM_CODE;
     };
  
     public void setDEAL_SE(String DEAL_SE){
            this.DEAL_SE=DEAL_SE;
     };
  
     public void setDEAL_CODE_CN(String DEAL_CODE_CN){
            this.DEAL_CODE_CN=DEAL_CODE_CN;
     };
  
     public void setTAKE_SE(String TAKE_SE){
            this.TAKE_SE=TAKE_SE;
     };
  
     public void setTAKE_CODE_CN(String TAKE_CODE_CN){
            this.TAKE_CODE_CN=TAKE_CODE_CN;
     };
  
     public void setREAL_DEAL_YMD(String REAL_DEAL_YMD){
            this.REAL_DEAL_YMD=REAL_DEAL_YMD;
     };
  
     public void setMW_TAKE_NO(String MW_TAKE_NO){
            this.MW_TAKE_NO=MW_TAKE_NO;
     };
  
     public void setETC1(String ETC1){
            this.ETC1=ETC1;
     };
  
     public void setETC2(String ETC2){
            this.ETC2=ETC2;
     };
  
     public void setETC3(String ETC3){
            this.ETC3=ETC3;
     };
  
     public void setBEF_PLANER_NAME(String BEF_PLANER_NAME){
            this.BEF_PLANER_NAME=BEF_PLANER_NAME;
     };
  
     public void setPROC_OFFI_ID(String PROC_OFFI_ID){
            this.PROC_OFFI_ID=PROC_OFFI_ID;
     };
  
     public void setADMIT_DT(String ADMIT_DT){
            this.ADMIT_DT=ADMIT_DT;
     };
  
  

  public String toString(){
      StringBuffer strB = new StringBuffer();
      
      strB.append("SIDO_CODE:"+ this.getSIDO_CODE()+"\n");
      
      strB.append("SIGUNGU_CODE:"+ this.getSIGUNGU_CODE()+"\n");
      
      strB.append("APPLPER_NM:"+ this.getAPPLPER_NM()+"\n");
      
      strB.append("APPLPER_REP:"+ this.getAPPLPER_REP()+"\n");
      
      strB.append("APPLPER_POSTNUM:"+ this.getAPPLPER_POSTNUM()+"\n");
      
      strB.append("APPLPER_ADDR:"+ this.getAPPLPER_ADDR()+"\n");
      
      strB.append("APPLPER_DETAILADDR:"+ this.getAPPLPER_DETAILADDR()+"\n");
      
      strB.append("APPLPER_TELNUM:"+ this.getAPPLPER_TELNUM()+"\n");
      
      strB.append("OPE_NAME:"+ this.getOPE_NAME()+"\n");
      
      strB.append("OPE_REP:"+ this.getOPE_REP()+"\n");
      
      strB.append("OPE_TELNUM:"+ this.getOPE_TELNUM()+"\n");
      
      strB.append("COI_WRT_NUM:"+ this.getCOI_WRT_NUM()+"\n");
      
      strB.append("OPE_POSTNUM:"+ this.getOPE_POSTNUM()+"\n");
      
      strB.append("OPE_ADDR:"+ this.getOPE_ADDR()+"\n");
      
      strB.append("OPE_DETAILADDR:"+ this.getOPE_DETAILADDR()+"\n");
      
      strB.append("INSP_SPOT_NM:"+ this.getINSP_SPOT_NM()+"\n");
      
      strB.append("INSP_SPOT_POSTNUM:"+ this.getINSP_SPOT_POSTNUM()+"\n");
      
      strB.append("INSP_SPOT_ADDR:"+ this.getINSP_SPOT_ADDR()+"\n");
      
      strB.append("INSP_SPOT_DETAILADDR:"+ this.getINSP_SPOT_DETAILADDR()+"\n");
      
      strB.append("PLANER_NM:"+ this.getPLANER_NM()+"\n");
      
      strB.append("WORK_ITEM:"+ this.getWORK_ITEM()+"\n");
      
      strB.append("AREA:"+ this.getAREA()+"\n");
      
      strB.append("NUM_FL:"+ this.getNUM_FL()+"\n");
      
      strB.append("USE:"+ this.getUSE()+"\n");
      
      strB.append("INSP_APPL_WORK:"+ this.getINSP_APPL_WORK()+"\n");
      
      strB.append("INSP_APPL_DT:"+ this.getINSP_APPL_DT()+"\n");
      
      strB.append("INSP_DT:"+ this.getINSP_DT()+"\n");
      
      strB.append("INSP_FEE:"+ this.getINSP_FEE()+"\n");
      
      strB.append("INSPER_NM:"+ this.getINSPER_NM()+"\n");
      
      strB.append("INSPER_POSI:"+ this.getINSPER_POSI()+"\n");
      
      strB.append("JUDGM:"+ this.getJUDGM()+"\n");
      
      strB.append("PLAN_CONFIRM_YN:"+ this.getPLAN_CONFIRM_YN()+"\n");
      
      strB.append("SW_BEF_REPO_DELINUM:"+ this.getSW_BEF_REPO_DELINUM()+"\n");
      
      strB.append("SW_DT:"+ this.getSW_DT()+"\n");
      
      strB.append("EW_DT:"+ this.getEW_DT()+"\n");
      
      strB.append("INSP_WISH_YMD:"+ this.getINSP_WISH_YMD()+"\n");
      
      strB.append("OFFI_TELNUM:"+ this.getOFFI_TELNUM()+"\n");
      
      strB.append("OFFI_NM:"+ this.getOFFI_NM()+"\n");
      
      strB.append("USEBEFINSP_DELINUM:"+ this.getUSEBEFINSP_DELINUM()+"\n");
      
      strB.append("SUV:"+ this.getSUV()+"\n");
      
      strB.append("REMARK:"+ this.getREMARK()+"\n");
      
      strB.append("CER_DELI_YN:"+ this.getCER_DELI_YN()+"\n");
      
      strB.append("PLAN_CONFIRM_REMARK:"+ this.getPLAN_CONFIRM_REMARK()+"\n");
      
      strB.append("NAPPL_YN:"+ this.getNAPPL_YN()+"\n");
      
      strB.append("NAPPL_CAUSE:"+ this.getNAPPL_CAUSE()+"\n");
      
      strB.append("DOC_INSP_REMARK:"+ this.getDOC_INSP_REMARK()+"\n");
      
      strB.append("WRT_ID:"+ this.getWRT_ID()+"\n");
      
      strB.append("INS_DT:"+ this.getINS_DT()+"\n");
      
      strB.append("UPD_DT:"+ this.getUPD_DT()+"\n");
      
      strB.append("CIV_RECV_NUM:"+ this.getCIV_RECV_NUM()+"\n");
      
      strB.append("RECV_DT:"+ this.getRECV_DT()+"\n");
      
      strB.append("PLAN_CONFIRM_PER_YN:"+ this.getPLAN_CONFIRM_PER_YN()+"\n");
      
      strB.append("PLAN_ENT_CHG_YN:"+ this.getPLAN_ENT_CHG_YN()+"\n");
      
      strB.append("PLAN_CONT_CHG_YN:"+ this.getPLAN_CONT_CHG_YN()+"\n");
      
      strB.append("RECV_NUM:"+ this.getRECV_NUM()+"\n");
      
      strB.append("ATT_DOC:"+ this.getATT_DOC()+"\n");
      
      strB.append("DELI_DT:"+ this.getDELI_DT()+"\n");
      
      strB.append("DEFI_YN:"+ this.getDEFI_YN()+"\n");
      
      strB.append("PROC_STE:"+ this.getPROC_STE()+"\n");
      
      strB.append("ISSUE_ITEM:"+ this.getISSUE_ITEM()+"\n");
      
      strB.append("NET_RECV_YN:"+ this.getNET_RECV_YN()+"\n");
      
      strB.append("PROC_LIM:"+ this.getPROC_LIM()+"\n");
      
      strB.append("INSP_NUM:"+ this.getINSP_NUM()+"\n");
      
      strB.append("PROC_OFFI:"+ this.getPROC_OFFI()+"\n");
      
      strB.append("PLAN_CONFIRM_PER_YN_CONT:"+ this.getPLAN_CONFIRM_PER_YN_CONT()+"\n");
      
      strB.append("PLAN_ENT_CHG_YN_CONT:"+ this.getPLAN_ENT_CHG_YN_CONT()+"\n");
      
      strB.append("PLAN_CONT_CHG_YN_CONT:"+ this.getPLAN_CONT_CHG_YN_CONT()+"\n");
      
      strB.append("CHG_INSP:"+ this.getCHG_INSP()+"\n");
      
      strB.append("INSP_ITEM:"+ this.getINSP_ITEM()+"\n");
      
      strB.append("ETC_INSP_BAS:"+ this.getETC_INSP_BAS()+"\n");
      
      strB.append("WORK_ITEM_ETC:"+ this.getWORK_ITEM_ETC()+"\n");
      
      strB.append("UPD_DT_OLD:"+ this.getUPD_DT_OLD()+"\n");
      
      strB.append("BACKUP_TRANS_DT:"+ this.getBACKUP_TRANS_DT()+"\n");
      
      strB.append("TAKE_TM:"+ this.getTAKE_TM()+"\n");
      
      strB.append("USER_NAME:"+ this.getUSER_NAME()+"\n");
      
      strB.append("MW_PPS_GETR_ID:"+ this.getMW_PPS_GETR_ID()+"\n");
      
      strB.append("OUTVARS:"+ this.getOUTVARS()+"\n");
      
      strB.append("MW_AFR_SHTNM:"+ this.getMW_AFR_SHTNM()+"\n");
      
      strB.append("MW_SE:"+ this.getMW_SE()+"\n");
      
      strB.append("MW_CODE_CN:"+ this.getMW_CODE_CN()+"\n");
      
      strB.append("TAKE_CONFRM_CODE:"+ this.getTAKE_CONFRM_CODE()+"\n");
      
      strB.append("DEAL_SE:"+ this.getDEAL_SE()+"\n");
      
      strB.append("DEAL_CODE_CN:"+ this.getDEAL_CODE_CN()+"\n");
      
      strB.append("TAKE_SE:"+ this.getTAKE_SE()+"\n");
      
      strB.append("TAKE_CODE_CN:"+ this.getTAKE_CODE_CN()+"\n");
      
      strB.append("REAL_DEAL_YMD:"+ this.getREAL_DEAL_YMD()+"\n");
      
      strB.append("MW_TAKE_NO:"+ this.getMW_TAKE_NO()+"\n");
      
      strB.append("ETC1:"+ this.getETC1()+"\n");
      
      strB.append("ETC2:"+ this.getETC2()+"\n");
      
      strB.append("ETC3:"+ this.getETC3()+"\n");
      
      strB.append("BEF_PLANER_NAME:"+ this.getBEF_PLANER_NAME()+"\n");
      
      strB.append("PROC_OFFI_ID:"+ this.getPROC_OFFI_ID()+"\n");
      
      strB.append("ADMIT_DT:"+ this.getADMIT_DT()+"\n");
      
      return strB.toString();      
  }
  
  //For ValueObject
  public String getPrefix(){
    return PT_UB_USEBEFOREHelper.PREFIX;
  }
  
  public String[] getPrimaryKeyList(){
       return PT_UB_USEBEFOREHelper.PRIMARYKEY_LIST;
      }
  public String[] getFieldList(){
       return PT_UB_USEBEFOREHelper.FIELD_LIST;
      }
  public Set getFieldSet(){
       return PT_UB_USEBEFOREHelper.fieldMap.keySet();
      }
  public boolean isField(String key){
     return PT_UB_USEBEFOREHelper.fieldMap.containsKey(key);
  };      

  public Object[] getPrimaryKeyValues(){
       Object values[] = new Object[3];
       values[0]= this.getRECV_NUM();
       values[1]= this.getSIDO_CODE();
       values[2]= this.getSIGUNGU_CODE();
       
       return values;
      }
  public ValueObject getTemp(){
          return new PT_UB_USEBEFOREEntity();
  }

  public ValueObject getClone(){
         PT_UB_USEBEFOREEntity newEnt = new PT_UB_USEBEFOREEntity();
	 
          newEnt.setSIDO_CODE(this.getSIDO_CODE());
         
          newEnt.setSIGUNGU_CODE(this.getSIGUNGU_CODE());
         
          newEnt.setAPPLPER_NM(this.getAPPLPER_NM());
         
          newEnt.setAPPLPER_REP(this.getAPPLPER_REP());
         
          newEnt.setAPPLPER_POSTNUM(this.getAPPLPER_POSTNUM());
         
          newEnt.setAPPLPER_ADDR(this.getAPPLPER_ADDR());
         
          newEnt.setAPPLPER_DETAILADDR(this.getAPPLPER_DETAILADDR());
         
          newEnt.setAPPLPER_TELNUM(this.getAPPLPER_TELNUM());
         
          newEnt.setOPE_NAME(this.getOPE_NAME());
         
          newEnt.setOPE_REP(this.getOPE_REP());
         
          newEnt.setOPE_TELNUM(this.getOPE_TELNUM());
         
          newEnt.setCOI_WRT_NUM(this.getCOI_WRT_NUM());
         
          newEnt.setOPE_POSTNUM(this.getOPE_POSTNUM());
         
          newEnt.setOPE_ADDR(this.getOPE_ADDR());
         
          newEnt.setOPE_DETAILADDR(this.getOPE_DETAILADDR());
         
          newEnt.setINSP_SPOT_NM(this.getINSP_SPOT_NM());
         
          newEnt.setINSP_SPOT_POSTNUM(this.getINSP_SPOT_POSTNUM());
         
          newEnt.setINSP_SPOT_ADDR(this.getINSP_SPOT_ADDR());
         
          newEnt.setINSP_SPOT_DETAILADDR(this.getINSP_SPOT_DETAILADDR());
         
          newEnt.setPLANER_NM(this.getPLANER_NM());
         
          newEnt.setWORK_ITEM(this.getWORK_ITEM());
         
          newEnt.setAREA(this.getAREA());
         
          newEnt.setNUM_FL(this.getNUM_FL());
         
          newEnt.setUSE(this.getUSE());
         
          newEnt.setINSP_APPL_WORK(this.getINSP_APPL_WORK());
         
          newEnt.setINSP_APPL_DT(this.getINSP_APPL_DT());
         
          newEnt.setINSP_DT(this.getINSP_DT());
         
          newEnt.setINSP_FEE(this.getINSP_FEE());
         
          newEnt.setINSPER_NM(this.getINSPER_NM());
         
          newEnt.setINSPER_POSI(this.getINSPER_POSI());
         
          newEnt.setJUDGM(this.getJUDGM());
         
          newEnt.setPLAN_CONFIRM_YN(this.getPLAN_CONFIRM_YN());
         
          newEnt.setSW_BEF_REPO_DELINUM(this.getSW_BEF_REPO_DELINUM());
         
          newEnt.setSW_DT(this.getSW_DT());
         
          newEnt.setEW_DT(this.getEW_DT());
         
          newEnt.setINSP_WISH_YMD(this.getINSP_WISH_YMD());
         
          newEnt.setOFFI_TELNUM(this.getOFFI_TELNUM());
         
          newEnt.setOFFI_NM(this.getOFFI_NM());
         
          newEnt.setUSEBEFINSP_DELINUM(this.getUSEBEFINSP_DELINUM());
         
          newEnt.setSUV(this.getSUV());
         
          newEnt.setREMARK(this.getREMARK());
         
          newEnt.setCER_DELI_YN(this.getCER_DELI_YN());
         
          newEnt.setPLAN_CONFIRM_REMARK(this.getPLAN_CONFIRM_REMARK());
         
          newEnt.setNAPPL_YN(this.getNAPPL_YN());
         
          newEnt.setNAPPL_CAUSE(this.getNAPPL_CAUSE());
         
          newEnt.setDOC_INSP_REMARK(this.getDOC_INSP_REMARK());
         
          newEnt.setWRT_ID(this.getWRT_ID());
         
          newEnt.setINS_DT(this.getINS_DT());
         
          newEnt.setUPD_DT(this.getUPD_DT());
         
          newEnt.setCIV_RECV_NUM(this.getCIV_RECV_NUM());
         
          newEnt.setRECV_DT(this.getRECV_DT());
         
          newEnt.setPLAN_CONFIRM_PER_YN(this.getPLAN_CONFIRM_PER_YN());
         
          newEnt.setPLAN_ENT_CHG_YN(this.getPLAN_ENT_CHG_YN());
         
          newEnt.setPLAN_CONT_CHG_YN(this.getPLAN_CONT_CHG_YN());
         
          newEnt.setRECV_NUM(this.getRECV_NUM());
         
          newEnt.setATT_DOC(this.getATT_DOC());
         
          newEnt.setDELI_DT(this.getDELI_DT());
         
          newEnt.setDEFI_YN(this.getDEFI_YN());
         
          newEnt.setPROC_STE(this.getPROC_STE());
         
          newEnt.setISSUE_ITEM(this.getISSUE_ITEM());
         
          newEnt.setNET_RECV_YN(this.getNET_RECV_YN());
         
          newEnt.setPROC_LIM(this.getPROC_LIM());
         
          newEnt.setINSP_NUM(this.getINSP_NUM());
         
          newEnt.setPROC_OFFI(this.getPROC_OFFI());
         
          newEnt.setPLAN_CONFIRM_PER_YN_CONT(this.getPLAN_CONFIRM_PER_YN_CONT());
         
          newEnt.setPLAN_ENT_CHG_YN_CONT(this.getPLAN_ENT_CHG_YN_CONT());
         
          newEnt.setPLAN_CONT_CHG_YN_CONT(this.getPLAN_CONT_CHG_YN_CONT());
         
          newEnt.setCHG_INSP(this.getCHG_INSP());
         
          newEnt.setINSP_ITEM(this.getINSP_ITEM());
         
          newEnt.setETC_INSP_BAS(this.getETC_INSP_BAS());
         
          newEnt.setWORK_ITEM_ETC(this.getWORK_ITEM_ETC());
         
          newEnt.setUPD_DT_OLD(this.getUPD_DT_OLD());
         
          newEnt.setBACKUP_TRANS_DT(this.getBACKUP_TRANS_DT());
         
          newEnt.setTAKE_TM(this.getTAKE_TM());
         
          newEnt.setUSER_NAME(this.getUSER_NAME());
         
          newEnt.setMW_PPS_GETR_ID(this.getMW_PPS_GETR_ID());
         
          newEnt.setOUTVARS(this.getOUTVARS());
         
          newEnt.setMW_AFR_SHTNM(this.getMW_AFR_SHTNM());
         
          newEnt.setMW_SE(this.getMW_SE());
         
          newEnt.setMW_CODE_CN(this.getMW_CODE_CN());
         
          newEnt.setTAKE_CONFRM_CODE(this.getTAKE_CONFRM_CODE());
         
          newEnt.setDEAL_SE(this.getDEAL_SE());
         
          newEnt.setDEAL_CODE_CN(this.getDEAL_CODE_CN());
         
          newEnt.setTAKE_SE(this.getTAKE_SE());
         
          newEnt.setTAKE_CODE_CN(this.getTAKE_CODE_CN());
         
          newEnt.setREAL_DEAL_YMD(this.getREAL_DEAL_YMD());
         
          newEnt.setMW_TAKE_NO(this.getMW_TAKE_NO());
         
          newEnt.setETC1(this.getETC1());
         
          newEnt.setETC2(this.getETC2());
         
          newEnt.setETC3(this.getETC3());
         
          newEnt.setBEF_PLANER_NAME(this.getBEF_PLANER_NAME());
         
          newEnt.setPROC_OFFI_ID(this.getPROC_OFFI_ID());
         
          newEnt.setADMIT_DT(this.getADMIT_DT());
         
	 return newEnt;
  }

  public Object getByName(String key){
         Integer idx = (Integer)PT_UB_USEBEFOREHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                 return  this.getSIDO_CODE();
        
             case 2 :
                 return  this.getSIGUNGU_CODE();
        
             case 3 :
                 return  this.getAPPLPER_NM();
        
             case 4 :
                 return  this.getAPPLPER_REP();
        
             case 5 :
                 return  this.getAPPLPER_POSTNUM();
        
             case 6 :
                 return  this.getAPPLPER_ADDR();
        
             case 7 :
                 return  this.getAPPLPER_DETAILADDR();
        
             case 8 :
                 return  this.getAPPLPER_TELNUM();
        
             case 9 :
                 return  this.getOPE_NAME();
        
             case 10 :
                 return  this.getOPE_REP();
        
             case 11 :
                 return  this.getOPE_TELNUM();
        
             case 12 :
                 return  this.getCOI_WRT_NUM();
        
             case 13 :
                 return  this.getOPE_POSTNUM();
        
             case 14 :
                 return  this.getOPE_ADDR();
        
             case 15 :
                 return  this.getOPE_DETAILADDR();
        
             case 16 :
                 return  this.getINSP_SPOT_NM();
        
             case 17 :
                 return  this.getINSP_SPOT_POSTNUM();
        
             case 18 :
                 return  this.getINSP_SPOT_ADDR();
        
             case 19 :
                 return  this.getINSP_SPOT_DETAILADDR();
        
             case 20 :
                 return  this.getPLANER_NM();
        
             case 21 :
                 return  this.getWORK_ITEM();
        
             case 22 :
                 return  this.getAREA();
        
             case 23 :
                 return  this.getNUM_FL();
        
             case 24 :
                 return  this.getUSE();
        
             case 25 :
                 return  this.getINSP_APPL_WORK();
        
             case 26 :
                 return  this.getINSP_APPL_DT();
        
             case 27 :
                 return  this.getINSP_DT();
        
             case 28 :
                 return  this.getINSP_FEE();
        
             case 29 :
                 return  this.getINSPER_NM();
        
             case 30 :
                 return  this.getINSPER_POSI();
        
             case 31 :
                 return  this.getJUDGM();
        
             case 32 :
                 return  this.getPLAN_CONFIRM_YN();
        
             case 33 :
                 return  this.getSW_BEF_REPO_DELINUM();
        
             case 34 :
                 return  this.getSW_DT();
        
             case 35 :
                 return  this.getEW_DT();
        
             case 36 :
                 return  this.getINSP_WISH_YMD();
        
             case 37 :
                 return  this.getOFFI_TELNUM();
        
             case 38 :
                 return  this.getOFFI_NM();
        
             case 39 :
                 return  this.getUSEBEFINSP_DELINUM();
        
             case 40 :
                 return  this.getSUV();
        
             case 41 :
                 return  this.getREMARK();
        
             case 42 :
                 return  this.getCER_DELI_YN();
        
             case 43 :
                 return  this.getPLAN_CONFIRM_REMARK();
        
             case 44 :
                 return  this.getNAPPL_YN();
        
             case 45 :
                 return  this.getNAPPL_CAUSE();
        
             case 46 :
                 return  this.getDOC_INSP_REMARK();
        
             case 47 :
                 return  this.getWRT_ID();
        
             case 48 :
                 return  this.getINS_DT();
        
             case 49 :
                 return  this.getUPD_DT();
        
             case 50 :
                 return  this.getCIV_RECV_NUM();
        
             case 51 :
                 return  this.getRECV_DT();
        
             case 52 :
                 return  this.getPLAN_CONFIRM_PER_YN();
        
             case 53 :
                 return  this.getPLAN_ENT_CHG_YN();
        
             case 54 :
                 return  this.getPLAN_CONT_CHG_YN();
        
             case 55 :
                 return  this.getRECV_NUM();
        
             case 56 :
                 return  this.getATT_DOC();
        
             case 57 :
                 return  this.getDELI_DT();
        
             case 58 :
                 return  this.getDEFI_YN();
        
             case 59 :
                 return  this.getPROC_STE();
        
             case 60 :
                 return  this.getISSUE_ITEM();
        
             case 61 :
                 return  this.getNET_RECV_YN();
        
             case 62 :
                 return  this.getPROC_LIM();
        
             case 63 :
                 return  this.getINSP_NUM();
        
             case 64 :
                 return  this.getPROC_OFFI();
        
             case 65 :
                 return  this.getPLAN_CONFIRM_PER_YN_CONT();
        
             case 66 :
                 return  this.getPLAN_ENT_CHG_YN_CONT();
        
             case 67 :
                 return  this.getPLAN_CONT_CHG_YN_CONT();
        
             case 68 :
                 return  this.getCHG_INSP();
        
             case 69 :
                 return  this.getINSP_ITEM();
        
             case 70 :
                 return  this.getETC_INSP_BAS();
        
             case 71 :
                 return  this.getWORK_ITEM_ETC();
        
             case 72 :
                 return  this.getUPD_DT_OLD();
        
             case 73 :
                 return  this.getBACKUP_TRANS_DT();
        
             case 74 :
                 return  this.getTAKE_TM();
        
             case 75 :
                 return  this.getUSER_NAME();
        
             case 76 :
                 return  this.getMW_PPS_GETR_ID();
        
             case 77 :
                 return  this.getOUTVARS();
        
             case 78 :
                 return  this.getMW_AFR_SHTNM();
        
             case 79 :
                 return  this.getMW_SE();
        
             case 80 :
                 return  this.getMW_CODE_CN();
        
             case 81 :
                 return  this.getTAKE_CONFRM_CODE();
        
             case 82 :
                 return  this.getDEAL_SE();
        
             case 83 :
                 return  this.getDEAL_CODE_CN();
        
             case 84 :
                 return  this.getTAKE_SE();
        
             case 85 :
                 return  this.getTAKE_CODE_CN();
        
             case 86 :
                 return  this.getREAL_DEAL_YMD();
        
             case 87 :
                 return  this.getMW_TAKE_NO();
        
             case 88 :
                 return  this.getETC1();
        
             case 89 :
                 return  this.getETC2();
        
             case 90 :
                 return  this.getETC3();
        
             case 91 :
                 return  this.getBEF_PLANER_NAME();
        
             case 92 :
                 return  this.getPROC_OFFI_ID();
        
             case 93 :
                 return  this.getADMIT_DT();
        
	    }

	if(this.isExField(key)==true)
	      return getExValue(key);

	return null;
  }
  public void   setByName(String key, Object value){
         Integer idx = (Integer)PT_UB_USEBEFOREHelper.fieldMap.get(key);
	 if(idx !=null)
	    switch(idx.intValue()){
        
             case 1 :
                    this.setSIDO_CODE((String)value);
	            return;  
        
             case 2 :
                    this.setSIGUNGU_CODE((String)value);
	            return;  
        
             case 3 :
                    this.setAPPLPER_NM((String)value);
	            return;  
        
             case 4 :
                    this.setAPPLPER_REP((String)value);
	            return;  
        
             case 5 :
                    this.setAPPLPER_POSTNUM((String)value);
	            return;  
        
             case 6 :
                    this.setAPPLPER_ADDR((String)value);
	            return;  
        
             case 7 :
                    this.setAPPLPER_DETAILADDR((String)value);
	            return;  
        
             case 8 :
                    this.setAPPLPER_TELNUM((String)value);
	            return;  
        
             case 9 :
                    this.setOPE_NAME((String)value);
	            return;  
        
             case 10 :
                    this.setOPE_REP((String)value);
	            return;  
        
             case 11 :
                    this.setOPE_TELNUM((String)value);
	            return;  
        
             case 12 :
                    this.setCOI_WRT_NUM((String)value);
	            return;  
        
             case 13 :
                    this.setOPE_POSTNUM((String)value);
	            return;  
        
             case 14 :
                    this.setOPE_ADDR((String)value);
	            return;  
        
             case 15 :
                    this.setOPE_DETAILADDR((String)value);
	            return;  
        
             case 16 :
                    this.setINSP_SPOT_NM((String)value);
	            return;  
        
             case 17 :
                    this.setINSP_SPOT_POSTNUM((String)value);
	            return;  
        
             case 18 :
                    this.setINSP_SPOT_ADDR((String)value);
	            return;  
        
             case 19 :
                    this.setINSP_SPOT_DETAILADDR((String)value);
	            return;  
        
             case 20 :
                    this.setPLANER_NM((String)value);
	            return;  
        
             case 21 :
                    this.setWORK_ITEM((String)value);
	            return;  
        
             case 22 :
                    this.setAREA((String)value);
	            return;  
        
             case 23 :
                    this.setNUM_FL((String)value);
	            return;  
        
             case 24 :
                    this.setUSE((String)value);
	            return;  
        
             case 25 :
                    this.setINSP_APPL_WORK((String)value);
	            return;  
        
             case 26 :
                    this.setINSP_APPL_DT((String)value);
	            return;  
        
             case 27 :
                    this.setINSP_DT((String)value);
	            return;  
        
             case 28 :
                    this.setINSP_FEE((String)value);
	            return;  
        
             case 29 :
                    this.setINSPER_NM((String)value);
	            return;  
        
             case 30 :
                    this.setINSPER_POSI((String)value);
	            return;  
        
             case 31 :
                    this.setJUDGM((String)value);
	            return;  
        
             case 32 :
                    this.setPLAN_CONFIRM_YN((String)value);
	            return;  
        
             case 33 :
                    this.setSW_BEF_REPO_DELINUM((String)value);
	            return;  
        
             case 34 :
                    this.setSW_DT((String)value);
	            return;  
        
             case 35 :
                    this.setEW_DT((String)value);
	            return;  
        
             case 36 :
                    this.setINSP_WISH_YMD((String)value);
	            return;  
        
             case 37 :
                    this.setOFFI_TELNUM((String)value);
	            return;  
        
             case 38 :
                    this.setOFFI_NM((String)value);
	            return;  
        
             case 39 :
                    this.setUSEBEFINSP_DELINUM((String)value);
	            return;  
        
             case 40 :
                    this.setSUV((String)value);
	            return;  
        
             case 41 :
                    this.setREMARK((String)value);
	            return;  
        
             case 42 :
                    this.setCER_DELI_YN((String)value);
	            return;  
        
             case 43 :
                    this.setPLAN_CONFIRM_REMARK((String)value);
	            return;  
        
             case 44 :
                    this.setNAPPL_YN((String)value);
	            return;  
        
             case 45 :
                    this.setNAPPL_CAUSE((String)value);
	            return;  
        
             case 46 :
                    this.setDOC_INSP_REMARK((String)value);
	            return;  
        
             case 47 :
                    this.setWRT_ID((String)value);
	            return;  
        
             case 48 :
                    this.setINS_DT((String)value);
	            return;  
        
             case 49 :
                    this.setUPD_DT((String)value);
	            return;  
        
             case 50 :
                    this.setCIV_RECV_NUM((String)value);
	            return;  
        
             case 51 :
                    this.setRECV_DT((String)value);
	            return;  
        
             case 52 :
                    this.setPLAN_CONFIRM_PER_YN((String)value);
	            return;  
        
             case 53 :
                    this.setPLAN_ENT_CHG_YN((String)value);
	            return;  
        
             case 54 :
                    this.setPLAN_CONT_CHG_YN((String)value);
	            return;  
        
             case 55 :
                    this.setRECV_NUM((String)value);
	            return;  
        
             case 56 :
                    this.setATT_DOC((String)value);
	            return;  
        
             case 57 :
                    this.setDELI_DT((String)value);
	            return;  
        
             case 58 :
                    this.setDEFI_YN((String)value);
	            return;  
        
             case 59 :
                    this.setPROC_STE((String)value);
	            return;  
        
             case 60 :
                    this.setISSUE_ITEM((String)value);
	            return;  
        
             case 61 :
                    this.setNET_RECV_YN((String)value);
	            return;  
        
             case 62 :
                    this.setPROC_LIM((String)value);
	            return;  
        
             case 63 :
                    this.setINSP_NUM((String)value);
	            return;  
        
             case 64 :
                    this.setPROC_OFFI((String)value);
	            return;  
        
             case 65 :
                    this.setPLAN_CONFIRM_PER_YN_CONT((String)value);
	            return;  
        
             case 66 :
                    this.setPLAN_ENT_CHG_YN_CONT((String)value);
	            return;  
        
             case 67 :
                    this.setPLAN_CONT_CHG_YN_CONT((String)value);
	            return;  
        
             case 68 :
                    this.setCHG_INSP((String)value);
	            return;  
        
             case 69 :
                    this.setINSP_ITEM((String)value);
	            return;  
        
             case 70 :
                    this.setETC_INSP_BAS((String)value);
	            return;  
        
             case 71 :
                    this.setWORK_ITEM_ETC((String)value);
	            return;  
        
             case 72 :
                    this.setUPD_DT_OLD((String)value);
	            return;  
        
             case 73 :
                    this.setBACKUP_TRANS_DT((String)value);
	            return;  
        
             case 74 :
                    this.setTAKE_TM((String)value);
	            return;  
        
             case 75 :
                    this.setUSER_NAME((String)value);
	            return;  
        
             case 76 :
                    this.setMW_PPS_GETR_ID((String)value);
	            return;  
        
             case 77 :
                    this.setOUTVARS((String)value);
	            return;  
        
             case 78 :
                    this.setMW_AFR_SHTNM((String)value);
	            return;  
        
             case 79 :
                    this.setMW_SE((String)value);
	            return;  
        
             case 80 :
                    this.setMW_CODE_CN((String)value);
	            return;  
        
             case 81 :
                    this.setTAKE_CONFRM_CODE((String)value);
	            return;  
        
             case 82 :
                    this.setDEAL_SE((String)value);
	            return;  
        
             case 83 :
                    this.setDEAL_CODE_CN((String)value);
	            return;  
        
             case 84 :
                    this.setTAKE_SE((String)value);
	            return;  
        
             case 85 :
                    this.setTAKE_CODE_CN((String)value);
	            return;  
        
             case 86 :
                    this.setREAL_DEAL_YMD((String)value);
	            return;  
        
             case 87 :
                    this.setMW_TAKE_NO((String)value);
	            return;  
        
             case 88 :
                    this.setETC1((String)value);
	            return;  
        
             case 89 :
                    this.setETC2((String)value);
	            return;  
        
             case 90 :
                    this.setETC3((String)value);
	            return;  
        
             case 91 :
                    this.setBEF_PLANER_NAME((String)value);
	            return;  
        
             case 92 :
                    this.setPROC_OFFI_ID((String)value);
	            return;  
        
             case 93 :
                    this.setADMIT_DT((String)value);
	            return;  
        
         }
	if(this.isExField(key)==true)
	      setExValue(key, value);
  
  }
  
  public String toXML(){
         return PT_UB_USEBEFOREHelper.toXML(this);
  }
  
}
