
create table PT_R_ENGINEER_M_PRIZE(
    SEQ VARCHAR2(12) NOT NULL , /* */
    CARE_BOOK_ISSUE_NUM VARCHAR2(20) NOT NULL , /* */
    YMD VARCHAR2(20)  , /* */
    ITEM VARCHAR2(30)  , /* */
    PAD_REST_TERM VARCHAR2(30)  , /* */
    BAS VARCHAR2(30)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_DT VARCHAR2(24)  , /* */
    ETC1 VARCHAR2(30)  , /* */
    ETC2 VARCHAR2(50)  , /* */
    PRIMARY KEY(CARE_BOOK_ISSUE_NUM,SEQ)
   );
