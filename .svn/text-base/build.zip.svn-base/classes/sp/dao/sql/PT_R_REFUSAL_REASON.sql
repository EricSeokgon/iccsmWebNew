
create table PT_R_REFUSAL_REASON(
    SEQ VARCHAR2(3) NOT NULL , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    REFS_ITEM VARCHAR2(6)  , /* */
    REFS_CAUSE VARCHAR2(256)  , /* */
    CHGBRE_SEQ NUMBER(4) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    PRIMARY KEY(CHGBRE_SEQ,SEQ,TMP_WRT_NUM)
   );
