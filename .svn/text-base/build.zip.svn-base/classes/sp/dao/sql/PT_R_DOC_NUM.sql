
create table PT_R_DOC_NUM(
    DOC_CLASS VARCHAR2(20) NOT NULL , /* */
    SD_CODE VARCHAR2(3) NOT NULL , /* */
    SGG_CODE VARCHAR2(4)  , /* */
    DOC_NUM1 VARCHAR2(4)  , /* */
    DOC_NUM2 VARCHAR2(4)  , /* */
    DOC_NUM3 VARCHAR2(4)  , /* */
    DOC_NUM4 VARCHAR2(4)  , /* */
    PRIMARY KEY(DOC_CLASS,SD_CODE)
   );
