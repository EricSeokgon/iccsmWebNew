
create table PT_BBS_COM_COMMENT(
    COMMENT_SEQ NUMBER(10) NOT NULL , /* */
    CT_ID VARCHAR2(30)  , /* */
    BOARD_SEQ VARCHAR2(10)  , /* */
    PASS VARCHAR2(10)  , /* */
    WRT_NM NVARCHAR2(100)  , /* */
    WRT_ID VARCHAR2(20)  , /* */
    COMMET NVARCHAR2(4000)  , /* */
    UPD_DT VARCHAR2(23)  , /* */
    INS_DT VARCHAR2(23)  , /* */
    PRIMARY KEY(COMMENT_SEQ)
   );
