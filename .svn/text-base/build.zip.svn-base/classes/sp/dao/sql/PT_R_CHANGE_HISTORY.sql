
create table PT_R_CHANGE_HISTORY(
    CHANGE_SEQ VARCHAR2(20) NOT NULL , /* */
    CHANGE_DIV VARCHAR2(20)  , /* */
    RC_REGIST_NUM VARCHAR2(20)  , /* */
    REC_NUM VARCHAR2(24)  , /* */
    REC_ORGAN VARCHAR2(20)  , /* */
    SD_CODE VARCHAR2(20)  , /* */
    REC_PERIOD VARCHAR2(20)  , /* */
    MEMO VARCHAR2(20)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UDP_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    TMP_REG_NUM CHAR(18) NOT NULL , /* */
    PRIMARY KEY(CHANGE_SEQ,TMP_REG_NUM)
   );
