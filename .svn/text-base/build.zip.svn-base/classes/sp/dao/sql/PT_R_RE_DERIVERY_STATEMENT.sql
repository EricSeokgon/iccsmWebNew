
create table PT_R_RE_DERIVERY_STATEMENT(
    RECV_NUM VARCHAR2(12) NOT NULL , /* */
    SIDO_CODE VARCHAR2(4) NOT NULL , /* */
    COI_WRT_NUM VARCHAR2(12)  , /* */
    RECV_DT VARCHAR2(8)  , /* */
    OFFI_PART VARCHAR2(50)  , /* */
    OFFI_PART_REBO_WRT_NUM VARCHAR2(12)  , /* */
    NAME VARCHAR2(50)  , /* */
    WRT_NUM VARCHAR2(12)  , /* */
    REP VARCHAR2(20)  , /* */
    TEL_NUM VARCHAR2(17)  , /* */
    FAX_NUM VARCHAR2(17)  , /* */
    OFF_ADDR VARCHAR2(200)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    MOT_STE VARCHAR2(6)  , /* */
    DEFI_STE VARCHAR2(1)  , /* */
    COI VARCHAR2(1)  , /* */
    WRTBOOK VARCHAR2(1)  , /* */
    APPL_CAUSE VARCHAR2(256)  , /* */
    TMP_WRT_NUM VARCHAR2(32)  , /* */
    PRIMARY KEY(RECV_NUM,SIDO_CODE)
   );
