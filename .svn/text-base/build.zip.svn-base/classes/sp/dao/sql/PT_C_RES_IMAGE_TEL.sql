
create table PT_C_RES_IMAGE_TEL(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    ITEM_NM VARCHAR2(100)  , /* */
    QTT NUMBER(10)  , /* */
    INSTAL_DT VARCHAR2(24)  , /* */
    PDT VARCHAR2(100)  , /* */
    REMARK VARCHAR2(125)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    ESTAB_AOM VARCHAR2(12)  , /* */
    PRIMARY KEY(SEQ)
   );
