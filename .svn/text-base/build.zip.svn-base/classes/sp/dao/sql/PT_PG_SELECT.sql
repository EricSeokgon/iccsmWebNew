
SELECT 
	PG_ID, PG_NAME, PG_URL, UPD_DT, USE_YN, ORDER_SEQ, PG_GROUP_ID 
FROM   PT_PG ;
                   
