
SELECT 
	JUMIN, JUMIN_ENCODE, JUMIN_JAVA 
FROM   TEST_TB ;
                   
