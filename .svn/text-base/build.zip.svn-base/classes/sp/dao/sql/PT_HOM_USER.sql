
create table PT_HOM_USER(
    USER_ID VARCHAR2(16) NOT NULL , /* */
    USER_NAME VARCHAR2(64)  , /* */
    USER_PASSWD VARCHAR2(64)  , /* */
    USER_NAT_NUM1 VARCHAR2(16)  , /* */
    USER_NAT_NUM2 VARCHAR2(50)  , /* */
    USER_EMAIL VARCHAR2(128)  , /* */
    USER_ZIPCODE VARCHAR2(8)  , /* */
    USER_ADDR VARCHAR2(128)  , /* */
    USER_ADDR_ETC VARCHAR2(128)  , /* */
    USER_TEL VARCHAR2(16)  , /* */
    USER_MOBILE VARCHAR2(16)  , /* */
    USER_SEX VARCHAR2(16)  , /* */
    INP_SITE VARCHAR2(50)  , /* */
    SC_CD VARCHAR2(4)  , /* */
    SGG_CD VARCHAR2(4)  , /* */
    CAPITAL VARCHAR2(2)  , /* */
    BIGO VARCHAR2(200)  , /* */
    SMS_YN VARCHAR2(2)  , /* */
    NEWS_YN VARCHAR2(2)  , /* */
    USE_CODE VARCHAR2(1)  , /* */
    INS_DT DATE  , /* */
    UPD_DT DATE  , /* */
    PRIMARY KEY(USER_ID)
   );
