
create table PT_R_WORK_RESULTS(
    SEQ VARCHAR2(4) NOT NULL , /* */
    YEAR VARCHAR2(4)  , /* */
    WORK_ROM VARCHAR2(15)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    PRIMARY KEY(SEQ,TMP_WRT_NUM)
   );
