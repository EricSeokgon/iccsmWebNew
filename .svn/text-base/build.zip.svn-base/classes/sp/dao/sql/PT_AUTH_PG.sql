
create table PT_AUTH_PG(
    AUTH_GROUP_CODE VARCHAR2(30) NOT NULL , /* */
    PG_ID VARCHAR2(5) NOT NULL , /* */
    PG_GROUP_ID VARCHAR2(5)  , /* */
    READ_FLAG VARCHAR2(1)  , /* */
    WRITE_FLAG VARCHAR2(1)  , /* */
    COM_FLAG VARCHAR2(1)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(AUTH_GROUP_CODE,PG_ID)
   );
