
create table PT_R_DEFICIT_CODE(
    DEFI_CODE VARCHAR2(6) NOT NULL , /* */
    CONT VARCHAR2(500)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    DEFI_GROUP VARCHAR2(6) NOT NULL , /* */
    PRIMARY KEY(DEFI_CODE,DEFI_GROUP)
   );
