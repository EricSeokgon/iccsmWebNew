
SELECT 
	USERID, FORMID, SAMPLENAME, XML 
FROM   PT_TEMPLET ;
                   
