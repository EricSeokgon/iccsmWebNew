
SELECT 
	REG_DATE, H_01, H_02, H_03, H_04, H_05, H_06, H_07, H_08, H_09, H_10, H_11, H_12, H_13, H_14, H_15, H_16, H_17, H_18, H_19, H_20, H_21, H_22, H_23, H_24, DAY_TOTAL 
FROM   PT_HOM_VISIT_HOUR_COUNT ;
                   
