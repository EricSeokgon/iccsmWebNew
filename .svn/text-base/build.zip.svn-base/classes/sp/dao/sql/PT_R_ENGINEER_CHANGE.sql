
create table PT_R_ENGINEER_CHANGE(
    ENGINEER_NM VARCHAR2(20)  , /* */
    ENGINEER_SSN1 VARCHAR2(18)  , /* */
    ENGINEER_SSN2 VARCHAR2(21)  , /* */
    EMPL_YMD VARCHAR2(8)  , /* */
    RET_YMD VARCHAR2(8)  , /* */
    REMARK VARCHAR2(256)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    SEQ NUMBER(4) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    TMP_FIELD VARCHAR2(20)  , /* */
    PRIMARY KEY(SEQ,TMP_WRT_NUM)
   );
