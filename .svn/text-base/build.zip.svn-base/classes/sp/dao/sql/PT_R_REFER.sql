
create table PT_R_REFER(
    SD_CODE VARCHAR2(4)  , /* */
    SEQ NUMBER(11) NOT NULL , /* */
    SGG_CODE VARCHAR2(4)  , /* */
    GUBUN VARCHAR2(20)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UDP_DT VARCHAR2(24)  , /* */
    NAME_HANJA VARCHAR2(20)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    SSN1 NUMBER(6)  , /* */
    NOTE VARCHAR2(128)  , /* */
    ADDR VARCHAR2(128)  , /* */
    FAMILY_HEAD VARCHAR2(20)  , /* */
    SSN2 NUMBER(7)  , /* */
    FAMILY_HEAD_RELATION VARCHAR2(20)  , /* */
    NAME_KOR VARCHAR2(18)  , /* */
    ORIGIN VARCHAR2(128)  , /* */
    TMP_REG_NUM CHAR(18) NOT NULL , /* */
    ENTER_DATE VARCHAR2(8)  , /* */
    RETIRE_DATE VARCHAR2(8)  , /* */
    REFER_YN VARCHAR2(1)  , /* */
    PRIMARY KEY(SEQ,TMP_REG_NUM)
   );
