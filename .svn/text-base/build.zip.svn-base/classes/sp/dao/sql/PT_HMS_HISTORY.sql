
create table PT_HMS_HISTORY(
    SEQ NUMBER(11) NOT NULL , /* */
    MENU_ID VARCHAR2(32)  , /* */
    VERSION VARCHAR2(32)  , /* */
    CONTENT CLOB  , /* */
    USE_YN VARCHAR2(1)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    WRT_NM VARCHAR2(32)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(SEQ)
   );
