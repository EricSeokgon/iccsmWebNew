
create table PT_C_RES_SWIT(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52)  , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    ITEM_NM VARCHAR2(100)  , /* */
    INLINE_NUM NUMBER(10)  , /* */
    OUTLINE_CH_NUM NUMBER(10)  , /* */
    OUTLINE_E1_NUM NUMBER(10)  , /* */
    INSTAL_DT VARCHAR2(12)  , /* */
    ESTAB_AOM NUMBER(20)  , /* */
    REMARK VARCHAR2(125)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    PRIMARY KEY(SEQ)
   );
