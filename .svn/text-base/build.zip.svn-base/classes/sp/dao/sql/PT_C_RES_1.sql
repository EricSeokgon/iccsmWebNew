
create table PT_C_RES_1(
    SEQ VARCHAR2(4)  , /* */
    SIDO_NM VARCHAR2(12)  , /* */
    SIDO_CODE VARCHAR2(4)  , /* */
    ITEM_NM VARCHAR2(50)  , /* */
    LINE_NUM NUMBER(10)  , /* */
    LINE_CH_NUM NUMBER(10)  , /* */
    LINE_E1_NUM NUMBER(10)  , /* */
    SET_DT VARCHAR2(24)  , /* */
    EQU_COST VARCHAR2(12)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    ETC VARCHAR2(50)  , /* */
    SIGUNGU_CODE VARCHAR2(4)  , /* */
    PRIMARY KEY()
   );
