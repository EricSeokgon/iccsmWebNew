
create table PT_C_RES_PRIVATE(
    SEQ NUMBER(4) NOT NULL , /* */
    ORG_NM VARCHAR2(52) NOT NULL , /* */
    SIDO_CODE VARCHAR2(5)  , /* */
    TEL_TD NUMBER(10)  , /* */
    M_BELOW NUMBER(10)  , /* */
    USE VARCHAR2(50)  , /* */
    REMARK VARCHAR2(125)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(12)  , /* */
    SIGUNGU_CODE VARCHAR2(5)  , /* */
    PRIMARY KEY(ORG_NM,SEQ)
   );
