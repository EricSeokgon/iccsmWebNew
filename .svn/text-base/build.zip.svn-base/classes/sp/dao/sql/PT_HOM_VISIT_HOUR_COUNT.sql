
create table PT_HOM_VISIT_HOUR_COUNT(
    REG_DATE VARCHAR2(12) NOT NULL , /* */
    H_01 NUMBER(22)  , /* */
    H_02 NUMBER(22)  , /* */
    H_03 NUMBER(22)  , /* */
    H_04 NUMBER(22)  , /* */
    H_05 NUMBER(22)  , /* */
    H_06 NUMBER(22)  , /* */
    H_07 NUMBER(22)  , /* */
    H_08 NUMBER(22)  , /* */
    H_09 NUMBER(22)  , /* */
    H_10 NUMBER(22)  , /* */
    H_11 NUMBER(22)  , /* */
    H_12 NUMBER(22)  , /* */
    H_13 NUMBER(22)  , /* */
    H_14 NUMBER(22)  , /* */
    H_15 NUMBER(22)  , /* */
    H_16 NUMBER(22)  , /* */
    H_17 NUMBER(22)  , /* */
    H_18 NUMBER(22)  , /* */
    H_19 NUMBER(22)  , /* */
    H_20 NUMBER(22)  , /* */
    H_21 NUMBER(22)  , /* */
    H_22 NUMBER(22)  , /* */
    H_23 NUMBER(22)  , /* */
    H_24 NUMBER(22)  , /* */
    DAY_TOTAL NUMBER(22)  , /* */
    PRIMARY KEY(REG_DATE)
   );
