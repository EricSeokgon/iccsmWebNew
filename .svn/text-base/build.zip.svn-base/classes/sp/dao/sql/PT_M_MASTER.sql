
create table PT_M_MASTER(
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    WRT_NUM VARCHAR2(12) NOT NULL , /* */
    WRT_DT VARCHAR2(8)  , /* */
    REGR VARCHAR2(16)  , /* */
    VIOL_CONT_CODE VARCHAR2(50)  , /* */
    VIOL_DT VARCHAR2(8)  , /* */
    D_PER_CODE VARCHAR2(6)  , /* */
    DISPO_CONT VARCHAR2(6)  , /* */
    DISPO_CAUSE VARCHAR2(512)  , /* */
    DISPO_DT VARCHAR2(8)  , /* */
    MOT_STE VARCHAR2(6)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    SIDO_CODE VARCHAR2(4)  , /* */
    REMARK VARCHAR2(256)  , /* */
    LEG_BAS VARCHAR2(256)  , /* */
    SND_STE VARCHAR2(1)  , /* */
    SND_DT VARCHAR2(8)  , /* */
    HOME_NOTE VARCHAR2(8)  , /* */
    NOTE_GUID_DT VARCHAR2(8)  , /* */
    OFFI_REPORT_DT VARCHAR2(8)  , /* */
    ASSO_GUILD_DT VARCHAR2(8)  , /* */
    RECV_NUM VARCHAR2(24)  , /* */
    DISPO_CONT2 VARCHAR2(6)  , /* */
    BUSISUSP_START_DT VARCHAR2(8)  , /* */
    BUSISUSP_END_DT VARCHAR2(8)  , /* */
    DOC_CODE VARCHAR2(50)  , /* */
    PRIMARY KEY(TMP_WRT_NUM,WRT_NUM)
   );
