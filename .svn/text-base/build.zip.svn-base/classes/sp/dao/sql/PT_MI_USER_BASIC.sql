
create table PT_MI_USER_BASIC(
    OFFI_ID VARCHAR2(16) NOT NULL , /* */
    NM VARCHAR2(40)  , /* */
    TEL VARCHAR2(16)  , /* */
    SIDO_CODE VARCHAR2(10)  , /* */
    SIGUNGU_CODE VARCHAR2(10)  , /* */
    PART VARCHAR2(50)  , /* */
    POS VARCHAR2(20)  , /* */
    GROUP_CODE VARCHAR2(5)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    PASS VARCHAR2(16)  , /* */
    HOME_GROUP VARCHAR2(5)  , /* */
    MOBILE VARCHAR2(16)  , /* */
    E_MAIL VARCHAR2(128)  , /* */
    OFFSEAL VARCHAR2(26)  , /* */
    TEL1 VARCHAR2(20)  , /* */
    TEL2 VARCHAR2(20)  , /* */
    TEL3 VARCHAR2(20)  , /* */
    MOBILE1 VARCHAR2(20)  , /* */
    MOBILE2 VARCHAR2(20)  , /* */
    MOBILE3 VARCHAR2(20)  , /* */
    PHOTO VARCHAR2(26)  , /* */
    FAX1 VARCHAR2(20)  , /* */
    FAX2 VARCHAR2(20)  , /* */
    FAX3 VARCHAR2(20)  , /* */
    FAX VARCHAR2(20)  , /* */
    PRIMARY KEY(OFFI_ID)
   );
