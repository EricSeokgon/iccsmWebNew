
create table PT_S_CAPITAL(
    WRT_NUM VARCHAR2(12) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    REA_CAP VARCHAR2(15)  , /* */
    PAY_CAP VARCHAR2(15)  , /* */
    CASH_INV_COPA_YN VARCHAR2(1)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    PRIMARY KEY(TMP_WRT_NUM,WRT_NUM)
   );
