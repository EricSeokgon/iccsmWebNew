
create table PT_TEMPLET(
    USERID VARCHAR2(50)  , /* */
    FORMID VARCHAR2(50)  , /* */
    SAMPLENAME VARCHAR2(50)  , /* */
    XML VARCHAR2(256)  , /* */
    PRIMARY KEY()
   );
