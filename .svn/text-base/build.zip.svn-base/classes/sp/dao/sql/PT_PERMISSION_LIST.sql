
create table PT_PERMISSION_LIST(
    LIST_SEQ INT(11) NOT NULL , /* */
    TARGET_SEQ INT(11)  , /* */
    GROUP_SEQ INT(11)  , /* */
    INPT_DT VARCHAR(30)  , /* */
    PRIMARY KEY(LIST_SEQ)
   );
