
create table TEST_TB(
    JUMIN VARCHAR2(32)  , /* */
    JUMIN_ENCODE VARCHAR2(50)  , /* */
    JUMIN_JAVA VARCHAR2(50)  , /* */
    PRIMARY KEY()
   );
