
create table PT_USER(
    USER_CODE VARCHAR2(10) NOT NULL , /* */
    USER_NAME VARCHAR2(40)  , /* */
    USER_ID VARCHAR2(12)  , /* */
    USER_PASSWD VARCHAR2(12)  , /* */
    USER_EMAIL VARCHAR2(60)  , /* */
    USER_TEL VARCHAR2(14)  , /* */
    USER_MOBILE VARCHAR2(14)  , /* */
    USER_NAT_NUM VARCHAR2(14)  , /* */
    POST VARCHAR2(40)  , /* */
    EMAIL VARCHAR2(50)  , /* */
    CAPITAL VARCHAR2(20)  , /* */
    USE_YN VARCHAR2(1)  , /* */
    REG_DATE VARCHAR2(30)  , /* */
    MOD_DATE VARCHAR2(10)  , /* */
    LAST_CONN VARCHAR2(20)  , /* */
    ORGANIZATION VARCHAR2(40)  , /* */
    POSITION VARCHAR2(50)  , /* */
    STAFF_SYSTEM VARCHAR2(40)  , /* */
    STAFF_LEVEL VARCHAR2(40)  , /* */
    USER_AUTH VARCHAR2(20)  , /* */
    USER_LEVEL NUMBER(22)  , /* */
    PRIMARY KEY(USER_CODE)
   );
