
create table PT_UB_USEBEFORE_PRINT_LOG(
    UB_LOG_SEQ NUMBER(22)  , /* */
    USER_NAME VARCHAR2(200)  , /* */
    CIV_RECV_NUM VARCHAR2(100)  , /* */
    USER_NAT_NUM VARCHAR2(32)  , /* */
    SIGUNGU_CODE VARCHAR2(4)  , /* */
    USER_IP VARCHAR2(18)  , /* */
    INSP_DT VARCHAR2(24)  , /* */
    PRIMARY KEY()
   );
