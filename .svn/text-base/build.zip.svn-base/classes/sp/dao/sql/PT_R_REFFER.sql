
create table PT_R_REFFER(
    SEQ VARCHAR2(3) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    SI_DO_CODE VARCHAR2(4)  , /* */
    SI_GUN_GU_CODE VARCHAR2(4)  , /* */
    POS_CLASS VARCHAR2(6)  , /* */
    ENT_DT VARCHAR2(8)  , /* */
    RET_DT VARCHAR2(8)  , /* */
    NM_KOR VARCHAR2(20)  , /* */
    NM_HAN VARCHAR2(20)  , /* */
    ORI VARCHAR2(200)  , /* */
    ADDR VARCHAR2(200)  , /* */
    SSN1 VARCHAR2(18)  , /* */
    SSN2 VARCHAR2(21)  , /* */
    HEFA VARCHAR2(10)  , /* */
    HEFA_RELA VARCHAR2(10)  , /* */
    REMARK VARCHAR2(256)  , /* */
    CHAR_REF_YN VARCHAR2(2)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    SEND_YN VARCHAR2(1)  , /* */
    FOREIGN_YN VARCHAR2(1)  , /* */
    PRIMARY KEY(SEQ,TMP_WRT_NUM)
   );
