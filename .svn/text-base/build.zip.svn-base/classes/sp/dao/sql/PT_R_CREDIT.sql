
create table PT_R_CREDIT(
    SEQ NUMBER(4) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    LICTAX_PAYAOM VARCHAR2(12)  , /* */
    LICTAX_PAY_CO_DT VARCHAR2(8)  , /* */
    HOS_CRE_AOM VARCHAR2(12)  , /* */
    HOS_CRE_PAY_CO_DT VARCHAR2(8)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(SEQ,TMP_WRT_NUM)
   );
