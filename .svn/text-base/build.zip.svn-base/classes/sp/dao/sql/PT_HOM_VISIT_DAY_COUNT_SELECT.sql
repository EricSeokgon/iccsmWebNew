
SELECT 
	REG_DATE, D_01, D_02, D_03, D_04, D_05, D_06, D_07, D_08, D_09, D_10, D_11, D_12, D_13, D_14, D_15, D_16, D_17, D_18, D_19, D_20, D_21, D_22, D_23, D_24, D_25, D_26, D_27, D_28, D_29, D_30, D_31, MONTH_TOTAL 
FROM   PT_HOM_VISIT_DAY_COUNT ;
                   
