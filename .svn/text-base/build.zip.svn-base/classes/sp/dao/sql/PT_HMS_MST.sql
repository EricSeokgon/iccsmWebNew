
create table PT_HMS_MST(
    MENU_ID VARCHAR2(32) NOT NULL , /* */
    L_MENU_CD VARCHAR2(64)  , /* */
    M_MENU_CD VARCHAR2(64)  , /* */
    S_MENU_CD VARCHAR2(64)  , /* */
    TITLE VARCHAR2(32)  , /* */
    URL VARCHAR2(64)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    WRT_NM VARCHAR2(16)  , /* */
    UDP_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(MENU_ID)
   );
