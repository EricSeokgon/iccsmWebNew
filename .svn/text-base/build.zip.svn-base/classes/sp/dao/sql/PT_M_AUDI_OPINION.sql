
create table PT_M_AUDI_OPINION(
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    WRT_NUM VARCHAR2(12) NOT NULL , /* */
    DISPO_CONT VARCHAR2(1024)  , /* */
    CHEF_OPIN VARCHAR2(1024)  , /* */
    ETC VARCHAR2(1024)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    PRIMARY KEY(TMP_WRT_NUM,WRT_NUM)
   );
