
create table PT_HOM_VISIT_DAY_COUNT(
    REG_DATE VARCHAR2(12) NOT NULL , /* */
    D_01 NUMBER(22)  , /* */
    D_02 NUMBER(22)  , /* */
    D_03 NUMBER(22)  , /* */
    D_04 NUMBER(22)  , /* */
    D_05 NUMBER(22)  , /* */
    D_06 NUMBER(22)  , /* */
    D_07 NUMBER(22)  , /* */
    D_08 NUMBER(22)  , /* */
    D_09 NUMBER(22)  , /* */
    D_10 NUMBER(22)  , /* */
    D_11 NUMBER(22)  , /* */
    D_12 NUMBER(22)  , /* */
    D_13 NUMBER(22)  , /* */
    D_14 NUMBER(22)  , /* */
    D_15 NUMBER(22)  , /* */
    D_16 NUMBER(22)  , /* */
    D_17 NUMBER(22)  , /* */
    D_18 NUMBER(22)  , /* */
    D_19 NUMBER(22)  , /* */
    D_20 NUMBER(22)  , /* */
    D_21 NUMBER(22)  , /* */
    D_22 NUMBER(22)  , /* */
    D_23 NUMBER(22)  , /* */
    D_24 NUMBER(22)  , /* */
    D_25 NUMBER(22)  , /* */
    D_26 NUMBER(22)  , /* */
    D_27 NUMBER(22)  , /* */
    D_28 NUMBER(22)  , /* */
    D_29 NUMBER(22)  , /* */
    D_30 NUMBER(22)  , /* */
    D_31 NUMBER(22)  , /* */
    MONTH_TOTAL NUMBER(22)  , /* */
    PRIMARY KEY(REG_DATE)
   );
