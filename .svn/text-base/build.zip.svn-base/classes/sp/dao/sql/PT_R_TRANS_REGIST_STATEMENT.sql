
create table PT_R_TRANS_REGIST_STATEMENT(
    RECV_NUM VARCHAR2(12) NOT NULL , /* */
    SIDO_CODE VARCHAR2(4) NOT NULL , /* */
    RECV_DT VARCHAR2(8)  , /* */
    RECV_TIME VARCHAR2(4)  , /* */
    PROC_LIM VARCHAR2(8)  , /* */
    OFFI_PART VARCHAR2(50)  , /* */
    OFFI_PART_REBO_WRT_NUM VARCHAR2(12)  , /* */
    NAME VARCHAR2(50)  , /* */
    MANA_NUM VARCHAR2(18)  , /* */
    COM_NUM VARCHAR2(18)  , /* */
    REP_NM_KOR VARCHAR2(20)  , /* */
    REP_NM_HAN VARCHAR2(20)  , /* */
    ADDR_POST_NUM VARCHAR2(6)  , /* */
    ADDR_DETAIL_ADDR VARCHAR2(200)  , /* */
    ADDR_TEL_NUM VARCHAR2(17)  , /* */
    ADDR_FAX_NUM VARCHAR2(17)  , /* */
    DEFI_STE VARCHAR2(1)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    ADDR_ADDR VARCHAR2(100)  , /* */
    PROC_TIME VARCHAR2(6)  , /* */
    REP_MOBILE VARCHAR2(17)  , /* */
    REP_MOBILE2 VARCHAR2(4)  , /* */
    REP_MOBILE3 VARCHAR2(4)  , /* */
    ADDR_TEL_NUM2 VARCHAR2(4)  , /* */
    ADDR_TEL_NUM3 VARCHAR2(4)  , /* */
    ADDR_FAX_NUM2 VARCHAR2(4)  , /* */
    ADDR_FAX_NUM3 VARCHAR2(4)  , /* */
    ADDR_TEL_NUM1 VARCHAR2(4)  , /* */
    ADDR_FAX_NUM1 VARCHAR2(4)  , /* */
    REP_MOBILE1 VARCHAR2(4)  , /* */
    REP_SSN1 VARCHAR2(18)  , /* */
    REP_SSN2 VARCHAR2(21)  , /* */
    GUBUN VARCHAR2(25)  , /* */
    COI_WRT_NUM VARCHAR2(12)  , /* */
    MOT_STE VARCHAR2(6)  , /* */
    DOC_CODE VARCHAR2(50)  , /* */
    COMMANA_CLASS VARCHAR2(3)  , /* */
    OFFICE_AREA VARCHAR2(10)  , /* */
    DIAG_ORG_CODE VARCHAR2(6)  , /* */
    DIAG_NM_NM VARCHAR2(20)  , /* */
    COMPANY_DIAG_BAS_DT VARCHAR2(8)  , /* */
    PAY_CAP VARCHAR2(15)  , /* */
    DIAG_NM_WRT_NUM VARCHAR2(12)  , /* */
    COMPANY_DIAG_ISSUE_DT VARCHAR2(24)  , /* */
    REA_CAP VARCHAR2(15)  , /* */
    TUP_CLASS_CODE VARCHAR2(6)  , /* */
    TUP_AOM VARCHAR2(15)  , /* */
    OFFICE_USE_NAME VARCHAR2(50)  , /* */
    OFFICE_OWN_CLASS VARCHAR2(1)  , /* */
    LICTAX VARCHAR2(1)  , /* */
    HOSCRE VARCHAR2(1)  , /* */
    MEMO_CONT VARCHAR2(256)  , /* */
    PRIMARY KEY(RECV_NUM,SIDO_CODE)
   );
