
create table PT_AUTH_USER(
    USER_ID VARCHAR2(30) NOT NULL , /* */
    PG_ID VARCHAR2(5) NOT NULL , /* */
    PG_GROUP_ID VARCHAR2(5)  , /* */
    READ_FLAG VARCHAR2(1)  , /* */
    WRITE_FLAG VARCHAR2(1)  , /* */
    COM_FLAG VARCHAR2(1)  , /* */
    UPD_DT DATE  , /* */
    PRIMARY KEY(PG_ID,USER_ID)
   );
