
create table PT_PERMISSION_GROUP(
    GROUP_SEQ INT(11) NOT NULL , /* */
    NAME VARCHAR(200)  , /* */
    INPT_DT VARCHAR(30)  , /* */
    DESCRIPTION TEXT(65535)  , /* */
    PRIMARY KEY(GROUP_SEQ)
   );
