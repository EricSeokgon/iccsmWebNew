
create table PT_BBS_HIT(
    CT_ID VARCHAR2(16)  , /* */
    BOARD_SEQ NUMBER(22)  , /* */
    IPADDR VARCHAR2(100)  , /* */
    PRIMARY KEY()
   );
