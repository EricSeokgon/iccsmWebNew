
create table PT_R_OTOB_COM_CODE(
    OTOB_COM_CODE VARCHAR2(6) NOT NULL , /* */
    OTOB_COM_TOB_CONT VARCHAR2(50)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(OTOB_COM_CODE)
   );
