
create table PT_UB_SUVMEMO(
    MEMO_DT VARCHAR2(8)  , /* */
    MEMO_CONT VARCHAR2(512)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    SEQ NUMBER(4) NOT NULL , /* */
    RECV_NUM VARCHAR2(16) NOT NULL , /* */
    SIDO_CODE VARCHAR2(4) NOT NULL , /* */
    SIGUNGU_CODE VARCHAR2(5) NOT NULL , /* */
    WRT_TIME VARCHAR2(5)  , /* */
    WRT_NAME VARCHAR2(25)  , /* */
    PRIMARY KEY(RECV_NUM,SEQ,SIDO_CODE,SIGUNGU_CODE)
   );
