
create table PT_R_REG_MEMO(
    MEMO_SEQ NUMBER(4) NOT NULL , /* */
    MEMO_CONT VARCHAR2(512)  , /* */
    WRT_DT VARCHAR2(8)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    CHGBRE_SEQ NUMBER(4) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    PRIMARY KEY(CHGBRE_SEQ,MEMO_SEQ,TMP_WRT_NUM)
   );
