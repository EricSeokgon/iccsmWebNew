
create table PT_SMS_LOG(
    USER_ID VARCHAR2(12)  , /* */
    LOCAL_CD VARCHAR2(4)  , /* */
    AREA_CD VARCHAR2(5)  , /* */
    FROM_TEL VARCHAR2(14)  , /* */
    TO_TEL VARCHAR2(14)  , /* */
    MSG VARCHAR2(82)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    RESULT CHAR(1)  , /* */
    PRIMARY KEY()
   );
