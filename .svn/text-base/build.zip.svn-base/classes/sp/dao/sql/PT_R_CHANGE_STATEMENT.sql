
create table PT_R_CHANGE_STATEMENT(
    RECV_NUM VARCHAR2(12) NOT NULL , /* */
    SIDO_CODE VARCHAR2(4) NOT NULL , /* */
    RECV_DT VARCHAR2(8)  , /* */
    RECV_TIME VARCHAR2(4)  , /* */
    PROC_LIM VARCHAR2(8)  , /* */
    TMP_WRT_NUM VARCHAR2(12)  , /* */
    COV_DT VARCHAR2(8)  , /* */
    COM_NUM VARCHAR2(13)  , /* */
    DEFI_STE VARCHAR2(1)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    PRIMARY KEY(RECV_NUM,SIDO_CODE)
   );
