
SELECT 
	USERID, FORMID, SAMPLENAME, XML, DSNAME 
FROM   PT_XML ;
                   
