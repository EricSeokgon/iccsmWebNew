
create table PT_S_CONFIRM(
    WRT_NUM VARCHAR2(12) NOT NULL , /* */
    TMP_WRT_NUM VARCHAR2(12) NOT NULL , /* */
    VIOL_DT VARCHAR2(8)  , /* */
    VIOL_ITEM VARCHAR2(512)  , /* */
    VIOL_CONT VARCHAR2(2048)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    PRIMARY KEY(TMP_WRT_NUM,WRT_NUM)
   );
