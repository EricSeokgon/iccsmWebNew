
create table PT_S_SYSVAR_PDA(
    PDA_MAC_ADDR VARCHAR2(125)  , /* */
    PDA_NUM VARCHAR2(24)  , /* */
    WRT_ID VARCHAR2(16)  , /* */
    INS_DT VARCHAR2(24)  , /* */
    UPD_DT VARCHAR2(24)  , /* */
    SIDO_CODE VARCHAR2(4) NOT NULL , /* */
    SIGUNGU_CODE VARCHAR2(5) NOT NULL , /* */
    SEQ NUMBER(4) NOT NULL , /* */
    PRIMARY KEY(SEQ,SIDO_CODE,SIGUNGU_CODE)
   );
